#!/bin/bash

echo "$(tput setaf 1)Running Master AMI Software Installation Script$(tput sgr 0)"

region=$1
#Environment=$4
#DB_HOST=$5
#profile=$6
#DATABASE_PASSWORD=$7
#DB_USER=$8
#DB_NAME=$9

sudo apt-get update -y

cat <<EOF | sudo tee /etc/apt/source.list
deb http://ports.ubuntu.com/ubuntu-ports focal main restricted universe multiverse
deb-src http://ports.ubuntu.com/ubuntu-ports focal main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports focal-updates main restricted universe multiverse
deb-src http://ports.ubuntu.com/ubuntu-ports focal-updates main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports focal-backports main restricted universe multiverse
deb-src http://ports.ubuntu.com/ubuntu-ports focal-backports main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports focal-security main restricted universe multiverse
deb-src http://ports.ubuntu.com/ubuntu-ports focal-security main restricted universe multiverse
deb http://archive.canonical.com/ubuntu focal partner
deb-src http://archive.canonical.com/ubuntu focal partner
EOF

sudo sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt/ focal-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
sudo apt-get install --reinstall ubuntu-advantage-tools -y
sudo apt-get update -y
sudo apt-get install autoconf gcc curl libmcrypt-dev make libssl-dev wget dc vim net-tools build-essential gettext -y
sudo apt-get install nfs-common python3 -y
sudo update-alternatives --install  /usr/bin/python python /usr/bin/python3 1000

sudo apt-get install -y unzip python3-pip python-dev build-essential

sudo apt update -y
sudo apt install python3 python3-pip
sudo pip3 install awscli
aws --version

sudo apt-get purge ruby -y
sudo apt-get autoremove -y
sudo apt-get update -y

sudo apt-get install -y apt-transport-https ca-certificates curl software-properties-common

sudo apt update -y
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=arm64] https://download.docker.com/linux/ubuntu focal stable"
sudo apt install -y apt-transport-https ca-certificates curl software-properties-common
sudo apt install -y docker-ce
sudo curl -L "https://github.com/docker/compose/releases/download/v2.18.1/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
sudo usermod -aG docker ubuntu
sudo ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose
cd ~

docker-compose down
docker rm $(docker ps -a -q)
docker rmi $(docker images -a -q)
sudo rm docker-compose.yml
sudo rm -rf redis

#nrpe agent installation

sudo useradd nagios

cd /home/ubuntu/

curl -L -O https://nagios-plugins.org/download/nagios-plugins-2.2.1.tar.gz
tar zxf nagios-plugins-2.2.1.tar.gz
cd nagios-plugins-2.2.1
wget -O config.guess 'http://git.savannah.gnu.org/gitweb/?p=config.git;a=blob_plain;f=config.guess;hb=HEAD'
wget -O config.sub 'http://git.savannah.gnu.org/gitweb/?p=config.git;a=blob_plain;f=config.sub;hb=HEAD'
sudo cp config.guess build-aux/
sudo cp config.sub build-aux/
sudo ./configure --build=aarch64-linux
make
sudo make install

cd /home/ubuntu/
sudo rm nagios-plugins-2.2.1.tar.gz
sudo rm -rf nagios-plugins-2.2.1

sudo curl -L -O https://github.com/NagiosEnterprises/nrpe/releases/download/nrpe-3.2.1/nrpe-3.2.1.tar.gz
sudo tar zxf nrpe-3.2.1.tar.gz
cd nrpe-3.2.1
sudo ./configure --enable-command-args --with-ssl=/usr/include/openssl --with-ssl-lib=/usr/lib/aarch64-linux-gnu --enable-ssl
sudo make all
sudo make install-daemon
sudo make install-config
sudo make install-init
sudo systemctl start nrpe
sudo systemctl enable nrpe
cd ~
sudo rm nrpe-3.2.1.tar.gz
sudo rm -rf nrpe-3.2.1

(crontab -l; echo "0 */4 * * * bash /home/ubuntu/dropcache.sh") | sort -u | crontab -

cd /home/ubuntu/ami-setup-kit

#nagios plugin copy

sudo cp ./scripts/dropcache.sh /home/ubuntu/
sudo chmod +x /home/ubuntu/dropcache.sh

sudo cp ./nrpe-config/plugins/mem_chk /usr/local/nagios/libexec/
sudo cp ./nrpe-config/plugins/ram_chk /usr/local/nagios/libexec/
sudo cp ./nrpe-config/plugins/check_cpu.sh /usr/local/nagios/libexec/
sudo cp ./nrpe-config/plugins/check_mem.pl /usr/local/nagios/libexec/
sudo chmod +x /usr/local/nagios/libexec/mem_chk
sudo chmod +x /usr/local/nagios/libexec/ram_chk
sudo chmod +x /usr/local/nagios/libexec/check_cpu.sh
sudo chmod +x /usr/local/nagios/libexec/check_mem.pl

sudo cp ./nrpe-config/nrpe.cfg /usr/local/nagios/etc/nrpe.cfg

sudo service nrpe stop
sudo service nrpe start
sudo systemctl enable nrpe

sudo bash -c 'sysctl -w fs.file-max=2000000'
sudo bash -c 'echo "fs.file-max=2000000" >> /etc/sysctl.conf'
sudo bash -c 'echo "* - nofile 2000000" >> /etc/security/limits.conf'
sudo bash -c 'echo "DefaultLimitNOFILE=2000000" >> /etc/systemd/system.conf'
sudo bash -c 'echo "DefaultLimitNOFILE=2000000" >> /etc/systemd/user.conf'
sudo bash -c 'sysctl -p'

# code deploy agent install

sudo apt-get update -y
sudo apt-get install ruby-full -y
sudo apt-get install wget -y
wget https://aws-codedeploy-${region}.s3.${region}.amazonaws.com/latest/install
chmod +x ./install
sudo ./install auto > /tmp/logfile
echo "Codedeploy-Agent Status:"
sudo service codedeploy-agent status

#install postgresql-12 client

sudo add-apt-repository "deb http://security.ubuntu.com/ubuntu focal-security main" -y
sudo apt-get update -y

wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -
echo 'deb http://apt.postgresql.org/pub/repos/apt/ focal-pgdg main' | sudo tee /etc/apt/sources.list.d/pg.list

sudo apt-get update -y
sudo apt-get install postgresql-client-12 -y

echo "$(tput setaf 1)Configuring Postgres RDS$(tput sgr 0)"

echo "$(tput setaf 1)Setting update_docker_compose file$(tput sgr 0)"

sudo cp /home/ubuntu/ami-setup-kit/update_docker_compose.sh  /home/ubuntu/update_docker_compose.sh 

sudo chown ubuntu:ubuntu /home/ubuntu/update_docker_compose.sh

sudo chmod +x /home/ubuntu/update_docker_compose.sh

FILE="/etc/rc.local"
STRING="/home/ubuntu/update_docker_compose.sh"

if [ ! -f "$FILE" ]; then
  printf '%s\n' '#!/bin/bash' 'exit 0' | sudo tee -a /etc/rc.local
fi

if [ -z $(grep "$STRING" "$FILE") ]; then
  sudo sed -i "/exit 0/i$STRING" $FILE
fi

sudo chmod 755 /etc/rc.local
sudo systemctl restart rc-local
sudo systemctl status rc-local --no-pager

