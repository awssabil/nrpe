#!/bin/bash

FILE="/home/ubuntu/config"

if test -f "$FILE"; then
	source $FILE

	file_system_dns=$EfsHost                               
	efs_directory=/home/ubuntu/efs-$Type

	mkdir -p $efs_directory
	sudo mount -t nfs -o nfsvers=4.1,rsize=1048576,wsize=1048576,hard,timeo=600,retrans=2 $file_system_dns:/ $efs_directory

	sleep 5

	sudo cp /home/ubuntu/efs-$Type/dockerfiles/$DockerFileName /home/ubuntu/docker-compose.yml
fi