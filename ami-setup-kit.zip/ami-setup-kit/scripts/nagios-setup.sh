 #!/bin/bash 
 sudo apt update -y
 
 #Install 3rd parties dependencies and nagios packages
 sudo apt install -y autoconf bc gawk dc build-essential gcc libc6 make wget unzip apache2 php libapache2-mod-php libgd-dev libmcrypt-dev make libssl-dev snmp libnet-snmp-perl gettext
 cd ~/
 sudo wget https://github.com/NagiosEnterprises/nagioscore/archive/nagios-4.4.6.tar.gz
 sudo tar -xf nagios-4.4.6.tar.gz
 cd nagioscore-*/
 sudo ./configure --with-httpd-conf=/etc/apache2/sites-enabled
 sudo make all
 sudo make install-groups-users
 sudo make install
 sudo make install-daemoninit
 sudo make install-commandmode
 sudo make install-config
 sudo make install-webconf
 sudo a2enmod rewrite
 sudo a2enmod cgi
 sudo usermod -a -G nagios www-data
 sudo htpasswd -c -B -b /usr/local/nagios/etc/htpasswd.users nagiosadmin cloudbolt@123
 sudo systemctl restart apache2
 
 #Enable firewall
 sudo ufw allow Apache
 sudo ufw allow ssh
 
 #Configure nagios plugins
 sudo apt install monitoring-plugins nagios-nrpe-plugin -y
 cd /usr/local/nagios/etc
 sudo mkdir -p /usr/local/nagios/etc/servers
 sudo chmod 777 /usr/local/nagios/etc/nagios.cfg
 sudo echo "cfg_dir=/usr/local/nagios/etc/servers" >> /usr/local/nagios/etc/nagios.cfg
 sudo echo "cfg_file=/usr/local/nagios/etc/objects/kumo-templates.cfg" >> /usr/local/nagios/etc/nagios.cfg
 sudo echo "cfg_file=/usr/local/nagios/etc/objects/pagerduty_nagios.cfg" >> /usr/local/nagios/etc/nagios.cfg
 sudo chmod 755 /usr/local/nagios/etc/nagios.cfg
 cd /usr/local/nagios/share/
 sudo wget github.com/ynlamy/vautour-style/releases/latest/download/vautour_style.zip
 sudo unzip -o vautour_style.zip
 cd ~
 
 #Update nagios custom configuration
 sudo unzip /home/ubuntu/ami-setup-kit/scripts/kumo-conf.zip
 cd /home/ubuntu/ami-setup-kit/scripts/kumo-conf
 
 #Change config files with custom configurations
 sudo rm -f /usr/local/nagios/etc/objects/commands.cfg
 sudo rm -f /usr/local/nagios/etc/objects/contacts.cfg
 
 sudo mv *.cfg /usr/local/nagios/etc/objects/
 sudo mv arana_style/ /usr/local/nagios/
 sudo mv vautour_style/ /usr/local/nagios/
 sudo mv servers/* /usr/local/nagios/etc/servers/
 sudo mv libexec/* /usr/local/nagios/libexec/
 
 #Start and enable services
 sudo systemctl start nagios
 sudo systemctl enable nagios 

 #Mongo plugins Install
 cd /usr/local/nagios/libexec/
 sudo git clone https://github.com/mzupan/nagios-plugin-mongodb.git
 sudo chown -R nagios:nagios nagios-plugin-mongodb
 cd nagios-plugin-mongodb
 sudo cp check_mongodb.py ../
 cd ../
 sudo chown nagios:nagios check_mongodb.py
 cd 
 sudo wget --no-check-certificate https://github.com/mongodb/mongo-python-driver/archive/master.zip
 sudo unzip master.zip
 cd mongo-python-driver-master
 sudo apt-get install python3
 sudo apt-get install pip -y
 sudo python3 setup.py install
 sudo pip uninstall pymongo -y
 cd /usr/local/nagios/libexec/nagios-plugin-mongodb
 sudo pip install -r requirements 
 sudo service nagios restart

 #pagerduty_nagios
 cd 
 sudo wget https://raw.githubusercontent.com/mdcollins05/pd-nag-connector/master/pagerduty.cgi
 sudo mv pagerduty.cgi /usr/local/nagios/sbin/
 sudo chmod +x /usr/local/nagios/sbin/pagerduty.cgi
 sudo apt-get install libwww-perl libjson-perl
 sudo service nagios restart

 #pnp4_nagios
 cd
 sudo apt-get update
 sudo apt-get install -y rrdtool librrds-perl php-gd php-xml

 cd /tmp
 sudo wget -O pnp4nagios.tar.gz https://github.com/lingej/pnp4nagios/archive/0.6.26.tar.gz
 sudo tar xzf pnp4nagios.tar.gz

 cd pnp4nagios-0.6.26
 sudo ./configure --with-httpd-conf=/etc/apache2/sites-enabled
 sudo make all
 sudo make install
 sudo make install-webconf
 sudo make install-config
 sudo make install-init

 sudo systemctl daemon-reload
 sudo systemctl enable npcd.service
 sudo systemctl start npcd.service
 sudo systemctl restart apache2.service

 cd /usr/local/nagios/etc
 sudo cp nagios.cfg nagios.cfg-bkp-before-graph

 cd

 sudo sh -c "sed -i 's/process_performance_data=0/process_performance_data=1/g' /usr/local/nagios/etc/nagios.cfg"
 sudo sh -c "sed -i 's/#host_perfdata_file=/host_perfdata_file=/g' /usr/local/nagios/etc/nagios.cfg"
 sudo sh -c "sed -i 's/^host_perfdata_file=.*/host_perfdata_file=\/usr\/local\/pnp4nagios\/var\/service-perfdata/g' /usr/local/nagios/etc/nagios.cfg"
 sudo sh -c "sed -i 's/^#host_perfdata_file_template=.*/host_perfdata_file_template=DATATYPE::HOSTPERFDATA\\\\tTIMET::\$TIMET\$\\\\tHOSTNAME::\$HOSTNAME\$\\\\tHOSTPERFDATA::\$HOSTPERFDATA\$\\\\tHOSTCHECKCOMMAND::\$HOSTCHECKCOMMAND\$\\\\tHOSTSTATE::\$HOSTSTATE\$\\\\tHOSTSTATETYPE::\$HOSTSTATETYPE\$/g' /usr/local/nagios/etc/nagios.cfg"
 sudo sh -c "sed -i 's/#host_perfdata_file_mode=/host_perfdata_file_mode=/g' /usr/local/nagios/etc/nagios.cfg"
 sudo sh -c "sed -i 's/^#host_perfdata_file_processing_command=.*/host_perfdata_file_processing_command=process-host-perfdata-file-bulk-npcd/g' /usr/local/nagios/etc/nagios.cfg"
 sudo sh -c "sed -i 's/#service_perfdata_file=/service_perfdata_file=/g' /usr/local/nagios/etc/nagios.cfg"
 sudo sh -c "sed -i 's/^service_perfdata_file=.*/service_perfdata_file=\/usr\/local\/pnp4nagios\/var\/service-perfdata/g' /usr/local/nagios/etc/nagios.cfg"
 sudo sh -c "sed -i 's/#service_perfdata_file_mode=/service_perfdata_file_mode=/g' /usr/local/nagios/etc/nagios.cfg"
 sudo sh -c "sed -i 's/^#service_perfdata_file_processing_interval=.*/service_perfdata_file_processing_interval=15/g' /usr/local/nagios/etc/nagios.cfg"
 sudo sh -c "sed -i 's/^#service_perfdata_file_processing_command=.*/service_perfdata_file_processing_command=process-service-perfdata-file-bulk-npcd/g' /usr/local/nagios/etc/nagios.cfg"

 sudo cp /usr/local/nagios/etc/objects/commands.cfg /usr/local/nagios/etc/objects/commands.cfg-bkp

 sudo sh -c "echo '' >> /usr/local/nagios/etc/objects/commands.cfg"
 sudo sh -c "echo 'define command {' >> /usr/local/nagios/etc/objects/commands.cfg"
 sudo sh -c "echo ' command_name process-host-perfdata-file-bulk-npcd' >> /usr/local/nagios/etc/objects/commands.cfg"
 sudo sh -c "echo ' command_line /bin/mv /usr/local/pnp4nagios/var/host-perfdata /usr/local/pnp4nagios/var/spool/host-perfdata.\$TIMET\$' >> /usr/local/nagios/etc/objects/commands.cfg"
 sudo sh -c "echo ' }' >> /usr/local/nagios/etc/objects/commands.cfg"
 sudo sh -c "echo '' >> /usr/local/nagios/etc/objects/commands.cfg"
 sudo sh -c "echo 'define command {' >> /usr/local/nagios/etc/objects/commands.cfg"
 sudo sh -c "echo ' command_name process-service-perfdata-file-bulk-npcd' >> /usr/local/nagios/etc/objects/commands.cfg"
 sudo sh -c "echo ' command_line /bin/mv /usr/local/pnp4nagios/var/service-perfdata /usr/local/pnp4nagios/var/spool/service-perfdata.\$TIMET\$' >> /usr/local/nagios/etc/objects/commands.cfg"
 sudo sh -c "echo ' }' >> /usr/local/nagios/etc/objects/commands.cfg"
 sudo sh -c "echo '' >> /usr/local/nagios/etc/objects/commands.cfg"


 sudo systemctl restart nagios.service

 sudo mv /usr/local/pnp4nagios/share/install.php /usr/local/pnp4nagios/share/install.php-bkp

 sudo cp /usr/local/nagios/etc/objects/templates.cfg /usr/local/nagios/etc/objects/templates.cfg-bkp

 sudo sh -c "echo '' >> /usr/local/nagios/etc/objects/templates.cfg"
 sudo sh -c "echo 'define host {' >> /usr/local/nagios/etc/objects/templates.cfg"
 sudo sh -c "echo ' name host-pnp' >> /usr/local/nagios/etc/objects/templates.cfg"
 sudo sh -c "echo ' action_url /pnp4nagios/index.php/graph?host=\$HOSTNAME\$&srv=_HOST_' >> /usr/local/nagios/etc/objects/templates.cfg"
 sudo sh -c "echo ' register 0' >> /usr/local/nagios/etc/objects/templates.cfg"
 sudo sh -c "echo '}' >> /usr/local/nagios/etc/objects/templates.cfg"
 sudo sh -c "echo '' >> /usr/local/nagios/etc/objects/templates.cfg"
 sudo sh -c "echo 'define service {' >> /usr/local/nagios/etc/objects/templates.cfg"
 sudo sh -c "echo ' name service-pnp' >> /usr/local/nagios/etc/objects/templates.cfg"
 sudo sh -c "echo ' action_url /pnp4nagios/index.php/graph?host=\$HOSTNAME\$&srv=\$SERVICEDESC\$' >> /usr/local/nagios/etc/objects/templates.cfg"
 sudo sh -c "echo ' register 0' >> /usr/local/nagios/etc/objects/templates.cfg"
 sudo sh -c "echo '}' >> /usr/local/nagios/etc/objects/templates.cfg"
 sudo sh -c "echo '' >> /usr/local/nagios/etc/objects/templates.cfg"



 sudo sh -c "sed -i '/name.*generic-host/a\ use host-pnp' /usr/local/nagios/etc/objects/templates.cfg"
 sudo sh -c "sed -i '/name.*generic-service/a\ use service-pnp' /usr/local/nagios/etc/objects/templates.cfg"

 sudo systemctl restart nagios.service
