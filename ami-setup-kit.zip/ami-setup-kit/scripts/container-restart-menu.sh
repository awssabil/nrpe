#!/bin/bash

key='key.pem'
VPC='vpc-id'
region='region-alias'
filename='iplist.txt'
#command='bash update_docker_compose.sh'
command='docker-compose down && docker-compose up -d'

echo -e
echo -e "\033[37m ################################################### \033[0m \n"
echo -e "\033[34m \t   Container Restart Menu \033[35m  \t \n"
echo -e "\033[37m ################################################### \033[0m \n"
echo -e "  \t 1)  API-MASTER\n"
echo -e "  \t 2)  API\n"
echo -e "  \t 3)  REPORT-API\n"
echo -e "  \t 4)  API-SIDEKIQ-ALL\n"
echo -e "  \t 5)  REPORT-SIDEKIQ-ALL\n"
echo -e "  \t 6)  ALL-API & REPORT-CONTAINER\n"
echo -e "\033[37m ################################################### \033[0m"
echo -e

        read -r  -p ' Please enter your choice: ' choice;
        case $choice in

  1) aws ec2 describe-instances --filters "Name=vpc-id,Values=$VPC" --query 'Reservations[*].Instances[*].[InstanceId,State. Name,InstanceType,PrivateIpAddress,PublicIpAddress,Tags[?Key==`Name`].Value[]]' --region $region --output json | tr -d '\n[] "' | perl -pe 's/i-/\ni-/g' | tr ',' '\t' | sed -e 's/null/None/g' | grep API-MASTER | column -t | awk '{print $4}' > $filename 

          for ip in `cat $filename`
       do
   ssh -o "StrictHostKeyChecking no" -i $key ubuntu@$ip "sh -c '$command'"
done ;;

  2) aws ec2 describe-instances --filters "Name=vpc-id,Values=$VPC" --query 'Reservations[*].Instances[*].[InstanceId,State. Name,InstanceType,PrivateIpAddress,PublicIpAddress,Tags[?Key==`Name`].Value[]]' --region $region --output json | tr -d '\n[] "' | perl -pe 's/i-/\ni-/g' | tr ',' '\t' | sed -e 's/null/None/g' | grep APSE2-API-ASG | column -t | awk '{print $4}' > $filename
         
          for ip in `cat $filename`
do
   ssh -o "StrictHostKeyChecking no" -i $key ubuntu@$ip "sh -c '$command'"
done ;;

  3) aws ec2 describe-instances --filters "Name=vpc-id,Values=$VPC" --query 'Reservations[*].Instances[*].[InstanceId,State. Name,InstanceType,PrivateIpAddress,PublicIpAddress,Tags[?Key==`Name`].Value[]]' --region $region --output json | tr -d '\n[] "' | perl -pe 's/i-/\ni-/g' | tr ',' '\t' | sed -e 's/null/None/g' | grep APSE2-REPORT-API-ASG | column -t | awk '{print $4}' > $filename
         
         for ip in `cat $filename`
do
   ssh -o "StrictHostKeyChecking no" -i $key ubuntu@$ip "sh -c '$command'"
done ;;

  4) aws ec2 describe-instances --filters "Name=vpc-id,Values=$VPC" --query 'Reservations[*].Instances[*].[InstanceId,State. Name,InstanceType,PrivateIpAddress,PublicIpAddress,Tags[?Key==`Name`].Value[]]' --region $region --output json | tr -d '\n[] "' | perl -pe 's/i-/\ni-/g' | tr ',' '\t' | sed -e 's/null/None/g' | grep APSE2-API | awk '!/API-MASTER/' | awk '!/API-ASG/' |column -t | awk '{print $4}' > $filename
         
         for ip in `cat $filename`
do
   ssh -o "StrictHostKeyChecking no" -i $key ubuntu@$ip "sh -c '$command'"
done ;;

  5) aws ec2 describe-instances --filters "Name=vpc-id,Values=$VPC" --query 'Reservations[*].Instances[*].[InstanceId,State. Name,InstanceType,PrivateIpAddress,PublicIpAddress,Tags[?Key==`Name`].Value[]]' --region $region --output json | tr -d '\n[] "' | perl -pe 's/i-/\ni-/g' | tr ',' '\t' | sed -e 's/null/None/g' | grep APSE2-REPORT | awk '!/REPORT-API-ASG/' |column -t | awk '{print $4}' > $filename
         
         for ip in `cat $filename`
do
   ssh -o "StrictHostKeyChecking no" -i $key ubuntu@$ip "sh -c '$command'"
done ;;
  
  6) aws ec2 describe-instances --filters "Name=vpc-id,Values=$VPC" --query 'Reservations[*].Instances[*].[InstanceId,State. Name,InstanceType,PrivateIpAddress,PublicIpAddress,Tags[?Key==`Name`].Value[]]' --region $region --output json | tr -d '\n[] "' | perl -pe 's/i-/\ni-/g' | tr ',' '\t' | sed -e 's/null/None/g' | grep API-MASTER | column -t | awk '{print $4}' > $filename

        for ip in `cat $filename`
do
   ssh -o "StrictHostKeyChecking no" -i $key ubuntu@$ip "sh -c '$command'"
done
        sleep 10

    aws ec2 describe-instances --filters "Name=vpc-id,Values=$VPC" --query 'Reservations[*].Instances[*].[InstanceId,State. Name,InstanceType,PrivateIpAddress,PublicIpAddress,Tags[?Key==`Name`].Value[]]' --region $region --output json | tr -d '\n[] "' | perl -pe 's/i-/\ni-/g' | tr ',' '\t' | sed -e 's/null/None/g' | grep API-ASG | column -t | awk '{print $4}' > $filename

        for ip in `cat $filename`
do
   ssh -o "StrictHostKeyChecking no" -i $key ubuntu@$ip "sh -c '$command'"
done
        sleep 10

    aws ec2 describe-instances --filters "Name=vpc-id,Values=$VPC" --query 'Reservations[*].Instances[*].[InstanceId,State. Name,InstanceType,PrivateIpAddress,PublicIpAddress,Tags[?Key==`Name`].Value[]]' --region $region --output json | tr -d '\n[] "' | perl -pe 's/i-/\ni-/g' | tr ',' '\t' | sed -e 's/null/None/g' | grep ASG | awk '!/WEB/' | awk '!/API-MASTER/' | awk '!/API-ASG/' | awk '!/REPORT-API/' |column -t | awk '{print $4}' > $filename

        for ip in `cat $filename`
do
   ssh -o "StrictHostKeyChecking no" -i $key ubuntu@$ip "sh -c '$command'"
done ;;

  *) echo invalid option Bye Bye ;; 
esac

