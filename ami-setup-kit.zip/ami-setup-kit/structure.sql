SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_rights; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.access_rights (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(255),
    code character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.access_rights OWNER TO csmpdbuser;

--
-- Name: access_rights_user_roles; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.access_rights_user_roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    access_right_id uuid,
    user_role_id uuid
);


ALTER TABLE public.access_rights_user_roles OWNER TO csmpdbuser;

--
-- Name: account_gcp_multi_regions; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.account_gcp_multi_regions (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    account_id uuid,
    gcp_multi_regional_id uuid,
    enabled boolean,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.account_gcp_multi_regions OWNER TO csmpdbuser;

--
-- Name: account_regions; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.account_regions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    account_id uuid,
    region_id uuid,
    enabled boolean DEFAULT true,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    billing_stats json DEFAULT '[]'::json
);


ALTER TABLE public.account_regions OWNER TO csmpdbuser;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.accounts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    state character varying(255),
    accountable_objects integer DEFAULT 30,
    organisation_id uuid
);


ALTER TABLE public.accounts OWNER TO csmpdbuser;

--
-- Name: accounts_soe_scripts_remote_sources; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.accounts_soe_scripts_remote_sources (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    account_id uuid,
    soe_scripts_remote_source_id uuid
);


ALTER TABLE public.accounts_soe_scripts_remote_sources OWNER TO csmpdbuser;

--
-- Name: adapters; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.adapters (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    type character varying(255) NOT NULL,
    data public.hstore,
    account_id uuid,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    state character varying(255),
    name text,
    is_billing boolean DEFAULT false,
    ancestry character varying(255),
    adapter_purpose character varying(255) DEFAULT 'normal'::character varying,
    sync_running boolean DEFAULT false,
    not_supported_regions character varying[] DEFAULT '{}'::character varying[] NOT NULL,
    aws_support_discount double precision,
    aws_vat_percentage double precision,
    service_types_discount jsonb DEFAULT '{}'::jsonb,
    all_selected_flags jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.adapters OWNER TO csmpdbuser;

--
-- Name: adapters_machine_images; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.adapters_machine_images (
    adapter_id uuid,
    machine_image_id uuid
);


ALTER TABLE public.adapters_machine_images OWNER TO csmpdbuser;

--
-- Name: adapters_tasks; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.adapters_tasks (
    adapter_id uuid,
    task_id uuid,
    tenant_access boolean DEFAULT true
);


ALTER TABLE public.adapters_tasks OWNER TO csmpdbuser;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.admin_users (
    id bigint NOT NULL,
    name character varying,
    email character varying,
    username character varying,
    api_token character varying,
    password_digest character varying,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.admin_users OWNER TO csmpdbuser;

--
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: csmpdbuser
--

CREATE SEQUENCE public.admin_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_users_id_seq OWNER TO csmpdbuser;

--
-- Name: admin_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: csmpdbuser
--

ALTER SEQUENCE public.admin_users_id_seq OWNED BY public.admin_users.id;


--
-- Name: aggregates; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.aggregates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    available_capacity json,
    total_capacity json,
    state character varying(255),
    encryption_type character varying(255),
    filer_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.aggregates OWNER TO csmpdbuser;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.alerts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data json,
    read boolean DEFAULT false,
    read_at timestamp without time zone,
    alertable_type character varying(255),
    alert_type character varying(255),
    alertable_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.alerts OWNER TO csmpdbuser;

--
-- Name: ami_config_categories; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.ami_config_categories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    account_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.ami_config_categories OWNER TO csmpdbuser;

--
-- Name: app_access_secrets; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.app_access_secrets (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    encrypted_token text,
    description text,
    token_expires smallint,
    user_id uuid,
    organisation_id uuid,
    last_used timestamp without time zone,
    enabled boolean DEFAULT true,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.app_access_secrets OWNER TO csmpdbuser;

--
-- Name: application_plans; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.application_plans (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    description character varying(255),
    max_usage_allowed numrange,
    cost_percentage numeric(2,0),
    support_type character varying(255),
    trial_period_days integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.application_plans OWNER TO csmpdbuser;

--
-- Name: applications; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.applications (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    description text,
    account_id uuid,
    created_by_user_id uuid,
    updated_by_user_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    cost numeric(12,4) DEFAULT 0.0,
    max_amount integer,
    notify boolean,
    access_roles uuid[] DEFAULT '{}'::uuid[],
    notify_to uuid[] DEFAULT '{}'::uuid[]
);


ALTER TABLE public.applications OWNER TO csmpdbuser;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO csmpdbuser;

--
-- Name: associated_services; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.associated_services (
    name character varying(255) NOT NULL,
    service_type character varying(255) NOT NULL,
    associated_kumo_service_id uuid NOT NULL,
    kumo_service_id uuid NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL
);


ALTER TABLE public.associated_services OWNER TO csmpdbuser;

--
-- Name: availability_zones; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.availability_zones (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    zone_name character varying(255),
    region_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.availability_zones OWNER TO csmpdbuser;

--
-- Name: aws_accounts; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.aws_accounts (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    aws_account_id character varying,
    is_password_present boolean,
    allow_users_to_change_password boolean,
    expire_passwords boolean,
    hard_expiry boolean,
    max_password_age integer,
    minimum_password_length integer,
    password_reuse_prevention integer,
    require_lowercase_characters boolean,
    require_numbers boolean,
    require_symbols boolean,
    require_uppercase_characters boolean,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.aws_accounts OWNER TO csmpdbuser;

--
-- Name: aws_cloud_trails; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.aws_cloud_trails (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    running boolean,
    adapter_id uuid,
    last_trail_time timestamp without time zone,
    last_process_time timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.aws_cloud_trails OWNER TO csmpdbuser;

--
-- Name: aws_cloud_watch_logs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.aws_cloud_watch_logs (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    adapter_id uuid,
    region_id uuid,
    account_id uuid,
    aws_account_id character varying,
    region_code character varying,
    alarm_configured json,
    console_sign_in_without_mfa json,
    monitored_aws_organizations_changes json,
    authorization_failures_alarm_monitored json,
    cmk_configuration_changes_monitored json,
    alarm_configured_for_cloud_trail json,
    monitored_sign_in_failures json,
    monitored_ec2_instance_changes json,
    monitored_large_ec2_instances_changes json,
    monitored_iam_policy_changes json,
    monitored_igw_changes json,
    monitored_nacl_changes json,
    monitored_root_account json,
    monitored_route_table_changes json,
    monitored_s3_bucket_changes json,
    monitored_security_group_changes json,
    monitored_vpc_changes json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.aws_cloud_watch_logs OWNER TO csmpdbuser;

--
-- Name: aws_configs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.aws_configs (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    adapter_id uuid,
    region_id uuid,
    aws_account_id character varying,
    name character varying,
    role_arn character varying,
    s3_bucket_name character varying,
    configuration_recorders json,
    configuration_recorder_status json,
    delivery_channels json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    is_s3_bucket_missing boolean
);


ALTER TABLE public.aws_configs OWNER TO csmpdbuser;

--
-- Name: aws_iam_roles; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.aws_iam_roles (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    aws_account_id character varying,
    role_name character varying,
    path character varying,
    role_id character varying,
    arn character varying,
    create_date timestamp without time zone,
    assume_role_policy_document json,
    description character varying,
    max_session_duration integer,
    permissions_boundary json,
    tags json,
    role_last_used json,
    role_trust_policy json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    adapter_id uuid
);


ALTER TABLE public.aws_iam_roles OWNER TO csmpdbuser;

--
-- Name: aws_marketplace_saas_subscriptions; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.aws_marketplace_saas_subscriptions (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    customer_identifier character varying,
    status character varying,
    subscription_date timestamp without time zone,
    active boolean DEFAULT false,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.aws_marketplace_saas_subscriptions OWNER TO csmpdbuser;

--
-- Name: aws_organisations; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.aws_organisations (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    organisation_id character varying,
    adapter_id uuid,
    account_id uuid,
    aws_account_id character varying,
    arn character varying,
    feature_set character varying,
    master_account_arn character varying,
    master_account_id character varying,
    master_account_email character varying,
    available_policy_types json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.aws_organisations OWNER TO csmpdbuser;

--
-- Name: aws_records; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.aws_records (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data json,
    provider_vpc_id character varying(255),
    provider_id character varying(255),
    service_type character varying(255),
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    type character varying(255),
    cost_by_hour numeric(23,18) DEFAULT 0.0
);


ALTER TABLE public.aws_records OWNER TO csmpdbuser;

--
-- Name: aws_right_sizings; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.aws_right_sizings (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    aws_account_id character varying,
    region character varying,
    data json,
    cost_save_per_month double precision,
    price double precision,
    resize_price double precision,
    type character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    organisation_id character varying
);


ALTER TABLE public.aws_right_sizings OWNER TO csmpdbuser;

--
-- Name: aws_service_forecast_costs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.aws_service_forecast_costs (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    aws_account_id character varying,
    tab character varying,
    cost double precision,
    account_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    adapter_id uuid,
    net_cost double precision,
    margin_cost double precision,
    discount_cost double precision
);


ALTER TABLE public.aws_service_forecast_costs OWNER TO csmpdbuser;

--
-- Name: aws_trails; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.aws_trails (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    adapter_id uuid,
    region_id uuid,
    name character varying,
    cloud_watch_logs_log_group_arn character varying,
    cloud_watch_logs_role_arn character varying,
    home_region character varying,
    has_custom_event_selectors boolean,
    include_global_service_events boolean,
    is_multi_region_trail boolean,
    is_organization_trail boolean,
    kms_key_id character varying,
    log_file_validation_enabled boolean,
    s3_key_prefix character varying,
    s3_bucket_name character varying,
    sns_topic_name character varying,
    sns_topic_arn character varying,
    trail_arn character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    s3_bucket_server_access_logging boolean,
    provider_name character varying,
    aws_account_id character varying,
    data_resources json,
    latest_delivery_error character varying,
    include_management_events boolean,
    s3_lock_configuration json
);


ALTER TABLE public.aws_trails OWNER TO csmpdbuser;

--
-- Name: azure_availability_sets; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_availability_sets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    provider_id text,
    update_domain_count integer DEFAULT 1,
    fault_domain_count integer DEFAULT 1,
    managed boolean DEFAULT false,
    azure_resource_type character varying(255),
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid,
    resource_group_id uuid,
    kumo_service_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    depends_on character varying(255)[] DEFAULT '{}'::character varying[],
    virtual_machines text[] DEFAULT '{}'::text[]
);


ALTER TABLE public.azure_availability_sets OWNER TO csmpdbuser;

--
-- Name: azure_compliance_checks; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_compliance_checks (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    azure_compliance_standard_id uuid,
    check_id character varying,
    check_section character varying,
    check_sub_section character varying,
    check_rule text,
    description text,
    check_type character varying,
    file_name character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.azure_compliance_checks OWNER TO csmpdbuser;

--
-- Name: azure_compliance_policies; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_compliance_policies (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    azure_compliance_check_id uuid,
    display_name character varying,
    description text,
    name character varying,
    policy_id character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.azure_compliance_policies OWNER TO csmpdbuser;

--
-- Name: azure_compliance_standards; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_compliance_standards (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    standard_type character varying,
    standard_version character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.azure_compliance_standards OWNER TO csmpdbuser;

--
-- Name: azure_cost_summaries; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_cost_summaries (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    hourly_cost numeric(23,18) DEFAULT 0.0,
    usage_cost numeric(23,18) DEFAULT 0.0,
    kumo_service_id uuid,
    summary json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.azure_cost_summaries OWNER TO csmpdbuser;

--
-- Name: azure_disks; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_disks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    provider_id text,
    create_option character varying(255),
    image_reference json,
    azure_resource_type character varying(255),
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid,
    resource_group_id uuid,
    kumo_service_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    disk_size double precision,
    depends_on character varying(255)[] DEFAULT '{}'::character varying[],
    account_type character varying(255),
    os_type character varying(255),
    vhd_uri text,
    caching character varying(255),
    lun character varying(255),
    disk_type character varying(255)
);


ALTER TABLE public.azure_disks OWNER TO csmpdbuser;

--
-- Name: azure_export_configurations; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_export_configurations (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    name character varying,
    container character varying,
    directory character varying,
    subscription_id character varying,
    storage_account_id character varying,
    resource_group_name character varying,
    status boolean DEFAULT true,
    adapter_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    error_message text[] DEFAULT '{}'::text[],
    scope character varying DEFAULT 'Subscription'::character varying,
    billing_account_id character varying,
    scope_id character varying
);


ALTER TABLE public.azure_export_configurations OWNER TO csmpdbuser;

--
-- Name: azure_load_balancers; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_load_balancers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    provider_id text,
    frontend_ip_configurations json,
    backend_address_pools json,
    load_balancing_rules json,
    probes json,
    inbound_nat_rules json,
    outbound_nat_rules json,
    inbound_nat_pools json,
    azure_resource_type character varying(255),
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid,
    resource_group_id uuid,
    kumo_service_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    lb_type character varying(255),
    depends_on character varying(255)[] DEFAULT '{}'::character varying[]
);


ALTER TABLE public.azure_load_balancers OWNER TO csmpdbuser;

--
-- Name: azure_network_interfaces; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_network_interfaces (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    azure_resource_type character varying(255),
    ip_configurations json,
    enable_ip_forwarding boolean,
    dns_settings json,
    provider_id text,
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid,
    resource_group_id uuid,
    kumo_service_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    dns_servers json,
    applied_dns_servers character varying(255),
    mac_address character varying(255),
    depends_on character varying(255)[] DEFAULT '{}'::character varying[],
    security_group text
);


ALTER TABLE public.azure_network_interfaces OWNER TO csmpdbuser;

--
-- Name: azure_price_lists; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_price_lists (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    subscription_id uuid,
    sku_details json DEFAULT '[]'::json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    region_code character varying,
    resource_type character varying
);


ALTER TABLE public.azure_price_lists OWNER TO csmpdbuser;

--
-- Name: azure_public_ip_addresses; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_public_ip_addresses (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    azure_resource_type character varying(255),
    public_ipallocation_method character varying(255),
    idle_timeout_in_minutes integer,
    ip_address character varying(255),
    provider_id text,
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid,
    resource_group_id uuid,
    kumo_service_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    domain_name_label character varying(255),
    depends_on character varying(255)[] DEFAULT '{}'::character varying[]
);


ALTER TABLE public.azure_public_ip_addresses OWNER TO csmpdbuser;

--
-- Name: azure_rate_cards; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_rate_cards (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    rates jsonb DEFAULT '{}'::jsonb NOT NULL,
    subscription_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.azure_rate_cards OWNER TO csmpdbuser;

--
-- Name: azure_resource_connections; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_resource_connections (
    resource_id uuid,
    associated_resource_id uuid
);


ALTER TABLE public.azure_resource_connections OWNER TO csmpdbuser;

--
-- Name: azure_resource_groups; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_resource_groups (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    provider_id text,
    properties json,
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    tags json[] DEFAULT '{}'::json[],
    state character varying
);


ALTER TABLE public.azure_resource_groups OWNER TO csmpdbuser;

--
-- Name: azure_resources; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_resources (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    name character varying,
    type character varying,
    provider_id character varying,
    adapter_id uuid,
    region_id uuid,
    provider_data json DEFAULT '{}'::json NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    error_message character varying,
    additional_properties json DEFAULT '{}'::json NOT NULL,
    cost_by_hour numeric(15,10) DEFAULT 0.0,
    tags json[] DEFAULT '{}'::json[],
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    azure_resource_group_id uuid,
    state character varying,
    idle_instance boolean DEFAULT false,
    meter_data json[] DEFAULT '{}'::json[],
    ignored_from character varying[] DEFAULT '{un-ignored}'::character varying[] NOT NULL
);


ALTER TABLE public.azure_resources OWNER TO csmpdbuser;

--
-- Name: azure_rg_service_forecast_costs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_rg_service_forecast_costs (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    subscription_id character varying,
    adapter_id uuid,
    tab character varying,
    cost double precision,
    account_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    resource_group character varying,
    month character varying,
    currency character varying
);


ALTER TABLE public.azure_rg_service_forecast_costs OWNER TO csmpdbuser;

--
-- Name: azure_route_tables; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_route_tables (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    routes json,
    provider_id text,
    azure_resource_type character varying(255),
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid,
    resource_group_id uuid,
    kumo_service_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    depends_on character varying(255)[] DEFAULT '{}'::character varying[]
);


ALTER TABLE public.azure_route_tables OWNER TO csmpdbuser;

--
-- Name: azure_security_groups; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_security_groups (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    inbound_security_rules json,
    outbound_security_rules json,
    provider_id text,
    azure_resource_type character varying(255),
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid,
    resource_group_id uuid,
    kumo_service_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    depends_on character varying(255)[] DEFAULT '{}'::character varying[]
);


ALTER TABLE public.azure_security_groups OWNER TO csmpdbuser;

--
-- Name: azure_service_forecast_costs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_service_forecast_costs (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    subscription_id character varying,
    tab character varying,
    cost double precision,
    account_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    adapter_id uuid,
    month character varying,
    net_cost double precision,
    margin_cost double precision,
    discount_cost double precision,
    currency character varying
);


ALTER TABLE public.azure_service_forecast_costs OWNER TO csmpdbuser;

--
-- Name: azure_sql_db_servers; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_sql_db_servers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    provider_id text,
    azure_resource_type character varying(255),
    kind character varying(255),
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid,
    resource_group_id uuid,
    kumo_service_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    fully_qualified_domain_name character varying(255),
    administrator_login character varying(255),
    external_administrator_login character varying(255),
    external_administrator_sid character varying(255),
    version character varying(255),
    db_server_state character varying(255),
    depends_on character varying(255)[] DEFAULT '{}'::character varying[]
);


ALTER TABLE public.azure_sql_db_servers OWNER TO csmpdbuser;

--
-- Name: azure_sql_dbs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_sql_dbs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    provider_id text,
    azure_resource_type character varying(255),
    kind character varying(255),
    edition character varying(255),
    status character varying(255),
    service_level_objective character varying(255),
    "collation" character varying(255),
    creation_date timestamp without time zone,
    default_secondary_location character varying(255),
    earliest_restore_date timestamp without time zone,
    elastic_pool_name character varying(255),
    containment_state integer,
    read_scale character varying(255),
    failover_group_id text,
    max_size double precision,
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid,
    resource_group_id uuid,
    kumo_service_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    max_size_bytes character varying(255),
    sample_name character varying(255),
    depends_on character varying(255)[] DEFAULT '{}'::character varying[]
);


ALTER TABLE public.azure_sql_dbs OWNER TO csmpdbuser;

--
-- Name: azure_storage_accounts; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_storage_accounts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    provider_id text,
    azure_resource_type character varying(255),
    kind character varying(255),
    sku_name character varying(255),
    sku_tier character varying(255),
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid,
    resource_group_id uuid,
    kumo_service_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    depends_on character varying(255)[] DEFAULT '{}'::character varying[]
);


ALTER TABLE public.azure_storage_accounts OWNER TO csmpdbuser;

--
-- Name: azure_subnets; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_subnets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    address_prefix character varying(255),
    provider_id text,
    azure_resource_type character varying(255),
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid,
    resource_group_id uuid,
    kumo_service_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    depends_on character varying(255)[] DEFAULT '{}'::character varying[],
    security_group text,
    route_table text
);


ALTER TABLE public.azure_subnets OWNER TO csmpdbuser;

--
-- Name: azure_subscriptions; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_subscriptions (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    display_name character varying,
    subscription_id uuid,
    adapter_id uuid,
    subscription_policies json,
    authorization_source character varying,
    state character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.azure_subscriptions OWNER TO csmpdbuser;

--
-- Name: azure_tenant_billing_adapters; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_tenant_billing_adapters (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    organisation_id uuid,
    tenant_id uuid,
    billing_adapter_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    is_total_selected boolean DEFAULT false
);


ALTER TABLE public.azure_tenant_billing_adapters OWNER TO csmpdbuser;

--
-- Name: azure_usage_costs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_usage_costs (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    start_datetime timestamp without time zone,
    end_datetime timestamp without time zone,
    aggregate_usage_cost json,
    subscription_id uuid,
    aggregation_granularity character varying,
    show_details character varying,
    api_version character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.azure_usage_costs OWNER TO csmpdbuser;

--
-- Name: azure_virtual_machines; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_virtual_machines (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    provider_id text,
    vm_size character varying(255),
    network_interfaces text[] DEFAULT '{}'::text[],
    availability_set text,
    os_profile json,
    publisher character varying(255),
    offer character varying(255),
    sku character varying(255),
    version character varying(255),
    azure_resource_type character varying(255),
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid,
    resource_group_id uuid,
    kumo_service_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    operating_system character varying(255),
    diagnostics_profile json,
    depends_on character varying(255)[] DEFAULT '{}'::character varying[],
    filer_volumes json DEFAULT '{}'::json
);


ALTER TABLE public.azure_virtual_machines OWNER TO csmpdbuser;

--
-- Name: azure_vnets; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.azure_vnets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    address_prefixes character varying(255)[] DEFAULT '{}'::character varying[],
    provider_id text,
    azure_resource_type character varying(255),
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid,
    resource_group_id uuid,
    kumo_service_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    depends_on character varying(255)[] DEFAULT '{}'::character varying[]
);


ALTER TABLE public.azure_vnets OWNER TO csmpdbuser;

--
-- Name: backup_policies; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.backup_policies (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    environment_ids uuid[] DEFAULT '{}'::uuid[],
    backupable_services json DEFAULT '{}'::json,
    region_id uuid,
    adapter_id uuid,
    account_id uuid,
    created_by_user_id uuid,
    updated_by_user_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    data json DEFAULT '{}'::json,
    is_bunker_option boolean,
    is_source_copy boolean,
    is_backup_retention boolean,
    retention_period character varying
);


ALTER TABLE public.backup_policies OWNER TO csmpdbuser;

--
-- Name: billing_currencies; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.billing_currencies (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    type character varying,
    currency character varying,
    symbol character varying,
    adapter_id uuid,
    is_default boolean DEFAULT false
);


ALTER TABLE public.billing_currencies OWNER TO csmpdbuser;

--
-- Name: cloud_resource_adapters; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.cloud_resource_adapters (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    endpoint character varying(255),
    credentials json,
    account_id uuid,
    type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.cloud_resource_adapters OWNER TO csmpdbuser;

--
-- Name: clusters; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.clusters (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data json,
    provider_data json,
    error_message text,
    state character varying(255),
    provider_id character varying(255),
    archived boolean DEFAULT false,
    type character varying(255),
    account_id uuid,
    region_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    environment_id uuid
);


ALTER TABLE public.clusters OWNER TO csmpdbuser;

--
-- Name: clusters_environments; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.clusters_environments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    environment_id uuid,
    cluster_id uuid
);


ALTER TABLE public.clusters_environments OWNER TO csmpdbuser;

--
-- Name: compliance_checks; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.compliance_checks (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    compliance_standard_id uuid,
    check_id character varying,
    check_section character varying,
    check_sub_section character varying,
    check_rule text,
    check_type character varying,
    check_automated boolean DEFAULT false,
    check_kumo_ids text[] DEFAULT '{}'::text[],
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    description text
);


ALTER TABLE public.compliance_checks OWNER TO csmpdbuser;

--
-- Name: compliance_standards; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.compliance_standards (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    standard_type character varying,
    standard_version character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.compliance_standards OWNER TO csmpdbuser;

--
-- Name: connections; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.connections (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    interface_id uuid,
    remote_interface_id uuid,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    internal boolean DEFAULT false
);


ALTER TABLE public.connections OWNER TO csmpdbuser;

--
-- Name: cost_summaries; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.cost_summaries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    blended_cost numeric(15,5) DEFAULT 0.0,
    unblended_cost numeric(15,5) DEFAULT 0.0,
    date date,
    environment_id uuid,
    account_id uuid,
    adapter_id uuid,
    type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.cost_summaries OWNER TO csmpdbuser;

--
-- Name: costs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.costs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    blended_cost double precision,
    unblended_cost double precision,
    availability_zone character varying(255),
    resource_id character varying(255),
    resource_type character varying(255),
    date date,
    type character varying(255),
    service_id uuid,
    environment_id uuid,
    account_id uuid,
    adapter_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.costs OWNER TO csmpdbuser;

--
-- Name: credit_cards; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.credit_cards (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    card_holder character varying(255),
    card_number character varying(255),
    card_expiry date,
    token character varying(255),
    response_data public.hstore,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.credit_cards OWNER TO csmpdbuser;

--
-- Name: currency_configurations; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.currency_configurations (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    cloud_provider_currency character varying,
    default_currency character varying,
    exchange_rates json,
    organisation_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    provider character varying
);


ALTER TABLE public.currency_configurations OWNER TO csmpdbuser;

--
-- Name: custom_dashboards; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.custom_dashboards (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    name character varying,
    "dashboardHeight" integer,
    type character varying,
    widgets text,
    organisation_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id uuid,
    shared_with_roles character varying[] DEFAULT '{}'::character varying[],
    shared_with character varying[] DEFAULT '{}'::character varying[],
    shared_at public.hstore
);


ALTER TABLE public.custom_dashboards OWNER TO csmpdbuser;

--
-- Name: dashboard_data; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.dashboard_data (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    account_id uuid,
    name character varying(255),
    data json,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.dashboard_data OWNER TO csmpdbuser;

--
-- Name: email_notifications; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.email_notifications (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    name character varying,
    notify boolean DEFAULT false,
    notify_using_tag boolean DEFAULT false,
    append_domain boolean DEFAULT false,
    custom_emails character varying[] DEFAULT '{}'::character varying[],
    notification_roles character varying[] DEFAULT '{}'::character varying[],
    notification_users character varying[] DEFAULT '{}'::character varying[],
    notify_condition json DEFAULT '{}'::json,
    service_ids character varying[] DEFAULT '{}'::character varying[],
    type character varying,
    account_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    creater uuid,
    service_type character varying[] DEFAULT '{}'::character varying[],
    severity character varying[] DEFAULT '{}'::character varying[],
    notify_to_tag_key character varying,
    adapter_id uuid,
    tenant_id uuid
);


ALTER TABLE public.email_notifications OWNER TO csmpdbuser;

--
-- Name: email_templates; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.email_templates (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    type character varying,
    subject character varying,
    body character varying,
    link character varying,
    data json,
    account_id uuid,
    organisation_id uuid,
    template_type integer
);


ALTER TABLE public.email_templates OWNER TO csmpdbuser;

--
-- Name: encryption_keys; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.encryption_keys (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    key_alias character varying(255),
    description character varying(255),
    key_id character varying(255),
    arn character varying(255),
    enabled boolean,
    key_usage character varying(255),
    aws_account_id character varying(255),
    creation_date timestamp without time zone,
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    state character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    key_state character varying,
    key_enabled boolean,
    key_rotation_enabled boolean,
    key_policy_exposed boolean,
    key_policy json
);


ALTER TABLE public.encryption_keys OWNER TO csmpdbuser;

--
-- Name: environment_adapters; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.environment_adapters (
    id uuid NOT NULL,
    environment_id uuid,
    adapter_id uuid
);


ALTER TABLE public.environment_adapters OWNER TO csmpdbuser;

--
-- Name: environment_filer_volumes; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.environment_filer_volumes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    environment_id uuid,
    filer_volume_id uuid
);


ALTER TABLE public.environment_filer_volumes OWNER TO csmpdbuser;

--
-- Name: environment_jobs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.environment_jobs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    environment_id uuid,
    job_id uuid,
    action character varying(255)
);


ALTER TABLE public.environment_jobs OWNER TO csmpdbuser;

--
-- Name: environment_kumo_services; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.environment_kumo_services (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    environment_id uuid,
    kumo_service_id uuid
);


ALTER TABLE public.environment_kumo_services OWNER TO csmpdbuser;

--
-- Name: environment_services; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.environment_services (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    environment_id uuid,
    service_id uuid
);


ALTER TABLE public.environment_services OWNER TO csmpdbuser;

--
-- Name: environment_storages; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.environment_storages (
    id integer NOT NULL,
    storage_id uuid,
    environment_id uuid
);


ALTER TABLE public.environment_storages OWNER TO csmpdbuser;

--
-- Name: environment_storages_id_seq; Type: SEQUENCE; Schema: public; Owner: csmpdbuser
--

CREATE SEQUENCE public.environment_storages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.environment_storages_id_seq OWNER TO csmpdbuser;

--
-- Name: environment_storages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: csmpdbuser
--

ALTER SEQUENCE public.environment_storages_id_seq OWNED BY public.environment_storages.id;


--
-- Name: environment_tags; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.environment_tags (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    environment_id uuid,
    tag_key character varying(255),
    tag_type character varying(255),
    tag_value character varying(255),
    is_mandatory boolean DEFAULT false,
    account_id uuid,
    created_by uuid,
    updated_by uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    applied_type character varying(255) DEFAULT 'Provider'::character varying,
    selected_type integer DEFAULT 2,
    applicable_services character varying(255)[] DEFAULT '{}'::character varying[],
    overridable_services character varying(255)[] DEFAULT '{}'::character varying[],
    description text,
    override_service_tags boolean DEFAULT false,
    data json,
    apply_naming_param boolean DEFAULT false
);


ALTER TABLE public.environment_tags OWNER TO csmpdbuser;

--
-- Name: environment_vpcs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.environment_vpcs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    environment_id uuid,
    vpc_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.environment_vpcs OWNER TO csmpdbuser;

--
-- Name: environments; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.environments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text,
    state text NOT NULL,
    template_id uuid,
    account_id uuid NOT NULL,
    default_adapter_id uuid,
    locked boolean DEFAULT false,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    desired_state text,
    key_id uuid,
    friendly_id text,
    region_id uuid,
    application_id uuid,
    "position" integer,
    created_by uuid,
    updated_by uuid,
    environment_model json,
    tag_id uuid,
    user_role_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    data json DEFAULT '{}'::json,
    revision double precision DEFAULT 1.0,
    description text DEFAULT ''::text,
    subscription_id uuid
);


ALTER TABLE public.environments OWNER TO csmpdbuser;

--
-- Name: environments_tasks; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.environments_tasks (
    id integer NOT NULL,
    environment_id uuid,
    task_id uuid
);


ALTER TABLE public.environments_tasks OWNER TO csmpdbuser;

--
-- Name: environments_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: csmpdbuser
--

CREATE SEQUENCE public.environments_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.environments_tasks_id_seq OWNER TO csmpdbuser;

--
-- Name: environments_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: csmpdbuser
--

ALTER SEQUENCE public.environments_tasks_id_seq OWNED BY public.environments_tasks.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data json,
    type text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    account_id uuid NOT NULL
);


ALTER TABLE public.events OWNER TO csmpdbuser;

--
-- Name: filer_configurations; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.filer_configurations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    region_id uuid,
    adapter_id uuid,
    account_id uuid,
    security_group_id uuid,
    vpc_id uuid,
    filer_id uuid,
    protocol character varying(255),
    name character varying(255),
    type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    storage_vm_id uuid
);


ALTER TABLE public.filer_configurations OWNER TO csmpdbuser;

--
-- Name: filer_services; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.filer_services (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    filer_id uuid,
    service_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.filer_services OWNER TO csmpdbuser;

--
-- Name: filer_volumes; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.filer_volumes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    svm_name character varying(255),
    root_volume boolean DEFAULT false,
    state character varying(255),
    provider_volume_type character varying(255),
    data json,
    filer_id uuid,
    cloud_resource_adapter_id uuid,
    account_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    type character varying(255),
    actual_protocol character varying(255),
    error_message text,
    export_policy_info json DEFAULT '{"policy_type":"none","ips":[]}'::json,
    snapshot_policy text DEFAULT 'none'::text,
    size_info json DEFAULT '{"size":1,"unit":"GB"}'::json,
    thin_provisioning boolean DEFAULT false,
    deduplication boolean DEFAULT false,
    compression boolean DEFAULT false,
    aggregate_name text,
    share_name text,
    access json,
    aggregate_id uuid,
    kumo_service_id uuid
);


ALTER TABLE public.filer_volumes OWNER TO csmpdbuser;

--
-- Name: filers; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.filers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    data json,
    cloud_resource_adapter_id uuid,
    account_id uuid,
    type character varying(255),
    public_id character varying(255),
    name character varying(255),
    tenant_id character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    enabled boolean DEFAULT true,
    working_environment_type character varying(255),
    cloud_provider_name character varying
);


ALTER TABLE public.filers OWNER TO csmpdbuser;

--
-- Name: follow_up_email_histories; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.follow_up_email_histories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    follow_up_email_id uuid,
    scheduled_at timestamp without time zone,
    processed_at timestamp without time zone,
    status boolean DEFAULT false,
    process_status boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    event_type character varying(255)
);


ALTER TABLE public.follow_up_email_histories OWNER TO csmpdbuser;

--
-- Name: follow_up_emails; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.follow_up_emails (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    account_id uuid,
    followup_for character varying(255),
    status boolean DEFAULT true,
    start_at timestamp without time zone DEFAULT '2017-07-25 10:39:24.619364'::timestamp without time zone,
    finish_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.follow_up_emails OWNER TO csmpdbuser;

--
-- Name: gcp_compute_pricings; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.gcp_compute_pricings (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    name character varying,
    sku character varying,
    description character varying,
    service_name character varying,
    resource_family character varying,
    resource_group character varying,
    usage_type character varying,
    pricing_info jsonb DEFAULT '[]'::jsonb,
    service_regions text[] DEFAULT '{}'::text[],
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.gcp_compute_pricings OWNER TO csmpdbuser;

--
-- Name: gcp_multi_regionals; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.gcp_multi_regionals (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    name character varying,
    code character varying,
    adapter_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.gcp_multi_regionals OWNER TO csmpdbuser;

--
-- Name: gcp_report_configurations; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.gcp_report_configurations (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    status boolean DEFAULT true,
    adapter_id uuid,
    error_message text[] DEFAULT '{}'::text[],
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.gcp_report_configurations OWNER TO csmpdbuser;

--
-- Name: gcp_resource_zones; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.gcp_resource_zones (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    zone_name character varying,
    code character varying,
    region_id uuid,
    adapter_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.gcp_resource_zones OWNER TO csmpdbuser;

--
-- Name: gcp_resources; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.gcp_resources (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    name character varying,
    type character varying,
    provider_id character varying,
    provider_data json DEFAULT '{}'::json NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    error_message character varying,
    additional_properties json DEFAULT '{}'::json NOT NULL,
    cost_by_hour numeric(15,10) DEFAULT 0.0,
    tags json[] DEFAULT '{}'::json[],
    state character varying,
    idle_instance boolean DEFAULT false,
    meter_data json[] DEFAULT '{}'::json[],
    ignored_from character varying[] DEFAULT '{un-ignored}'::character varying[] NOT NULL,
    adapter_id uuid,
    region_id uuid,
    gcp_resource_zone_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    gcp_multi_regional_id uuid
);


ALTER TABLE public.gcp_resources OWNER TO csmpdbuser;

--
-- Name: gcp_service_forecast_costs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.gcp_service_forecast_costs (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    tab character varying,
    cost double precision,
    account_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    adapter_id uuid,
    project_id character varying,
    month character varying
);


ALTER TABLE public.gcp_service_forecast_costs OWNER TO csmpdbuser;

--
-- Name: gcp_tenant_billing_adapters; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.gcp_tenant_billing_adapters (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    organisation_id uuid,
    tenant_id uuid,
    billing_adapter_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.gcp_tenant_billing_adapters OWNER TO csmpdbuser;

--
-- Name: general_settings; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.general_settings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    naming_convention_enabled boolean DEFAULT false,
    account_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    ip_auto_increment_enabled boolean DEFAULT true,
    applicationwise_monthly_budget boolean DEFAULT true,
    email_domain character varying,
    is_tag_case_insensitive boolean DEFAULT true,
    time_zone json DEFAULT '{"region":"Australia","org_time_zone":"Brisbane"}'::json,
    default_tenant_visibility boolean DEFAULT true
);


ALTER TABLE public.general_settings OWNER TO csmpdbuser;

--
-- Name: group_roles; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.group_roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    resource_id uuid,
    resource_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.group_roles OWNER TO csmpdbuser;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.groups (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text,
    organisation_id uuid,
    account_id uuid,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.groups OWNER TO csmpdbuser;

--
-- Name: groups_roles; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.groups_roles (
    group_id uuid,
    group_role_id uuid
);


ALTER TABLE public.groups_roles OWNER TO csmpdbuser;

--
-- Name: groups_users; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.groups_users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    group_id uuid
);


ALTER TABLE public.groups_users OWNER TO csmpdbuser;

--
-- Name: iam_certificates; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.iam_certificates (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    path character varying,
    server_certificate_name character varying,
    server_certificate_id character varying,
    arn character varying,
    upload_date timestamp without time zone,
    expiration timestamp without time zone,
    aws_account_id character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    account_id uuid
);


ALTER TABLE public.iam_certificates OWNER TO csmpdbuser;

--
-- Name: iam_groups; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.iam_groups (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    adapter_id uuid,
    account_id uuid,
    group_id character varying,
    arn character varying,
    group_name character varying,
    create_date character varying,
    aws_account_id character varying,
    path character varying,
    users json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    list_group_policies json
);


ALTER TABLE public.iam_groups OWNER TO csmpdbuser;

--
-- Name: iam_roles; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.iam_roles (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    aws_account_id character varying,
    role character varying,
    arn character varying,
    instance_profile_id character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.iam_roles OWNER TO csmpdbuser;

--
-- Name: iam_user_role_policies; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.iam_user_role_policies (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    policy_id uuid,
    iam_id uuid,
    iam_type character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    adapter_id uuid,
    aws_account_id character varying
);


ALTER TABLE public.iam_user_role_policies OWNER TO csmpdbuser;

--
-- Name: iam_users; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.iam_users (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    path character varying,
    user_name character varying,
    user_id character varying,
    arn character varying,
    create_date timestamp without time zone,
    password_last_used timestamp without time zone,
    permissions_boundary character varying,
    tags text[] DEFAULT '{}'::text[],
    password_enabled boolean,
    password_last_changed timestamp without time zone,
    password_next_rotation timestamp without time zone,
    mfa_active boolean,
    access_key_1_active boolean,
    access_key_1_last_rotated timestamp without time zone,
    access_key_1_last_used_date timestamp without time zone,
    access_key_1_last_used_region character varying,
    access_key_1_last_used_service character varying,
    access_key_2_active boolean,
    access_key_2_last_rotated timestamp without time zone,
    access_key_2_last_used_date timestamp without time zone,
    access_key_2_last_used_region character varying,
    access_key_2_last_used_service character varying,
    cert_1_active boolean,
    cert_1_last_rotated timestamp without time zone,
    cert_2_active boolean,
    cert_2_last_rotated timestamp without time zone,
    aws_account_id character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    adapter_id uuid,
    ssh_public_keys json,
    access_keys_list json,
    login_profile json,
    list_mfa_devices json,
    virtual_mfa_devices json
);


ALTER TABLE public.iam_users OWNER TO csmpdbuser;

--
-- Name: instance_filer_volumes; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.instance_filer_volumes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    service_id uuid,
    filer_volume_id uuid
);


ALTER TABLE public.instance_filer_volumes OWNER TO csmpdbuser;

--
-- Name: instance_planners; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.instance_planners (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    account_id uuid,
    region_id uuid,
    adapter_id uuid,
    total_instances integer,
    active_standard integer,
    active_scheduled integer,
    unused_standard integer,
    unused_scheduled integer,
    ec2_covered integer,
    ec2_uncovered integer,
    potential_benifit double precision,
    data json,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.instance_planners OWNER TO csmpdbuser;

--
-- Name: integration_user_roles; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.integration_user_roles (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    integration_id uuid,
    user_role_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.integration_user_roles OWNER TO csmpdbuser;

--
-- Name: integrations; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.integrations (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    name character varying,
    user_id uuid,
    account_id uuid,
    workspace_id uuid,
    organisation_id uuid,
    data jsonb DEFAULT '{}'::jsonb,
    slack_members text[] DEFAULT '{}'::text[],
    modules text[] DEFAULT '{}'::text[],
    type character varying,
    state integer DEFAULT 0,
    is_mute boolean DEFAULT false,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    all_roles_selected boolean
);


ALTER TABLE public.integrations OWNER TO csmpdbuser;

--
-- Name: interfaces; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.interfaces (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    service_id uuid,
    name text,
    interface_type text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    depends boolean
);


ALTER TABLE public.interfaces OWNER TO csmpdbuser;

--
-- Name: internet_gateways; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.internet_gateways (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    state character varying(255),
    type character varying(255),
    provider_id character varying(255),
    provider_data json,
    vpc_id uuid,
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.internet_gateways OWNER TO csmpdbuser;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.invoices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    payment_due_date timestamp without time zone,
    payment_date timestamp without time zone,
    payment_status character varying(255) DEFAULT 'pending'::character varying,
    data json,
    account_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    invoice_number integer NOT NULL
);


ALTER TABLE public.invoices OWNER TO csmpdbuser;

--
-- Name: invoices_invoice_number_seq; Type: SEQUENCE; Schema: public; Owner: csmpdbuser
--

CREATE SEQUENCE public.invoices_invoice_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoices_invoice_number_seq OWNER TO csmpdbuser;

--
-- Name: invoices_invoice_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: csmpdbuser
--

ALTER SEQUENCE public.invoices_invoice_number_seq OWNED BY public.invoices.invoice_number;


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.jobs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    log_id uuid,
    state text,
    bg_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.jobs OWNER TO csmpdbuser;

--
-- Name: kumo_services; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.kumo_services (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    service_type character varying(255) NOT NULL,
    state character varying(255) NOT NULL,
    provider_id text NOT NULL,
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    metadata json DEFAULT '{}'::json,
    error_message text
);


ALTER TABLE public.kumo_services OWNER TO csmpdbuser;

--
-- Name: kumo_services_tag_key_values; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.kumo_services_tag_key_values (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    kumo_service_id uuid,
    tag_key_value_id uuid
);


ALTER TABLE public.kumo_services_tag_key_values OWNER TO csmpdbuser;

--
-- Name: logs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    job_id uuid,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.logs OWNER TO csmpdbuser;

--
-- Name: machine_image_configurations; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.machine_image_configurations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organisation_image_id integer,
    name character varying(255),
    userdata text,
    user_role_ids uuid[] DEFAULT '{}'::uuid[],
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    instance_types character varying(255)[] DEFAULT '{}'::character varying[] NOT NULL,
    account_id uuid,
    is_template boolean DEFAULT false,
    ami_config_category_id uuid,
    rundata text
);


ALTER TABLE public.machine_image_configurations OWNER TO csmpdbuser;

--
-- Name: machine_image_configurations_soe_scripts; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.machine_image_configurations_soe_scripts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    machine_image_configuration_id uuid,
    soe_script_id uuid,
    soe_script_type character varying(255)
);


ALTER TABLE public.machine_image_configurations_soe_scripts OWNER TO csmpdbuser;

--
-- Name: machine_image_groups; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.machine_image_groups (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    match_key character varying(255),
    virtualization_type character varying(255),
    image_owner_alias character varying(255),
    root_device_type character varying(255),
    image_owner_id character varying(255),
    architecture character varying(255),
    image_type character varying(255),
    is_public character varying(255),
    platform character varying(255),
    region_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.machine_image_groups OWNER TO csmpdbuser;

--
-- Name: machine_images; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.machine_images (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    adapter_id uuid,
    region_id uuid,
    architecture character varying(255),
    description character varying(255),
    image_id character varying(255),
    image_location character varying(255),
    image_state character varying(255),
    image_type character varying(255),
    is_public character varying(255),
    kernel_id character varying(255),
    platform character varying(255),
    ramdisk_id character varying(255),
    root_device_name character varying(255),
    root_device_type character varying(255),
    virtualization_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    block_device_mapping text,
    image_owner_alias character varying(255),
    image_owner_id character varying(255),
    product_codes text,
    active boolean DEFAULT true,
    name character varying(255),
    machine_image_group_id uuid,
    creation_date timestamp without time zone,
    cost_by_hour numeric(23,18) DEFAULT 0.0,
    service_tags json,
    aws_account_id character varying[] DEFAULT '{}'::character varying[]
);


ALTER TABLE public.machine_images OWNER TO csmpdbuser;

--
-- Name: nacls; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.nacls (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    provider_id character varying(255),
    provider_vpc_id character varying(255),
    name character varying(255),
    vpc_id uuid,
    entries json DEFAULT '{}'::json,
    associations json DEFAULT '{}'::json,
    tags json DEFAULT '{}'::json,
    type character varying(255),
    adapter_id uuid,
    provider_data json,
    account_id uuid,
    region_id uuid
);


ALTER TABLE public.nacls OWNER TO csmpdbuser;

--
-- Name: network_interfaces; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.network_interfaces (
    id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.network_interfaces OWNER TO csmpdbuser;

--
-- Name: network_interfaces_id_seq; Type: SEQUENCE; Schema: public; Owner: csmpdbuser
--

CREATE SEQUENCE public.network_interfaces_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.network_interfaces_id_seq OWNER TO csmpdbuser;

--
-- Name: network_interfaces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: csmpdbuser
--

ALTER SEQUENCE public.network_interfaces_id_seq OWNED BY public.network_interfaces.id;


--
-- Name: organisation_adapters; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.organisation_adapters (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    organisation_id uuid,
    adapter_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.organisation_adapters OWNER TO csmpdbuser;

--
-- Name: organisation_brands; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.organisation_brands (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    organisation_id uuid,
    name character varying,
    product_name text,
    child_organisation_domain character varying,
    documentation_url character varying,
    support_url character varying,
    login_page_title text,
    login_page_tagline text,
    login_page_background_image_position character varying,
    login_page_background_image_overlay_color character varying,
    login_text_color character varying,
    show_privacy_policy_url boolean,
    privacy_policy_url character varying,
    privacy_policy_url_name character varying,
    show_terms_of_use_url boolean,
    terms_of_use_url character varying,
    terms_of_use_url_name character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    company_logo_public_url character varying,
    fevicon_public_url character varying,
    navigation_logo_public_url character varying,
    login_page_logo_public_url character varying,
    login_page_background_image_public_url character varying
);


ALTER TABLE public.organisation_brands OWNER TO csmpdbuser;

--
-- Name: organisation_details; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.organisation_details (
    id bigint NOT NULL,
    data json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.organisation_details OWNER TO csmpdbuser;

--
-- Name: organisation_details_id_seq; Type: SEQUENCE; Schema: public; Owner: csmpdbuser
--

CREATE SEQUENCE public.organisation_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organisation_details_id_seq OWNER TO csmpdbuser;

--
-- Name: organisation_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: csmpdbuser
--

ALTER SEQUENCE public.organisation_details_id_seq OWNED BY public.organisation_details.id;


--
-- Name: organisation_images; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.organisation_images (
    account_id uuid,
    machine_image_id uuid,
    image_id character varying(255),
    region_id uuid,
    instance_types text,
    image_name text,
    image_data json,
    id integer NOT NULL,
    active boolean DEFAULT true,
    user_role_ids uuid[] DEFAULT '{}'::uuid[],
    machine_image_group_id uuid,
    ejectable boolean DEFAULT true NOT NULL,
    architecture character varying,
    description text,
    image_location character varying,
    image_type character varying,
    kernel_id character varying,
    platform character varying,
    ramdisk_id character varying,
    root_device_name character varying,
    root_device_type character varying,
    virtualization_type character varying,
    block_device_mapping text,
    image_owner_alias character varying,
    image_owner_id character varying,
    product_codes text,
    machine_image_name character varying,
    creation_date timestamp without time zone,
    is_public boolean,
    cost_by_hour numeric(23,18) DEFAULT 0.0,
    image_state character varying,
    updated_at timestamp without time zone,
    aws_account_id character varying[] DEFAULT '{}'::character varying[]
);


ALTER TABLE public.organisation_images OWNER TO csmpdbuser;

--
-- Name: organisation_images_id_seq; Type: SEQUENCE; Schema: public; Owner: csmpdbuser
--

CREATE SEQUENCE public.organisation_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organisation_images_id_seq OWNER TO csmpdbuser;

--
-- Name: organisation_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: csmpdbuser
--

ALTER SEQUENCE public.organisation_images_id_seq OWNED BY public.organisation_images.id;


--
-- Name: organisation_images_copy; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.organisation_images_copy (
    account_id uuid,
    machine_image_id uuid,
    image_id character varying(255),
    region_id uuid,
    instance_types text,
    image_name text,
    image_data json,
    id integer DEFAULT nextval('public.organisation_images_id_seq'::regclass) NOT NULL,
    active boolean
);


ALTER TABLE public.organisation_images_copy OWNER TO csmpdbuser;

--
-- Name: organisation_saml_users; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.organisation_saml_users (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    user_id uuid,
    organisation_id uuid,
    auto_assign_tenant boolean DEFAULT true,
    auto_assign_role boolean DEFAULT true,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.organisation_saml_users OWNER TO csmpdbuser;

--
-- Name: organisation_service_groups; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.organisation_service_groups (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    organisation_id uuid,
    service_group_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.organisation_service_groups OWNER TO csmpdbuser;

--
-- Name: organisations; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.organisations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    application_plan_id uuid,
    trial_period_days integer,
    organisation_identifier character varying(255) NOT NULL,
    subdomain character varying,
    user_id uuid,
    is_active boolean DEFAULT true,
    parent_id uuid,
    child_organisation_enable boolean DEFAULT false,
    report_profile_id character varying,
    owner_type integer DEFAULT 0
);


ALTER TABLE public.organisations OWNER TO csmpdbuser;

--
-- Name: organisations_users; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.organisations_users (
    organisation_id uuid NOT NULL,
    user_id uuid NOT NULL,
    uuid bigint NOT NULL,
    state character varying DEFAULT 'invited'::character varying,
    invite_token character varying,
    invited_at timestamp without time zone,
    active_dashboard_id character varying
);


ALTER TABLE public.organisations_users OWNER TO csmpdbuser;

--
-- Name: organisations_users_uuid_seq; Type: SEQUENCE; Schema: public; Owner: csmpdbuser
--

CREATE SEQUENCE public.organisations_users_uuid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organisations_users_uuid_seq OWNER TO csmpdbuser;

--
-- Name: organisations_users_uuid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: csmpdbuser
--

ALTER SEQUENCE public.organisations_users_uuid_seq OWNED BY public.organisations_users.uuid;


--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.payment_methods (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    account_id uuid,
    payable_id uuid,
    payable_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.payment_methods OWNER TO csmpdbuser;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    name text,
    subject_class text,
    subject_id uuid,
    action text,
    description text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.permissions OWNER TO csmpdbuser;

--
-- Name: policies; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.policies (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    policy_name character varying,
    policy_arn character varying,
    type character varying,
    policy_id character varying,
    group_arn character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    adapter_id uuid,
    aws_account_id character varying,
    policy_document json
);


ALTER TABLE public.policies OWNER TO csmpdbuser;

--
-- Name: protocols; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.protocols (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text,
    type text,
    description text,
    interface_id uuid,
    data public.hstore,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.protocols OWNER TO csmpdbuser;

--
-- Name: rds_configurations; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.rds_configurations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    account_id uuid,
    created_by uuid,
    updated_by uuid,
    data json,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.rds_configurations OWNER TO csmpdbuser;

--
-- Name: regions; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.regions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    region_name character varying(255),
    adapter_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    code character varying(255)
);


ALTER TABLE public.regions OWNER TO csmpdbuser;

--
-- Name: report_configurations; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.report_configurations (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    report_name character varying,
    report_prefix character varying,
    compression_type character varying,
    adapter_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    status boolean DEFAULT true,
    error_message text[] DEFAULT '{}'::text[]
);


ALTER TABLE public.report_configurations OWNER TO csmpdbuser;

--
-- Name: reserved_instances; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.reserved_instances (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    account_id uuid,
    region_id uuid,
    adapter_id uuid,
    availability_zone character varying(255),
    duration integer,
    fixed_price double precision,
    instance_type character varying(255),
    instance_count integer,
    product_description character varying(255),
    reserved_instances_id character varying(255),
    start_time timestamp without time zone,
    state character varying(255),
    usage_price double precision,
    end_time timestamp without time zone,
    data json,
    provider_data json,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.reserved_instances OWNER TO csmpdbuser;

--
-- Name: resource_groups; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.resource_groups (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    location character varying(255),
    tags json,
    data json,
    provider_data json,
    type character varying(255),
    subscription_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.resource_groups OWNER TO csmpdbuser;

--
-- Name: resources; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.resources (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text,
    data public.hstore,
    type text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    account_id uuid,
    environment_id uuid,
    region_id uuid,
    adapter_id uuid,
    user_role_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL
);


ALTER TABLE public.resources OWNER TO csmpdbuser;

--
-- Name: right_size_configurations; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.right_size_configurations (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    account_id uuid,
    family_type text[] DEFAULT '{}'::text[],
    right_size_config_check boolean DEFAULT false,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.right_size_configurations OWNER TO csmpdbuser;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text,
    resource_id uuid,
    resource_type text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    start_date timestamp with time zone,
    end_date timestamp with time zone
);


ALTER TABLE public.roles OWNER TO csmpdbuser;

--
-- Name: route_tables; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.route_tables (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    provider_id character varying(255),
    type character varying(255),
    associations text,
    routes text,
    provider_data json,
    vpc_id uuid,
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    tags json DEFAULT '{}'::json
);


ALTER TABLE public.route_tables OWNER TO csmpdbuser;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO csmpdbuser;

--
-- Name: security_groups; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.security_groups (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    group_id character varying(255),
    owner_id character varying(255),
    type character varying(255),
    description text,
    ip_permissions text,
    provider_data json,
    vpc_id uuid,
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    ip_permissions_egress text,
    state character varying(255) DEFAULT 'pending'::character varying,
    data json
);


ALTER TABLE public.security_groups OWNER TO csmpdbuser;

--
-- Name: service_adviser_configs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.service_adviser_configs (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    account_id uuid NOT NULL,
    adapter_id uuid,
    provider_type character varying NOT NULL,
    config_type character varying NOT NULL,
    name character varying NOT NULL,
    category character varying NOT NULL,
    service_type character varying,
    tags jsonb DEFAULT '{}'::jsonb,
    config_details jsonb NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.service_adviser_configs OWNER TO csmpdbuser;

--
-- Name: service_adviser_summaries; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.service_adviser_summaries (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    account_id uuid,
    tenant_id uuid,
    tenant_name character varying,
    summary_data json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.service_adviser_summaries OWNER TO csmpdbuser;

--
-- Name: service_advisor_logs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.service_advisor_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    account_id uuid,
    service_id uuid,
    data public.hstore,
    origin_environment_id uuid,
    destination_environment_id uuid,
    event_type character varying(255),
    status character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.service_advisor_logs OWNER TO csmpdbuser;

--
-- Name: service_details; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.service_details (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    ignored_from character varying,
    ignored_from_category character varying,
    comment text,
    commented_by character varying,
    commented_date timestamp without time zone,
    adapter_id uuid,
    region_id uuid,
    provider_id character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    comment_type character varying,
    user_email character varying,
    provider_type character varying DEFAULT 'AWS'::character varying,
    schedule text,
    ignore_for_days character varying DEFAULT 'forever'::character varying
);


ALTER TABLE public.service_details OWNER TO csmpdbuser;

--
-- Name: service_encryption_keys; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.service_encryption_keys (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    service_id uuid,
    encryption_key_id uuid
);


ALTER TABLE public.service_encryption_keys OWNER TO csmpdbuser;

--
-- Name: service_events; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.service_events (
    id integer NOT NULL,
    service_id uuid NOT NULL,
    event character varying(255),
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.service_events OWNER TO csmpdbuser;

--
-- Name: service_events_id_seq; Type: SEQUENCE; Schema: public; Owner: csmpdbuser
--

CREATE SEQUENCE public.service_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_events_id_seq OWNER TO csmpdbuser;

--
-- Name: service_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: csmpdbuser
--

ALTER SEQUENCE public.service_events_id_seq OWNED BY public.service_events.id;


--
-- Name: service_groups; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.service_groups (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    account_id uuid,
    tenant_id uuid,
    type character varying,
    name character varying,
    description character varying,
    provider_type character varying,
    adapter_ids json[] DEFAULT '{}'::json[],
    tags json[] DEFAULT '{}'::json[],
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    billing_adapter_id uuid,
    is_group_empty boolean DEFAULT false,
    normal_adapter_ids character varying[] DEFAULT '{}'::character varying[],
    custom_data jsonb DEFAULT '{}'::jsonb,
    sub_account_ids json[] DEFAULT '{}'::json[],
    customer_id character varying,
    customer_name character varying,
    customer_subscriptions character varying[] DEFAULT '{}'::character varying[]
);


ALTER TABLE public.service_groups OWNER TO csmpdbuser;

--
-- Name: service_naming_defaults; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.service_naming_defaults (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    prefix_service_name character varying(255),
    suffix_service_count integer,
    last_used_number character varying(255),
    created_by character varying(255),
    updated_by character varying(255),
    account_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    service_type character varying(255),
    generic_service_type character varying(255),
    sub_service_type character varying(255),
    free_text boolean DEFAULT false,
    last_used_names json DEFAULT '{}'::json
);


ALTER TABLE public.service_naming_defaults OWNER TO csmpdbuser;

--
-- Name: service_synchronization_histories; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.service_synchronization_histories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    state character varying(255),
    provider_type character varying(255),
    generic_type character varying(255),
    provider_id character varying(255),
    provider_vpc_id character varying(255),
    data json,
    provider_data json,
    updates json,
    adapter_id uuid,
    region_id uuid,
    account_id uuid,
    synchronization_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.service_synchronization_histories OWNER TO csmpdbuser;

--
-- Name: tag_key_values; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.tag_key_values (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tag_value character varying(600) NOT NULL,
    tag_key_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.tag_key_values OWNER TO csmpdbuser;

--
-- Name: tag_keys; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.tag_keys (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    key character varying(600) NOT NULL,
    description text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    account_id uuid,
    adapter_id uuid,
    region_id uuid,
    subscription_id uuid
);


ALTER TABLE public.tag_keys OWNER TO csmpdbuser;

--
-- Name: service_tags; Type: VIEW; Schema: public; Owner: csmpdbuser
--

CREATE VIEW public.service_tags AS
 SELECT st.kumo_service_id,
    v.tag_value,
    t.key,
    t.adapter_id,
    t.subscription_id,
    t.region_id,
    ks.service_type,
    ks.name,
    ks.provider_id
   FROM (((public.kumo_services_tag_key_values st
     LEFT JOIN public.kumo_services ks ON ((st.kumo_service_id = ks.id)))
     LEFT JOIN public.tag_key_values v ON ((st.tag_key_value_id = v.id)))
     LEFT JOIN public.tag_keys t ON ((v.tag_key_id = t.id)));


ALTER TABLE public.service_tags OWNER TO csmpdbuser;

--
-- Name: services; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.services (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text,
    state text NOT NULL,
    data json,
    type text NOT NULL,
    provider_type text,
    adapter_id uuid,
    geometry json,
    account_id uuid,
    provider_data json,
    generic boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    generic_type text,
    parent_id uuid,
    desired_state text,
    friendly_id text,
    region_id uuid,
    vpc_id uuid,
    provider_id character varying(255),
    error_message text,
    service_vpc_id uuid,
    additional_properties json,
    synchronized boolean,
    hourly_cost double precision,
    total_cost double precision,
    last_cost_update_time timestamp without time zone,
    cost_by_hour numeric(15,10) DEFAULT 0.0,
    provider_created_at timestamp without time zone,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp without time zone,
    idle_instance boolean DEFAULT false,
    ignored_from character varying[] DEFAULT '{un-ignored}'::character varying[] NOT NULL
);


ALTER TABLE public.services OWNER TO csmpdbuser;

--
-- Name: services_tasks; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.services_tasks (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    service_id uuid,
    task_id uuid
);


ALTER TABLE public.services_tasks OWNER TO csmpdbuser;

--
-- Name: slack_users; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.slack_users (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    organisation_id uuid,
    user_id uuid,
    workspace_id uuid,
    account_id uuid,
    access_token character varying,
    auth_data jsonb DEFAULT '{}'::jsonb,
    data jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.slack_users OWNER TO csmpdbuser;

--
-- Name: snapshots; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.snapshots (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    type character varying(255),
    category character varying(255),
    provider_id character varying(255),
    provider_data json,
    description text,
    account_id uuid,
    service_id uuid,
    adapter_id uuid,
    region_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    archived boolean DEFAULT false,
    state character varying(255),
    data json,
    error_message text,
    cost_by_hour numeric(23,18) DEFAULT 0.0,
    environment_id uuid,
    first_snapshot boolean DEFAULT false,
    last_cost_update_time timestamp without time zone,
    provider_created_at timestamp without time zone,
    machine_image_id uuid,
    created_by uuid,
    image_reference character varying,
    publicly_accessible boolean DEFAULT false,
    ignored_from character varying[] DEFAULT '{un-ignored}'::character varying[] NOT NULL
);


ALTER TABLE public.snapshots OWNER TO csmpdbuser;

--
-- Name: snapshots_tasks; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.snapshots_tasks (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    snapshot_id uuid,
    task_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.snapshots_tasks OWNER TO csmpdbuser;

--
-- Name: soe_scripts; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.soe_scripts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    last_updated timestamp without time zone,
    script_type character varying(255),
    script_text text,
    soe_scripts_group_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.soe_scripts OWNER TO csmpdbuser;

--
-- Name: soe_scripts_groups; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.soe_scripts_groups (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    supported_os character varying(255),
    soe_config_count integer DEFAULT 0,
    sourceable_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    sourceable_id uuid
);


ALTER TABLE public.soe_scripts_groups OWNER TO csmpdbuser;

--
-- Name: soe_scripts_remote_sources; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.soe_scripts_remote_sources (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    url text,
    last_updated timestamp without time zone,
    version character varying(255),
    state character varying(255) DEFAULT 'active'::character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.soe_scripts_remote_sources OWNER TO csmpdbuser;

--
-- Name: sso_configs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.sso_configs (
    id integer NOT NULL,
    idp_sso_target_url text,
    idp_slo_target_url text,
    idp_entity_id text,
    certificate text,
    account_id uuid,
    disable boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    email_attribute_key text DEFAULT 'E-Mail Address'::text,
    name_attribute_key text DEFAULT 'Name'::text,
    roles_attribute_key text DEFAULT 'Role'::text,
    sso_keyword_attribute_key text DEFAULT 'Tenant'::text,
    idp_metadata text,
    private_key text
);


ALTER TABLE public.sso_configs OWNER TO csmpdbuser;

--
-- Name: sso_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: csmpdbuser
--

CREATE SEQUENCE public.sso_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sso_configs_id_seq OWNER TO csmpdbuser;

--
-- Name: sso_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: csmpdbuser
--

ALTER SEQUENCE public.sso_configs_id_seq OWNED BY public.sso_configs.id;


--
-- Name: storage_vms; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.storage_vms (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    filer_id uuid,
    name character varying(255),
    state character varying(255),
    language character varying(255),
    allowed_aggregates text[] DEFAULT '{}'::text[],
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    cifs_nfs_mount_ip character varying
);


ALTER TABLE public.storage_vms OWNER TO csmpdbuser;

--
-- Name: storages; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.storages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    key character varying(255),
    adapter_id uuid,
    region_id uuid,
    account_id uuid,
    creation_date timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    owner_id character varying(255),
    owner_display_name character varying(255),
    access_control_list json,
    data json,
    ignored_from character varying[] DEFAULT '{un-ignored}'::character varying[] NOT NULL
);


ALTER TABLE public.storages OWNER TO csmpdbuser;

--
-- Name: subnet_groups; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.subnet_groups (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    provider_id character varying(255),
    description text,
    state character varying(255),
    account_id uuid,
    region_id uuid,
    adapter_id uuid,
    vpc_id uuid,
    subnet_ids text[] DEFAULT '{}'::text[],
    data json,
    provider_data json,
    type character varying(255),
    subnet_service_ids text[] DEFAULT '{}'::text[],
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.subnet_groups OWNER TO csmpdbuser;

--
-- Name: subnets; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.subnets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    provider_id character varying(255),
    provider_vpc_id character varying(255),
    name character varying(255),
    vpc_id uuid,
    cidr_block text,
    available_ip integer,
    availability_zone character varying(255),
    tags json DEFAULT '{}'::json,
    type character varying(255),
    provider_data json,
    adapter_id uuid,
    account_id uuid,
    region_id uuid,
    state character varying(255) DEFAULT 'pending'::character varying,
    data json
);


ALTER TABLE public.subnets OWNER TO csmpdbuser;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.subscriptions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    provider_subscription_id character varying(255),
    name character varying(255),
    state character varying(255),
    data json,
    provider_data json,
    enabled boolean DEFAULT true,
    adapter_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    type character varying(255)
);


ALTER TABLE public.subscriptions OWNER TO csmpdbuser;

--
-- Name: synchronization_settings; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.synchronization_settings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    account_id uuid,
    repeat json,
    sync_time time without time zone,
    auto_sync_to_aws boolean DEFAULT false,
    auto_sync_to_kum_from_aws boolean DEFAULT false,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    status json,
    adapters uuid[] DEFAULT '{}'::uuid[]
);


ALTER TABLE public.synchronization_settings OWNER TO csmpdbuser;

--
-- Name: synchronizations; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.synchronizations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    state_info json,
    account_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    friendly_id integer,
    adapter_ids uuid[] DEFAULT '{}'::uuid[],
    region_ids uuid[] DEFAULT '{}'::uuid[],
    executor_id uuid,
    has_synced_vpcs boolean DEFAULT false,
    sync_info json,
    adapter_wise_sync_status public.hstore DEFAULT ''::public.hstore,
    service_sync_status json
);


ALTER TABLE public.synchronizations OWNER TO csmpdbuser;

--
-- Name: tags; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.tags (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tag_key character varying(255),
    tag_type character varying(255),
    tag_value text[] DEFAULT '{}'::text[],
    is_mandatory boolean DEFAULT false,
    data public.hstore,
    account_id uuid,
    created_by uuid,
    updated_by uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    state character varying(255),
    applied_type character varying(255) DEFAULT 'Provider'::character varying,
    applicable_services character varying(255)[] DEFAULT '{}'::character varying[],
    overridable_services character varying(255)[] DEFAULT '{}'::character varying[],
    description text
);


ALTER TABLE public.tags OWNER TO csmpdbuser;

--
-- Name: task_details; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.task_details (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    adapter_id uuid,
    task_id uuid,
    type character varying,
    data json,
    resource_identifier character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    is_opt_out boolean DEFAULT false
);


ALTER TABLE public.task_details OWNER TO csmpdbuser;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.tasks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(255),
    description character varying(255),
    created_by uuid,
    account_id uuid,
    repeat boolean DEFAULT false,
    start_datetime timestamp without time zone NOT NULL,
    end_schedule json NOT NULL,
    occurences_completed integer DEFAULT 0,
    data json,
    schedule text NOT NULL,
    task_type integer NOT NULL,
    notify boolean DEFAULT false,
    notification_schedule json,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    parent_id uuid,
    service_type character varying[] DEFAULT '{}'::character varying[],
    schedule_type character varying,
    last_execuation_time timestamp without time zone,
    next_execuation_time timestamp without time zone,
    status character varying,
    interval_time integer,
    time_zone public.hstore DEFAULT ''::public.hstore,
    region_ids character varying[] DEFAULT '{}'::character varying[],
    backup_policy_id character varying,
    machine_image_ids character varying[] DEFAULT '{}'::character varying[],
    enable boolean DEFAULT true,
    progress json DEFAULT '{"total":0,"success":0,"failure":0}'::json NOT NULL,
    skip_occurrence character varying[] DEFAULT '{}'::character varying[],
    type character varying,
    data_prepared boolean DEFAULT true,
    tenant_id uuid
);


ALTER TABLE public.tasks OWNER TO csmpdbuser;

--
-- Name: teams_users; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.teams_users (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    account_id uuid,
    organisation_id uuid,
    workspace_id uuid,
    user_id uuid,
    access_token character varying,
    user_details jsonb DEFAULT '{}'::jsonb,
    bot_data jsonb DEFAULT '{}'::jsonb,
    conversation_data jsonb DEFAULT '{}'::jsonb,
    user_data jsonb DEFAULT '{}'::jsonb,
    service_url character varying,
    aad_object_id character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    refresh_token character varying
);


ALTER TABLE public.teams_users OWNER TO csmpdbuser;

--
-- Name: template_costs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.template_costs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    region_id uuid,
    data json,
    type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.template_costs OWNER TO csmpdbuser;

--
-- Name: template_kumo_services; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.template_kumo_services (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    template_id uuid,
    kumo_service_id uuid,
    geometry json
);


ALTER TABLE public.template_kumo_services OWNER TO csmpdbuser;

--
-- Name: template_services; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.template_services (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    template_id uuid NOT NULL,
    service_id uuid NOT NULL
);


ALTER TABLE public.template_services OWNER TO csmpdbuser;

--
-- Name: template_vpcs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.template_vpcs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    template_id uuid,
    vpc_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.template_vpcs OWNER TO csmpdbuser;

--
-- Name: templates; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.templates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text,
    version text,
    state text NOT NULL,
    account_id uuid,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    friendly_id text,
    template_model json,
    region_id uuid,
    adapter_id uuid,
    created_by uuid,
    updated_by uuid,
    revision double precision DEFAULT 0.0 NOT NULL,
    shared_with uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    description text DEFAULT ''::text,
    template_tags json DEFAULT '{}'::json,
    selected_type integer DEFAULT 2,
    subscription_id uuid,
    generic_type boolean DEFAULT false,
    with_nc boolean DEFAULT false
);


ALTER TABLE public.templates OWNER TO csmpdbuser;

--
-- Name: tenant_adapters; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.tenant_adapters (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    tenant_id uuid,
    adapter_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.tenant_adapters OWNER TO csmpdbuser;

--
-- Name: tenant_billing_adapters; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.tenant_billing_adapters (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    tenant_id uuid,
    organisation_id uuid,
    billing_adapter_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.tenant_billing_adapters OWNER TO csmpdbuser;

--
-- Name: tenant_service_groups; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.tenant_service_groups (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    tenant_id uuid,
    service_group_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.tenant_service_groups OWNER TO csmpdbuser;

--
-- Name: tenant_users; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.tenant_users (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    user_id uuid,
    tenant_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.tenant_users OWNER TO csmpdbuser;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.tenants (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    name text,
    state character varying,
    organisation_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    is_default boolean DEFAULT false,
    tags json DEFAULT '{}'::json,
    sso_keywords text[] DEFAULT '{}'::text[],
    exclude_edp boolean,
    report_profile_id character varying,
    all_selected_flags jsonb DEFAULT '{}'::jsonb,
    enable_currency_conversion boolean,
    default_currency character varying
);


ALTER TABLE public.tenants OWNER TO csmpdbuser;

--
-- Name: tenants_resource_groups; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.tenants_resource_groups (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    tenant_id uuid,
    adapter_id uuid,
    azure_resource_group_id uuid
);


ALTER TABLE public.tenants_resource_groups OWNER TO csmpdbuser;

--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.user_preferences (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    preferences json DEFAULT '{}'::json,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    prefereable_id uuid,
    prefereable_type character varying(255)
);


ALTER TABLE public.user_preferences OWNER TO csmpdbuser;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    sso_keywords text[] DEFAULT '{}'::text[],
    provision_right boolean DEFAULT false,
    organisation_id uuid
);


ALTER TABLE public.user_roles OWNER TO csmpdbuser;

--
-- Name: user_roles_users; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.user_roles_users (
    id integer NOT NULL,
    user_id uuid,
    user_role_id uuid,
    tenant_id uuid
);


ALTER TABLE public.user_roles_users OWNER TO csmpdbuser;

--
-- Name: user_roles_users_id_seq; Type: SEQUENCE; Schema: public; Owner: csmpdbuser
--

CREATE SEQUENCE public.user_roles_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_roles_users_id_seq OWNER TO csmpdbuser;

--
-- Name: user_roles_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: csmpdbuser
--

ALTER SEQUENCE public.user_roles_users_id_seq OWNED BY public.user_roles_users.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email text,
    encrypted_password text NOT NULL,
    reset_password_token text,
    sign_in_count integer DEFAULT 0,
    current_sign_in_ip text,
    last_sign_in_ip text,
    authentication_token text NOT NULL,
    name text,
    confirmation_token text,
    unconfirmed_email text,
    invite_token character varying(255),
    username character varying(255),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    reset_password_sent_at timestamp with time zone,
    remember_created_at timestamp with time zone,
    current_sign_in_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    confirmed_at timestamp with time zone,
    confirmation_sent_at timestamp with time zone,
    invited_at timestamp with time zone,
    signed_up boolean,
    state character varying(255),
    account_id uuid,
    show_intro boolean DEFAULT true,
    user_type character varying(255) DEFAULT 'kumo'::character varying,
    time_zone json,
    is_admin boolean DEFAULT false,
    current_tenant uuid,
    override_tenant_currency boolean,
    default_currency character varying,
    reset_to_default_currency boolean,
    activated_by_user boolean,
    enable_welcome_popup boolean DEFAULT true
);


ALTER TABLE public.users OWNER TO csmpdbuser;

--
-- Name: users_roles; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.users_roles (
    user_id uuid,
    role_id uuid
);


ALTER TABLE public.users_roles OWNER TO csmpdbuser;

--
-- Name: vm_ware_service_forecast_costs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.vm_ware_service_forecast_costs (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    adapter_id uuid,
    account_id uuid,
    month character varying,
    tab character varying,
    cost double precision,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    vcenter_id uuid,
    net_cost double precision,
    margin_cost double precision,
    discount_cost double precision
);


ALTER TABLE public.vm_ware_service_forecast_costs OWNER TO csmpdbuser;

--
-- Name: vm_ware_tenant_adapters; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.vm_ware_tenant_adapters (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    organisation_id uuid,
    tenant_id uuid,
    adapter_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.vm_ware_tenant_adapters OWNER TO csmpdbuser;

--
-- Name: vpcs; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.vpcs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255),
    cidr character varying(255),
    vpc_id character varying(255),
    enable_dns_resolution boolean,
    internet_attached boolean,
    tenancy character varying(255),
    provider_data json,
    enabled boolean,
    template_id uuid,
    region_id uuid,
    account_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    type character varying(255),
    adapter_id uuid,
    data json,
    state character varying(255),
    synchronized boolean DEFAULT false,
    user_role_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL
);


ALTER TABLE public.vpcs OWNER TO csmpdbuser;

--
-- Name: vw_events; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.vw_events (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    count integer,
    size integer,
    cores_per_socket integer,
    forceful_apply boolean DEFAULT false,
    name integer DEFAULT 0,
    vw_inventory_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    status integer DEFAULT 0,
    error character varying,
    data json DEFAULT '{}'::json
);


ALTER TABLE public.vw_events OWNER TO csmpdbuser;

--
-- Name: vw_inventories; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.vw_inventories (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    data json,
    parent_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    vw_vcenter_id uuid,
    resource_type character varying,
    provider_id character varying,
    tag character varying,
    idle_instance boolean DEFAULT false,
    cost_by_hour numeric DEFAULT 0.0
);


ALTER TABLE public.vw_inventories OWNER TO csmpdbuser;

--
-- Name: vw_metrics; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.vw_metrics (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    data json,
    vw_inventory_id uuid,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    noted_at timestamp without time zone
);


ALTER TABLE public.vw_metrics OWNER TO csmpdbuser;

--
-- Name: vw_vcenters; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.vw_vcenters (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    adapter_id uuid,
    data json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    provider_id character varying
);


ALTER TABLE public.vw_vcenters OWNER TO csmpdbuser;

--
-- Name: vw_vdc_files; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.vw_vdc_files (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    adapter_id uuid,
    zip character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    vw_vcenter_id character varying
);


ALTER TABLE public.vw_vdc_files OWNER TO csmpdbuser;

--
-- Name: workspaces; Type: TABLE; Schema: public; Owner: csmpdbuser
--

CREATE TABLE public.workspaces (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    name character varying,
    type character varying,
    user_id uuid,
    account_id uuid,
    organisation_id uuid,
    data jsonb DEFAULT '{}'::jsonb,
    state character varying DEFAULT 'Active'::character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.workspaces OWNER TO csmpdbuser;

--
-- Name: admin_users id; Type: DEFAULT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.admin_users ALTER COLUMN id SET DEFAULT nextval('public.admin_users_id_seq'::regclass);


--
-- Name: environment_storages id; Type: DEFAULT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_storages ALTER COLUMN id SET DEFAULT nextval('public.environment_storages_id_seq'::regclass);


--
-- Name: environments_tasks id; Type: DEFAULT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environments_tasks ALTER COLUMN id SET DEFAULT nextval('public.environments_tasks_id_seq'::regclass);


--
-- Name: invoices invoice_number; Type: DEFAULT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.invoices ALTER COLUMN invoice_number SET DEFAULT nextval('public.invoices_invoice_number_seq'::regclass);


--
-- Name: network_interfaces id; Type: DEFAULT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.network_interfaces ALTER COLUMN id SET DEFAULT nextval('public.network_interfaces_id_seq'::regclass);


--
-- Name: organisation_details id; Type: DEFAULT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisation_details ALTER COLUMN id SET DEFAULT nextval('public.organisation_details_id_seq'::regclass);


--
-- Name: organisation_images id; Type: DEFAULT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisation_images ALTER COLUMN id SET DEFAULT nextval('public.organisation_images_id_seq'::regclass);


--
-- Name: organisations_users uuid; Type: DEFAULT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisations_users ALTER COLUMN uuid SET DEFAULT nextval('public.organisations_users_uuid_seq'::regclass);


--
-- Name: service_events id; Type: DEFAULT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.service_events ALTER COLUMN id SET DEFAULT nextval('public.service_events_id_seq'::regclass);


--
-- Name: sso_configs id; Type: DEFAULT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.sso_configs ALTER COLUMN id SET DEFAULT nextval('public.sso_configs_id_seq'::regclass);


--
-- Name: user_roles_users id; Type: DEFAULT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.user_roles_users ALTER COLUMN id SET DEFAULT nextval('public.user_roles_users_id_seq'::regclass);


--
-- Data for Name: access_rights; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.access_rights (id, title, code, created_at, updated_at) FROM stdin;
f25c1aa2-fd93-4e39-bbce-8fb64cdc07a0    Monitor Application/Environment kum_monitor_view    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
b29fe3bf-4180-4893-bc1e-b3c0085ff24b    View    kum_report_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
e00b30a9-2ce9-49e4-83c7-5530924d70e1    View    kum_report_cost_view    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
3e88a07d-ddf0-4609-8536-e3bbabfc9295    View    kum_report_ri_view  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
2d498d91-4d7f-4554-9c9a-8115a863fd53    View    kum_report_user_activity_view   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
06d2eb2b-3722-4c0c-b6a4-cd8a3993e1b9    View    kum_report_synchronization_history_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
eeec3a77-235a-46da-ae97-275adbf317d1    View    kum_report_support_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
816b7508-ef4e-4832-9101-26d7c6206572    View    kum_report_account_budget_view  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
9b648a32-51a0-4e43-b697-25f54e3e5941    Edit    kum_report_account_budget_edit  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
a4085c64-fb32-4142-9642-803f31328aaf    Create  kum_report_account_budget_create    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
2b0b4833-9f61-4eee-a020-f4db21cb8df8    Delete  kum_report_account_budget_delete    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
0a718cf1-82bf-408d-a0f6-5531560696de    Modify  kum_environment_edit    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
4ac45498-65d0-47a3-89aa-e3693422ab2c    View    kum_environment_view    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
ba26e1d2-8a35-4123-bd1f-467c6b30c7fd    Operate - Start/Stop/Reboot kum_environment_operate 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
d0a02046-9b9b-4e93-8b75-7a075340358d    Create Snapshot kum_env_snapshot_create 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
e6f943e9-f2a7-4e59-8585-ced6c4901dfe    Delete Snapshot kum_env_snapshot_delete 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
d3916792-671a-4aee-b354-f60262fa0b5e    View    kum_application_view    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
71e60760-89ee-42b5-a23c-a19fe5bf1e8b    Create  kum_application_create  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
fdc0a95b-8f83-4f81-b801-a70f0e0eacd6    Edit    kum_application_edit    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
2e4da4ae-5014-4dc6-ac4d-c24e02b609ed    Delete  kum_application_delete  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
24ecf599-77b9-4651-919b-3c22e9e49994    View    kum_template_view   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
3cf4be88-2149-44ef-9e88-9087fdcaed5b    Create  kum_template_create 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
a414ace4-f840-4e9f-9a4d-e1493b0b7b82    Edit    kum_template_edit   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
8148942b-b3ba-4833-9a1a-668cb7a82bd9    Delete  kum_template_delete 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
fafcaaff-47b3-4b5f-b43f-0eac1bdac4eb    Provision   kum_template_provision  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
7623bb92-27b4-46c6-a038-17f58f6a6309    Share within Organisation   kum_template_share_within_organization  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
d5abfecf-51b7-4ed5-8d47-e2d4901f11eb    View    kum_vpc_view    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
d98d10c7-f076-4c91-92b0-ad33a540428a    Create  kum_vpc_create  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
85dc97da-13ff-4416-bbb4-ff03947f0529    Edit    kum_vpc_edit    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
cf40505f-2863-494a-aa26-4a06d9cf9115    Delete  kum_vpc_delete  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
e5806bc9-6e01-4a43-aca3-8cca009edae2    View    kum_adapter_view    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
386692b8-df9e-4e73-9d52-832e53ba0676    Create  kum_adapter_create  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
a80fb583-fdb4-4a4b-8a72-6b2f2c414f14    Edit    kum_adapter_edit    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
7d2d5cb7-4d7a-49a9-ba0c-39d4bab0c2c3    Delete  kum_adapter_delete  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
ba8aabd6-9fe8-4731-99a3-a6d41a49815f    View    kum_settings_gen_view   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
b153521e-7080-4608-8a15-798c2f6abd7b    Manage  kum_settings_gen_manage 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
38140a38-ce92-490f-86b1-2b98baf6b1e1    View    kum_settings_sync_view  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
502c810b-d045-4071-a9fc-285d9ddbea8a    Manage  kum_settings_sync_manage    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
95147c37-a220-40f2-8b83-9921e9d755ec    View    kum_settings_tag_view   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
dcb0304a-f401-473e-a872-405819d80830    Manage  kum_settings_tag_manage 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
cdd99a62-2edb-498f-b978-35820c85e30f    View    kum_settings_netw_view  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
3ec25392-8971-4bc0-a171-73d8e341795d    Manage  kum_settings_netw_manage    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
742f31a6-33d4-4701-b845-d664efbd8ed1    View    kum_settings_auth_view  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
59852cec-f771-4d70-926d-8c35e9578d45    Manage  kum_settings_auth_manage    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
79fa4b37-4634-42db-b02c-6a7022f4a02f    View    kum_settings_key_pair_view  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
753481a9-4478-4006-a416-bdbbce15c443    Manage  kum_settings_key_pair_manage    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
180ea2ec-6c94-4b92-a7b7-8cdaaaacbe97    View SOE OS kum_ami_view    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
4a9f2279-17ca-458d-bbf4-41be80536ea6    Add To Organisation SOE OS  kum_org_os_add  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
52551fec-8270-42de-bad4-d72be014584a    Edit Organisation SOE OS    kum_org_os_edit 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
7a748410-3d95-4e44-8d6f-88901a22acfd    Remove Organisation SOE OS  kum_org_os_remove   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
5d6850b5-6ac1-4233-bc10-ae5433f5b969    Manage SOE Scripts  kum_ami_soe_scripts 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
92a94cfd-08b8-469d-b44d-4bf6623f53ab    View    kum_access_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
52232061-922d-4198-9843-7546e1da8cfa    Manage  kum_access_user_manage  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
3ed259c0-0061-4f7b-bb42-7aefd73b8375    Add kum_access_role_add 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
82d10ca1-f315-423c-9d54-2dd225257496    Edit    kum_access_role_edit    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
b61d94f0-345b-46c7-9c4e-1e5590bb9415    Delete  kum_access_role_delete  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
756660d2-40be-45b5-9e6a-36decb40ccbe    Manage  kum_access_members_manage   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
79e65e99-f22f-4b63-9381-e3c86f0c6ddd    Restrict Environment    kum_env_restrict    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
cc695599-6bcd-4180-b325-023d463913c1    Exception for naming convention kum_exception_for_naming_convention 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
9acc40c2-a8c0-400a-9f19-a183b62c6626    Exception For IP Auto Correct   kum_exception_for_ip_auto_correct   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
d6e7d43b-cb73-4fb1-b319-cdb6be99410f    View    kum_encryption_keys_view    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
5dd6beae-354b-4275-9c65-3d4881032fe3    View Rds Config kum_rds_configuration_view  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
dfb0963a-effe-446f-a14e-6909f5d5f567    Manage Rds Config   kum_rds_configuration_manage    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
8974655b-e685-40bc-967d-e8d9ecbb4861    View    kum_event_view  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
d3dd0b57-04d4-4469-b373-844a064f84e4    Create  kum_event_create    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
3e7982c7-bc4a-4ae6-8971-fbbb50ae1c7c    Edit    kum_event_edit  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
8b242e87-1526-4839-9325-2a84114e9df9    Delete  kum_event_delete    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
7f2a9608-8545-48b1-9f0b-41bc98185ca5    View Sync Report    kum_sync_report_view    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
18613b8c-03bc-47ab-b4b3-5648d67c9e97    View Services synced    kum_sync_services_view  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
8fa056c0-0ffa-4157-ae33-9558b77d982e    View Service Advisor    kum_service_advisor_view    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
d9a5a5a8-4304-40ef-a06d-998828d93abd    Backup Services kum_backup_policy_manage    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
9d98a1f5-8ef2-46c0-b0cb-b1875b65a59c    View Payment Information    kum_settings_financial_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
c898cb46-dfe6-4b86-bb54-377e6ec5fcd7    Edit Payment Information    kum_settings_financial_edit 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
79c10000-1830-46b7-aae9-a720f0864c37    Application wise monthly budget kum_application_monthly_budget  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
211168b0-b2f3-4739-8bf8-e52657eff3fc    Manage storages kum_manage_storage  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
75e8d3a7-278f-4234-bb3c-569b7c394236    Manage filers   kum_create_modify_filer 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
6d70bb28-4843-4d68-add1-326b8e42d191    Create / Modify Service kum_service_edit    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
802d7328-760f-4bed-82cc-4f422abde197    Environment and Service Purge   kum_environment_service_purge   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
a41fad12-f11a-4b98-86b2-df50b11002e9    View restricted environment kum_restricted_environment_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
c828fdc2-202d-46f1-aba5-f6fb35d6b2b5    View restricted application kum_restricted_application_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
73eb2749-5a34-4a11-97ec-43fce87a49a8    View Event scheduler    kum_event_scheduler_view    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
51eee2dc-1001-4646-be39-0672a58f8443    Edit Event scheduler    kum_event_scheduler_edit    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
3236bc51-d4a8-4e71-b0e4-1019ec51b779    Non financial dashboard view    kum_non_financial_dashboard_view    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
955fcd0e-b6a6-4fce-ada4-1a268f610e44    Backup Configuration    kum_backup_configuration_manage 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
0de410cd-1830-4d69-813c-6ccffb0bfb74    HTTP Proxy Configuration    kum_http_proxy_configuration_manage 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
65d619bf-3bb6-4320-b1d5-4a4b67fe6442    SMTP Configuration  kum_smtp_configuration_manage   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
c6e5e5c9-4d12-4e41-92ee-874a0cd7d799    SSO Configuration   kum_sso_configuration_manage    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
4da529b6-d7a7-4164-a620-f5e5b6de3a06    SSL Configuration   kum_ssl_certificate_manage  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
1f017924-03a0-4ec7-98fb-6393e04116a0    DNS Server Configuration    kum_dns_server_preferences_manage   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
4a3c4987-39a7-4ee9-ae83-1608e54f0b16    Add kum_tenant_add  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
c58721c8-d813-469c-9710-b183de638369    Edit    kum_tenant_edit 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
ae30fbe0-f5f4-4831-90fa-054707ee5cda    Delete  kum_tenant_delete   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
eb8294dc-0643-4876-8933-ccfea6bc62bc    Manage Permission   kum_tenant_manage_permission    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
55a05ddd-d215-484e-8a50-57802387d40a    View    kum_tenant_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
779a8605-a83f-47dd-ad06-7f8824e45a62    View    kum_service_adviser_view    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
0ec1890e-e936-4333-a798-cbbc2f5e9763    View    kum_security_adviser_view   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
2016d52a-5238-439a-bf0c-25e76cfa2843    View    kum_compliance_reports_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
f98f111c-e677-4178-81aa-8eaad3c6059e    View    kum_service_manager_services_view   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
73a6b46d-11f0-495a-bc57-7326dca74153    Manage service manager services kum_service_manager_manage_services 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
3540d7b7-8658-44c5-8882-f1e283d86328    Delete  kum_service_manager_delete_services 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
3a98c142-138f-4542-af82-c828af1641f7    View    kum_service_adviser_config_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
1383c8ac-8624-4f1b-9d14-1b09c9991681    Edit    kum_service_adviser_config_edit 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
d33fdec6-0e07-424e-94e7-3f9c94cf81de    View    kum_backup_policy_view  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
2f335fe3-d22a-4d6b-bc47-2ff8312493f4    Edit    kum_backup_policy_edit  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
d0826033-9e9a-4368-b063-40a4471f7168    Create  kum_backup_policy_create    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
2cfcaf1e-64c1-4c52-90e0-9dcaa1937d95    Delete  kum_backup_policy_delete    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
aa7f5a40-3910-4e1b-932e-f8b8316efd3e    Delete  kum_service_adviser_delete  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
80c9f9f2-14cf-4080-a5ff-2272078bcf17    View environment visualization  kum_environment_visualization   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
75b1919a-563d-4962-8c73-cd6ffc15ac14    View security visualization kum_security_visualization  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
7125a702-0765-4b42-9e3f-a9fbd33e7482    View Group  kum_service_group_view  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
fca63d2f-bb75-4ffe-88f3-214e988e5337    Create group    kum_service_group_create    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
3ad6c9dd-f85a-4c58-92bf-8e165e4df436    Edit group  kum_service_group_edit  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
6d260cde-0dc1-4bfa-bc5c-c1edfba0baa6    Delete group    kum_service_group_delete    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
0562faa8-513f-40be-b8fe-af110c7e0895    View slack workspace    kum_integrations_slack_workspace_view   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
a97d3aaa-7211-45a6-8014-db1e6e32f754    Delete slack workspace  kum_integrations_slack_workspace_delete 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
ecfdffea-87d0-4534-ad53-062f34839d1c    Authenticate slack  kum_integrations_slack_authenticate 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
87e87d6d-533e-456e-bb4f-fe54bd169f58    View slack channel  kum_integrations_slack_channel_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
d7f9aadc-c708-45f3-8add-8f1bd0782d61    Create slack channel    kum_integrations_slack_channel_create   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
1d21118c-18c3-478d-b6eb-9beb25549791    Update slack channel    kum_integrations_slack_channel_update   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
dc3981d9-f3a8-4a05-b343-1dfb57941ff0    Configuartaion for slack channel    kum_integrations_slack_channel_config   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
25b640cb-0603-4344-87b9-b58cb48fcde3    Delete slack channel    kum_integrations_slack_channel_delete   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
0f80f2cc-3c6f-439c-b63a-6124509d1ebc    View child organisation kum_child_organisation_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
f51f5add-8bf3-45ae-9044-e0133d54efff    Create child organisation   kum_child_organisation_create   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
2d8a0c3e-e60c-4641-bd79-6a1ddae35921    Change child organisation state kum_child_organisation_change_state 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
1d4c5b56-1ca2-4048-b4a0-2f597f617444    Edit shared adapters    kum_child_organisation_shared_adapter_edit  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
dedea0db-8f4c-40dc-af81-ec91b233a4ff    Remove shared adapter access.   kum_child_organisation_shared_adapter_delete    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
f040685c-9b8e-40be-a4d7-c9462058c4d9    View teams workspace    kum_integrations_teams_workspace_view   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
25331176-52bb-4d9e-9cec-f20d2e676f16    Delete teams workspace  kum_integrations_teams_workspace_delete 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
aec1d7ab-885c-475c-9fa2-fbfb234ef6f9    Authenticate teams workspace    kum_integrations_teams_authenticate 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
3e9d7bd8-c0f4-47c2-8992-1be412194b3d    View teams integration  kum_integrations_teams_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
6dcb4d54-44e6-4086-99ae-f4a8ac53058b    Update teams integration    kum_integrations_teams_update   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
910bffe2-dc9d-40fc-bbb8-6a6c2e05baeb    View naming convention  kum_naming_convention_view  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
d7d64c3c-4378-4532-82bd-2d2bb0f91144    Edit naming convention  kum_naming_convention_edit  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
ab4022bd-efb6-4c00-aae6-4107bfcfca05    View service now workspaces kum_integrations_service_now_workspace_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
9f1c2273-0e52-41c3-9e62-bea32bddde6e    Authenticate service now workspace  kum_integrations_service_now_authenticate   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
620f7285-b8e7-4e10-9930-0d9901e5d8d0    Update service now workspace    kum_integrations_service_now_workspace_update   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
a0ef8319-40ee-483c-b41d-0778fa57fb83    Update service now integration  kum_integrations_service_now_update 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
82e5dd71-96ce-4737-8a83-159cec044064    Delete service now workspace    kum_integrations_service_now_workspace_delete   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
4f827251-92a7-47af-b0a7-9e8747619b4d    Manage security vizualization   kum_security_visualization_manage   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
26ca0ea0-a665-4ffa-bb31-37e2a3adaedd    See all top level organisations csmp_admin_organisations_viewer 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
781c0974-fa0f-477a-aef4-e4ea1825e9a4    Manage trial expiration days in an organisation csmp_admin_organisations_extend_trial   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
ae46e272-f509-4f1d-8247-efd2c8d1c6b4    Moves an organisation from trial to permanent   csmp_admin_organisations_convert_to_permanent   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
cec1a889-778a-4015-9f8c-9e6f3e86bccf    Can enable child organisations  csmp_admin_organisations_enable_child_orgs  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
cabfc7c6-b47f-4593-aa15-4b3e42b1a2c2    View    kum_vm_ware_rate_card_view  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
f04f33c1-0b07-4a01-b58c-73d2a6f84a80    Create  kum_vm_ware_rate_card_create    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
02aebd34-e9a7-432e-b1f6-9b388bfb2be9    Edit    kum_vm_ware_rate_card_edit  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
fec5cdff-8c20-4cda-9a66-7b8fe7bae244    View    kum_organisation_brand_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
a405e4e4-e5d6-4ac3-8d47-457a08da331d    Edit    kum_organisation_brand_edit 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
aca193ae-daf5-4232-87ea-a95ed15d1709    View    kum_currency_conversion_view    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
ebe5f274-0cdf-4d7c-a8f4-d692f96d9763    Create  kum_currency_conversion_create  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
c6d0b681-f0c4-46d7-aba3-b5f357ce9de0    Edit    kum_currency_conversion_edit    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
afcdc8c8-7676-48ee-98de-9308d57e577e    Delete  kum_currency_conversion_delete  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
81730e3f-0c07-45cb-acd5-46a938e11c38    View    kum_report_profile_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
97965fb3-07f7-4bac-b2fd-0572b983e795    Create  kum_report_profile_create   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
874241e3-aa1a-41f8-b519-53a7420b32d3    Edit    kum_report_profile_edit 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
11ddccb6-814d-4992-b861-caecd058f46f    Delete  kum_report_profile_delete   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
55552350-04a4-47f5-a094-7f2b380b73f7    View    kum_saving_plan_report_view 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
aec5f17e-caf1-4e54-8b3b-946c4be5c001    View    kum_billing_configuration_view  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
5b5adb2e-3285-41f6-9df4-c3c4b22536f7    Create  kum_billing_configuration_create    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
2f098036-25c7-4d10-941a-dc7675b55274    Edit    kum_billing_configuration_edit  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
493e546f-d977-4ce7-96ca-6dcbc8861e46    Delete  kum_billing_configuration_delete    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
c8307e48-bf6b-4ddd-8206-8d89a4c13211    View    kum_export_report_view  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
2fba3a0a-0ce8-44f7-86ec-05eba57ffb18    View    kum_custom_dashboard_preview    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
30e3e0b2-db2a-453a-a1a7-5e4f1bfc2a21    Create  kum_custom_dashboard_create 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
b8477362-b8d8-4836-a594-4cc6f6a884c0    Edit    kum_custom_dashboard_edit   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
02836d5c-26cc-4aca-99dd-f10381e7fcfe    Delete  kum_custom_dashboard_delete 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
f8025550-2259-44c0-a6b1-9650b0008d8b    Manage  kum_custom_dashboard_manage 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
8a6cea2b-04a3-4684-a7ed-8de9190b4606    View    kum_custom_dashboard_default    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
975faef4-bef0-40ed-8484-9658b4bc3e56    View    kum_custom_dashboard_list   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
eae4722c-9a68-4a61-919b-1e55005012e4    Access  kum_custom_dashboard_activate   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
78674e4c-2f4b-4f34-ac6c-12cd99d24f6c    Provision   kum_custom_dashboard_activate_for_organization  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
e251a790-1cdc-4cd6-a42b-63ad6e01e377    View    kum_favourite_report_view   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
e6ad59c7-ef37-427e-bb8a-29f8c398516f    Create  kum_favourite_report_create 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
c5323226-550c-43c4-9fe5-6f84cc012c40    Edit    kum_favourite_report_edit   2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
dd344ea5-3504-448c-9d01-3d6a67be123b    Delete  kum_favourite_report_delete 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
204d7722-afbb-4b77-bf77-7ce8c922f2ac    Manage  kum_favourite_report_manage 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
272d0a9c-c609-4664-b2d1-2287875b5a47    Provision   kum_favourite_report_provision  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
d336146a-1fe9-4dd9-9c02-dfdaf8c71ffe    View    kum_ri_sp_billing_configuration_view    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
240b1838-39c3-4aed-956e-5fcae0a40dd2    Create  kum_ri_sp_billing_configuration_create  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
b48ec325-c164-4dc1-bd4f-8bc3386ad228    Edit    kum_ri_sp_billing_configuration_edit    2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
28ee263a-dfab-4da4-9ddb-df648eb19e5b    Delete  kum_ri_sp_billing_configuration_delete  2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
5398ed54-e232-4de6-b509-a1c6f4c27e26    History kum_ri_sp_billing_configuration_history 2022-09-27 11:04:47.220463  2022-09-27 11:07:37.276177
\.


--
-- Data for Name: access_rights_user_roles; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.access_rights_user_roles (id, access_right_id, user_role_id) FROM stdin;
\.


--
-- Data for Name: account_gcp_multi_regions; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.account_gcp_multi_regions (id, account_id, gcp_multi_regional_id, enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: account_regions; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.account_regions (id, account_id, region_id, enabled, created_at, updated_at, billing_stats) FROM stdin;
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.accounts (id, name, created_at, updated_at, state, accountable_objects, organisation_id) FROM stdin;
\.


--
-- Data for Name: accounts_soe_scripts_remote_sources; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.accounts_soe_scripts_remote_sources (id, name, account_id, soe_scripts_remote_source_id) FROM stdin;
\.


--
-- Data for Name: adapters; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.adapters (id, type, data, account_id, created_at, updated_at, state, name, is_billing, ancestry, adapter_purpose, sync_running, not_supported_regions, aws_support_discount, aws_vat_percentage, service_types_discount, all_selected_flags) FROM stdin;
581e83bc-daf5-4bc1-bf15-3f6324ec47e9    Adapters::Azure \N  \N  2022-09-27 11:04:45.374571+00   2022-09-27 11:04:45.381162+00   directory   Ms. Jordon Kuhic    f   \N  normal  f   {}  \N  \N  {}  {}
75748e0f-6f70-4074-aac6-71c984cd6993    Adapters::AWS   \N  \N  2022-09-27 11:04:45.3895+00 2022-09-27 11:04:45.396181+00   directory   Kris Pacocha    f   \N  normal  f   {}  \N  \N  {}  {}
677e6d0d-4f59-4b2d-bab4-066b9029008f    Adapters::VmWare    \N  \N  2022-09-27 11:04:45.404583+00   2022-09-27 11:04:45.41093+00    directory   Savanah Baumbach    f   \N  normal  f   {}  \N  \N  {}  {}
dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    Adapters::GCP   \N  \N  2022-09-27 11:04:45.419335+00   2022-09-27 11:04:45.426087+00   directory   Lorena Hahn f   \N  normal  f   {}  \N  \N  {}  {}
\.


--
-- Data for Name: adapters_machine_images; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.adapters_machine_images (adapter_id, machine_image_id) FROM stdin;
\.


--
-- Data for Name: adapters_tasks; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.adapters_tasks (adapter_id, task_id, tenant_access) FROM stdin;
\.


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.admin_users (id, name, email, username, api_token, password_digest, reset_password_token, reset_password_sent_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: aggregates; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.aggregates (id, name, available_capacity, total_capacity, state, encryption_type, filer_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.alerts (id, data, read, read_at, alertable_type, alert_type, alertable_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ami_config_categories; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.ami_config_categories (id, name, account_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: app_access_secrets; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.app_access_secrets (id, encrypted_token, description, token_expires, user_id, organisation_id, last_used, enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: application_plans; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.application_plans (id, name, description, max_usage_allowed, cost_percentage, support_type, trial_period_days, created_at, updated_at) FROM stdin;
14168354-59d4-4e93-85b9-828a5410cf0e    viewer  viewer plan \N  \N  \N  0   2022-09-27 11:04:45.333694  2022-09-27 11:04:45.333694
d1441d0b-fbb3-4183-a208-d9e7f95dfbd9    normal  normal plan \N  \N  \N  0   2022-09-27 11:04:45.342763  2022-09-27 11:04:45.342763
\.


--
-- Data for Name: applications; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.applications (id, name, description, account_id, created_by_user_id, updated_by_user_id, created_at, updated_at, cost, max_amount, notify, access_roles, notify_to) FROM stdin;
\.


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment development 2022-09-27 10:41:23.791025  2022-09-27 10:41:23.791025
\.


--
-- Data for Name: associated_services; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.associated_services (name, service_type, associated_kumo_service_id, kumo_service_id, created_at, updated_at, id) FROM stdin;
\.


--
-- Data for Name: availability_zones; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.availability_zones (id, zone_name, region_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: aws_accounts; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.aws_accounts (id, aws_account_id, is_password_present, allow_users_to_change_password, expire_passwords, hard_expiry, max_password_age, minimum_password_length, password_reuse_prevention, require_lowercase_characters, require_numbers, require_symbols, require_uppercase_characters, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: aws_cloud_trails; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.aws_cloud_trails (id, running, adapter_id, last_trail_time, last_process_time, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: aws_cloud_watch_logs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.aws_cloud_watch_logs (id, adapter_id, region_id, account_id, aws_account_id, region_code, alarm_configured, console_sign_in_without_mfa, monitored_aws_organizations_changes, authorization_failures_alarm_monitored, cmk_configuration_changes_monitored, alarm_configured_for_cloud_trail, monitored_sign_in_failures, monitored_ec2_instance_changes, monitored_large_ec2_instances_changes, monitored_iam_policy_changes, monitored_igw_changes, monitored_nacl_changes, monitored_root_account, monitored_route_table_changes, monitored_s3_bucket_changes, monitored_security_group_changes, monitored_vpc_changes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: aws_configs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.aws_configs (id, adapter_id, region_id, aws_account_id, name, role_arn, s3_bucket_name, configuration_recorders, configuration_recorder_status, delivery_channels, created_at, updated_at, is_s3_bucket_missing) FROM stdin;
\.


--
-- Data for Name: aws_iam_roles; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.aws_iam_roles (id, aws_account_id, role_name, path, role_id, arn, create_date, assume_role_policy_document, description, max_session_duration, permissions_boundary, tags, role_last_used, role_trust_policy, created_at, updated_at, adapter_id) FROM stdin;
\.


--
-- Data for Name: aws_marketplace_saas_subscriptions; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.aws_marketplace_saas_subscriptions (id, customer_identifier, status, subscription_date, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: aws_organisations; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.aws_organisations (id, organisation_id, adapter_id, account_id, aws_account_id, arn, feature_set, master_account_arn, master_account_id, master_account_email, available_policy_types, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: aws_records; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.aws_records (id, data, provider_vpc_id, provider_id, service_type, account_id, adapter_id, region_id, created_at, updated_at, type, cost_by_hour) FROM stdin;
\.


--
-- Data for Name: aws_right_sizings; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.aws_right_sizings (id, aws_account_id, region, data, cost_save_per_month, price, resize_price, type, created_at, updated_at, organisation_id) FROM stdin;
\.


--
-- Data for Name: aws_service_forecast_costs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.aws_service_forecast_costs (id, aws_account_id, tab, cost, account_id, created_at, updated_at, adapter_id, net_cost, margin_cost, discount_cost) FROM stdin;
\.


--
-- Data for Name: aws_trails; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.aws_trails (id, adapter_id, region_id, name, cloud_watch_logs_log_group_arn, cloud_watch_logs_role_arn, home_region, has_custom_event_selectors, include_global_service_events, is_multi_region_trail, is_organization_trail, kms_key_id, log_file_validation_enabled, s3_key_prefix, s3_bucket_name, sns_topic_name, sns_topic_arn, trail_arn, created_at, updated_at, s3_bucket_server_access_logging, provider_name, aws_account_id, data_resources, latest_delivery_error, include_management_events, s3_lock_configuration) FROM stdin;
\.


--
-- Data for Name: azure_availability_sets; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_availability_sets (id, name, location, provider_id, update_domain_count, fault_domain_count, managed, azure_resource_type, account_id, adapter_id, region_id, subscription_id, resource_group_id, kumo_service_id, created_at, updated_at, depends_on, virtual_machines) FROM stdin;
\.


--
-- Data for Name: azure_compliance_checks; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_compliance_checks (id, azure_compliance_standard_id, check_id, check_section, check_sub_section, check_rule, description, check_type, file_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: azure_compliance_policies; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_compliance_policies (id, azure_compliance_check_id, display_name, description, name, policy_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: azure_compliance_standards; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_compliance_standards (id, standard_type, standard_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: azure_cost_summaries; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_cost_summaries (id, hourly_cost, usage_cost, kumo_service_id, summary, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: azure_disks; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_disks (id, name, location, provider_id, create_option, image_reference, azure_resource_type, account_id, adapter_id, region_id, subscription_id, resource_group_id, kumo_service_id, created_at, updated_at, disk_size, depends_on, account_type, os_type, vhd_uri, caching, lun, disk_type) FROM stdin;
\.


--
-- Data for Name: azure_export_configurations; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_export_configurations (id, name, container, directory, subscription_id, storage_account_id, resource_group_name, status, adapter_id, created_at, updated_at, error_message, scope, billing_account_id, scope_id) FROM stdin;
\.


--
-- Data for Name: azure_load_balancers; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_load_balancers (id, name, location, provider_id, frontend_ip_configurations, backend_address_pools, load_balancing_rules, probes, inbound_nat_rules, outbound_nat_rules, inbound_nat_pools, azure_resource_type, account_id, adapter_id, region_id, subscription_id, resource_group_id, kumo_service_id, created_at, updated_at, lb_type, depends_on) FROM stdin;
\.


--
-- Data for Name: azure_network_interfaces; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_network_interfaces (id, name, location, azure_resource_type, ip_configurations, enable_ip_forwarding, dns_settings, provider_id, account_id, adapter_id, region_id, subscription_id, resource_group_id, kumo_service_id, created_at, updated_at, dns_servers, applied_dns_servers, mac_address, depends_on, security_group) FROM stdin;
\.


--
-- Data for Name: azure_price_lists; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_price_lists (id, subscription_id, sku_details, created_at, updated_at, region_code, resource_type) FROM stdin;
\.


--
-- Data for Name: azure_public_ip_addresses; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_public_ip_addresses (id, name, location, azure_resource_type, public_ipallocation_method, idle_timeout_in_minutes, ip_address, provider_id, account_id, adapter_id, region_id, subscription_id, resource_group_id, kumo_service_id, created_at, updated_at, domain_name_label, depends_on) FROM stdin;
\.


--
-- Data for Name: azure_rate_cards; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_rate_cards (id, rates, subscription_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: azure_resource_connections; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_resource_connections (resource_id, associated_resource_id) FROM stdin;
\.


--
-- Data for Name: azure_resource_groups; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_resource_groups (id, name, location, provider_id, properties, account_id, adapter_id, region_id, subscription_id, created_at, updated_at, tags, state) FROM stdin;
\.


--
-- Data for Name: azure_resources; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_resources (id, name, type, provider_id, adapter_id, region_id, provider_data, data, error_message, additional_properties, cost_by_hour, tags, created_at, updated_at, azure_resource_group_id, state, idle_instance, meter_data, ignored_from) FROM stdin;
\.


--
-- Data for Name: azure_rg_service_forecast_costs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_rg_service_forecast_costs (id, subscription_id, adapter_id, tab, cost, account_id, created_at, updated_at, resource_group, month, currency) FROM stdin;
\.


--
-- Data for Name: azure_route_tables; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_route_tables (id, name, location, routes, provider_id, azure_resource_type, account_id, adapter_id, region_id, subscription_id, resource_group_id, kumo_service_id, created_at, updated_at, depends_on) FROM stdin;
\.


--
-- Data for Name: azure_security_groups; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_security_groups (id, name, location, inbound_security_rules, outbound_security_rules, provider_id, azure_resource_type, account_id, adapter_id, region_id, subscription_id, resource_group_id, kumo_service_id, created_at, updated_at, depends_on) FROM stdin;
\.


--
-- Data for Name: azure_service_forecast_costs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_service_forecast_costs (id, subscription_id, tab, cost, account_id, created_at, updated_at, adapter_id, month, net_cost, margin_cost, discount_cost, currency) FROM stdin;
\.


--
-- Data for Name: azure_sql_db_servers; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_sql_db_servers (id, name, location, provider_id, azure_resource_type, kind, account_id, adapter_id, region_id, subscription_id, resource_group_id, kumo_service_id, created_at, updated_at, fully_qualified_domain_name, administrator_login, external_administrator_login, external_administrator_sid, version, db_server_state, depends_on) FROM stdin;
\.


--
-- Data for Name: azure_sql_dbs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_sql_dbs (id, name, location, provider_id, azure_resource_type, kind, edition, status, service_level_objective, "collation", creation_date, default_secondary_location, earliest_restore_date, elastic_pool_name, containment_state, read_scale, failover_group_id, max_size, account_id, adapter_id, region_id, subscription_id, resource_group_id, kumo_service_id, created_at, updated_at, max_size_bytes, sample_name, depends_on) FROM stdin;
\.


--
-- Data for Name: azure_storage_accounts; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_storage_accounts (id, name, location, provider_id, azure_resource_type, kind, sku_name, sku_tier, account_id, adapter_id, region_id, subscription_id, resource_group_id, kumo_service_id, created_at, updated_at, depends_on) FROM stdin;
\.


--
-- Data for Name: azure_subnets; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_subnets (id, name, location, address_prefix, provider_id, azure_resource_type, account_id, adapter_id, region_id, subscription_id, resource_group_id, kumo_service_id, created_at, updated_at, depends_on, security_group, route_table) FROM stdin;
\.


--
-- Data for Name: azure_subscriptions; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_subscriptions (id, display_name, subscription_id, adapter_id, subscription_policies, authorization_source, state, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: azure_tenant_billing_adapters; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_tenant_billing_adapters (id, organisation_id, tenant_id, billing_adapter_id, created_at, updated_at, is_total_selected) FROM stdin;
\.


--
-- Data for Name: azure_usage_costs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_usage_costs (id, start_datetime, end_datetime, aggregate_usage_cost, subscription_id, aggregation_granularity, show_details, api_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: azure_virtual_machines; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_virtual_machines (id, name, location, provider_id, vm_size, network_interfaces, availability_set, os_profile, publisher, offer, sku, version, azure_resource_type, account_id, adapter_id, region_id, subscription_id, resource_group_id, kumo_service_id, created_at, updated_at, operating_system, diagnostics_profile, depends_on, filer_volumes) FROM stdin;
\.


--
-- Data for Name: azure_vnets; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.azure_vnets (id, name, location, address_prefixes, provider_id, azure_resource_type, account_id, adapter_id, region_id, subscription_id, resource_group_id, kumo_service_id, created_at, updated_at, depends_on) FROM stdin;
\.


--
-- Data for Name: backup_policies; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.backup_policies (id, name, environment_ids, backupable_services, region_id, adapter_id, account_id, created_by_user_id, updated_by_user_id, created_at, updated_at, data, is_bunker_option, is_source_copy, is_backup_retention, retention_period) FROM stdin;
\.


--
-- Data for Name: billing_currencies; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.billing_currencies (id, type, currency, symbol, adapter_id, is_default) FROM stdin;
\.


--
-- Data for Name: cloud_resource_adapters; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.cloud_resource_adapters (id, name, endpoint, credentials, account_id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: clusters; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.clusters (id, data, provider_data, error_message, state, provider_id, archived, type, account_id, region_id, created_at, updated_at, environment_id) FROM stdin;
\.


--
-- Data for Name: clusters_environments; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.clusters_environments (id, environment_id, cluster_id) FROM stdin;
\.


--
-- Data for Name: compliance_checks; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.compliance_checks (id, compliance_standard_id, check_id, check_section, check_sub_section, check_rule, check_type, check_automated, check_kumo_ids, created_at, updated_at, description) FROM stdin;
\.


--
-- Data for Name: compliance_standards; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.compliance_standards (id, standard_type, standard_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: connections; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.connections (id, interface_id, remote_interface_id, created_at, updated_at, internal) FROM stdin;
\.


--
-- Data for Name: cost_summaries; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.cost_summaries (id, blended_cost, unblended_cost, date, environment_id, account_id, adapter_id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: costs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.costs (id, blended_cost, unblended_cost, availability_zone, resource_id, resource_type, date, type, service_id, environment_id, account_id, adapter_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: credit_cards; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.credit_cards (id, card_holder, card_number, card_expiry, token, response_data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: currency_configurations; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.currency_configurations (id, cloud_provider_currency, default_currency, exchange_rates, organisation_id, created_at, updated_at, provider) FROM stdin;
\.


--
-- Data for Name: custom_dashboards; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.custom_dashboards (id, name, "dashboardHeight", type, widgets, organisation_id, created_at, updated_at, user_id, shared_with_roles, shared_with, shared_at) FROM stdin;
\.


--
-- Data for Name: dashboard_data; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.dashboard_data (id, account_id, name, data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_notifications; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.email_notifications (id, name, notify, notify_using_tag, append_domain, custom_emails, notification_roles, notification_users, notify_condition, service_ids, type, account_id, created_at, updated_at, creater, service_type, severity, notify_to_tag_key, adapter_id, tenant_id) FROM stdin;
\.


--
-- Data for Name: email_templates; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.email_templates (id, type, subject, body, link, data, account_id, organisation_id, template_type) FROM stdin;
\.


--
-- Data for Name: encryption_keys; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.encryption_keys (id, key_alias, description, key_id, arn, enabled, key_usage, aws_account_id, creation_date, account_id, adapter_id, region_id, state, created_at, updated_at, key_state, key_enabled, key_rotation_enabled, key_policy_exposed, key_policy) FROM stdin;
\.


--
-- Data for Name: environment_adapters; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.environment_adapters (id, environment_id, adapter_id) FROM stdin;
\.


--
-- Data for Name: environment_filer_volumes; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.environment_filer_volumes (id, environment_id, filer_volume_id) FROM stdin;
\.


--
-- Data for Name: environment_jobs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.environment_jobs (id, environment_id, job_id, action) FROM stdin;
\.


--
-- Data for Name: environment_kumo_services; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.environment_kumo_services (id, environment_id, kumo_service_id) FROM stdin;
\.


--
-- Data for Name: environment_services; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.environment_services (id, environment_id, service_id) FROM stdin;
\.


--
-- Data for Name: environment_storages; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.environment_storages (id, storage_id, environment_id) FROM stdin;
\.


--
-- Data for Name: environment_tags; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.environment_tags (id, environment_id, tag_key, tag_type, tag_value, is_mandatory, account_id, created_by, updated_by, created_at, updated_at, applied_type, selected_type, applicable_services, overridable_services, description, override_service_tags, data, apply_naming_param) FROM stdin;
\.


--
-- Data for Name: environment_vpcs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.environment_vpcs (id, environment_id, vpc_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: environments; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.environments (id, name, state, template_id, account_id, default_adapter_id, locked, created_at, updated_at, desired_state, key_id, friendly_id, region_id, application_id, "position", created_by, updated_by, environment_model, tag_id, user_role_ids, data, revision, description, subscription_id) FROM stdin;
\.


--
-- Data for Name: environments_tasks; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.environments_tasks (id, environment_id, task_id) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.events (id, data, type, created_at, updated_at, account_id) FROM stdin;
\.


--
-- Data for Name: filer_configurations; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.filer_configurations (id, region_id, adapter_id, account_id, security_group_id, vpc_id, filer_id, protocol, name, type, created_at, updated_at, storage_vm_id) FROM stdin;
\.


--
-- Data for Name: filer_services; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.filer_services (id, filer_id, service_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: filer_volumes; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.filer_volumes (id, name, svm_name, root_volume, state, provider_volume_type, data, filer_id, cloud_resource_adapter_id, account_id, created_at, updated_at, type, actual_protocol, error_message, export_policy_info, snapshot_policy, size_info, thin_provisioning, deduplication, compression, aggregate_name, share_name, access, aggregate_id, kumo_service_id) FROM stdin;
\.


--
-- Data for Name: filers; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.filers (id, data, cloud_resource_adapter_id, account_id, type, public_id, name, tenant_id, created_at, updated_at, enabled, working_environment_type, cloud_provider_name) FROM stdin;
\.


--
-- Data for Name: follow_up_email_histories; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.follow_up_email_histories (id, follow_up_email_id, scheduled_at, processed_at, status, process_status, created_at, updated_at, event_type) FROM stdin;
\.


--
-- Data for Name: follow_up_emails; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.follow_up_emails (id, user_id, account_id, followup_for, status, start_at, finish_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gcp_compute_pricings; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.gcp_compute_pricings (id, name, sku, description, service_name, resource_family, resource_group, usage_type, pricing_info, service_regions, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gcp_multi_regionals; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.gcp_multi_regionals (id, name, code, adapter_id, created_at, updated_at) FROM stdin;
06422332-005d-4e22-9f0d-7177ecbebc08    Asia    asia    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.862633  2022-09-27 11:04:46.862633
dc0055ca-0f49-4360-bb8e-ebfac5ee2140    Europe  eu  dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.868536  2022-09-27 11:04:46.868536
0c4a1e8c-b2b5-4a69-bf8d-3a9ece18f72e    United States   us  dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.873917  2022-09-27 11:04:46.873917
\.


--
-- Data for Name: gcp_report_configurations; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.gcp_report_configurations (id, status, adapter_id, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gcp_resource_zones; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.gcp_resource_zones (id, zone_name, code, region_id, adapter_id, created_at, updated_at) FROM stdin;
2a3cf437-1b59-40f5-ac79-b47d7dfcaab9    us-east1-b  us-east1-b  134425c7-a5e0-4333-ad4a-564f2a663b0c    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.119392  2022-09-27 11:04:46.119392
a3329aed-6b08-4a8a-9287-2ec460a59708    us-east1-c  us-east1-c  134425c7-a5e0-4333-ad4a-564f2a663b0c    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.127144  2022-09-27 11:04:46.127144
c708534a-0cf3-43f7-a967-cea0ed66282a    us-east1-d  us-east1-d  134425c7-a5e0-4333-ad4a-564f2a663b0c    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.134469  2022-09-27 11:04:46.134469
fc240861-951f-4350-85fe-437c0a9aab5a    us-east4-c  us-east4-c  63730c49-7bbc-4fbb-9955-1bd3bd0558b2    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.141964  2022-09-27 11:04:46.141964
0b74644f-d060-4abc-8ad8-205be378cc5c    us-east4-b  us-east4-b  63730c49-7bbc-4fbb-9955-1bd3bd0558b2    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.149291  2022-09-27 11:04:46.149291
282b3e39-5b50-4edd-95b8-5e09fff7a43c    us-east4-a  us-east4-a  63730c49-7bbc-4fbb-9955-1bd3bd0558b2    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.156324  2022-09-27 11:04:46.156324
15c5ff57-ea0f-4f74-975c-62e27795ce0d    us-central1-c   us-central1-c   7bcf8c97-2722-46c7-a6f7-8c4bf5ba6dc3    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.16354   2022-09-27 11:04:46.16354
65d6c62a-272c-46ac-ba23-cd8999a79961    us-central1-a   us-central1-a   7bcf8c97-2722-46c7-a6f7-8c4bf5ba6dc3    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.171555  2022-09-27 11:04:46.171555
85c5cea6-3321-46f0-8ea7-0166e71dd753    us-central1-f   us-central1-f   7bcf8c97-2722-46c7-a6f7-8c4bf5ba6dc3    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.179977  2022-09-27 11:04:46.179977
f8d00cc8-3867-40e2-b02f-2260502073f7    us-central1-b   us-central1-b   7bcf8c97-2722-46c7-a6f7-8c4bf5ba6dc3    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.187069  2022-09-27 11:04:46.187069
746156b3-9578-4ef1-ae40-b1c870f4ace6    us-west1-b  us-west1-b  02adfb56-cca7-4e21-9f45-f06871069537    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.194185  2022-09-27 11:04:46.194185
e98d52fd-208d-4651-a1ac-3c33dfa89ae4    us-west1-c  us-west1-c  02adfb56-cca7-4e21-9f45-f06871069537    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.200847  2022-09-27 11:04:46.200847
0c164c6c-34c9-47f5-a18b-35a041f7363a    us-west1-a  us-west1-a  02adfb56-cca7-4e21-9f45-f06871069537    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.208026  2022-09-27 11:04:46.208026
cdbe16c3-596d-446c-b2fb-6f0a9d1b31de    europe-west4-a  europe-west4-a  b39071d3-f6fc-46f1-9e03-a47d04a83856    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.304082  2022-09-27 11:04:46.304082
d4233e9d-1357-42c3-8702-f62b91172570    europe-west4-b  europe-west4-b  b39071d3-f6fc-46f1-9e03-a47d04a83856    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.320742  2022-09-27 11:04:46.320742
194ccfdf-4bad-4f75-bb06-05d8c7b96dcd    europe-west4-c  europe-west4-c  b39071d3-f6fc-46f1-9e03-a47d04a83856    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.337632  2022-09-27 11:04:46.337632
24403e77-27ae-45c5-8b32-2fde5184823c    europe-west1-b  europe-west1-b  05ce423a-c73b-4d17-8db5-3d598f6f10e7    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.348805  2022-09-27 11:04:46.348805
c62b02aa-993a-438b-841b-2b3dee49de5f    europe-west1-d  europe-west1-d  05ce423a-c73b-4d17-8db5-3d598f6f10e7    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.357255  2022-09-27 11:04:46.357255
ece16bbd-48a4-4c97-9adc-528042d16831    europe-west1-c  europe-west1-c  05ce423a-c73b-4d17-8db5-3d598f6f10e7    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.364748  2022-09-27 11:04:46.364748
aa2278e6-8f79-44cb-8247-cd0515dcf09e    europe-west3-c  europe-west3-c  2070b256-0b5c-49b0-9b48-e28bb24c921e    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.371946  2022-09-27 11:04:46.371946
904d1b9a-8d14-4075-b19f-1cd15760135c    europe-west3-a  europe-west3-a  2070b256-0b5c-49b0-9b48-e28bb24c921e    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.379012  2022-09-27 11:04:46.379012
b6b05551-861f-45ab-ab0b-2ee47c26d8ea    europe-west3-b  europe-west3-b  2070b256-0b5c-49b0-9b48-e28bb24c921e    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.386293  2022-09-27 11:04:46.386293
ac1bc588-9352-470b-9886-299e4b7c1e8f    europe-west2-c  europe-west2-c  eaf424de-2874-460b-bac6-5af2c5561144    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.393889  2022-09-27 11:04:46.393889
301e92eb-f0b2-4255-9545-7a168cf47a7c    europe-west2-b  europe-west2-b  eaf424de-2874-460b-bac6-5af2c5561144    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.400909  2022-09-27 11:04:46.400909
4d429756-78c8-49ac-83cb-efa08c4c1c0f    europe-west2-a  europe-west2-a  eaf424de-2874-460b-bac6-5af2c5561144    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.408286  2022-09-27 11:04:46.408286
37d99c6c-ccd2-4d0c-9b0a-1f42e6f30ccc    asia-east1-b    asia-east1-b    4ffbf355-61cd-4667-afd2-96ffa1baafc8    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.415365  2022-09-27 11:04:46.415365
54428285-ca20-44ce-8b08-5646f7ae1010    asia-east1-a    asia-east1-a    4ffbf355-61cd-4667-afd2-96ffa1baafc8    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.422597  2022-09-27 11:04:46.422597
90d76f61-3bd1-4594-b645-4b9e72d99d59    asia-east1-c    asia-east1-c    4ffbf355-61cd-4667-afd2-96ffa1baafc8    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.429732  2022-09-27 11:04:46.429732
1de5d45a-142b-42f9-8b46-acc74a817ff5    asia-southeast1-b   asia-southeast1-b   0211fdc1-5049-4f72-b070-47e1a2c359e2    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.436477  2022-09-27 11:04:46.436477
f2a9884d-971d-49b6-a097-9e411b951e36    asia-southeast1-a   asia-southeast1-a   0211fdc1-5049-4f72-b070-47e1a2c359e2    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.443747  2022-09-27 11:04:46.443747
67b6e649-ef9f-4f5d-a505-f689baba7c4f    asia-southeast1-c   asia-southeast1-c   0211fdc1-5049-4f72-b070-47e1a2c359e2    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.469219  2022-09-27 11:04:46.469219
7aaf2f77-3450-4921-be9b-d3023b47dc4d    asia-northeast1-b   asia-northeast1-b   50a178f5-928e-4a8e-bcdb-2a6d6c9840fe    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.476777  2022-09-27 11:04:46.476777
74ef812e-2301-4009-a34c-75167afebf3d    asia-northeast1-c   asia-northeast1-c   50a178f5-928e-4a8e-bcdb-2a6d6c9840fe    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.484216  2022-09-27 11:04:46.484216
d6a9e611-588b-43cb-8270-98689d51ad71    asia-northeast1-a   asia-northeast1-a   50a178f5-928e-4a8e-bcdb-2a6d6c9840fe    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.491776  2022-09-27 11:04:46.491776
869d8e38-4552-452d-b648-30ea1e883562    asia-south1-c   asia-south1-c   a21f57da-fe42-499b-a56b-20806df9ba36    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.498793  2022-09-27 11:04:46.498793
355e076f-55bd-4aca-bcc2-3163a6ca24ff    asia-south1-b   asia-south1-b   a21f57da-fe42-499b-a56b-20806df9ba36    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.505576  2022-09-27 11:04:46.505576
400ad9a7-69e4-465a-92f6-d5d09f743414    asia-south1-a   asia-south1-a   a21f57da-fe42-499b-a56b-20806df9ba36    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.512544  2022-09-27 11:04:46.512544
c3254375-31c4-4051-b78c-167f1e42237b    australia-southeast1-b  australia-southeast1-b  bfb17f6c-6641-4f46-b219-c554b6693014    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.519763  2022-09-27 11:04:46.519763
a2dc7d0f-dbec-4b96-9413-120819ed127e    australia-southeast1-c  australia-southeast1-c  bfb17f6c-6641-4f46-b219-c554b6693014    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.52655   2022-09-27 11:04:46.52655
69d762a8-f710-4900-b6e4-bf23de6a1b6f    australia-southeast1-a  australia-southeast1-a  bfb17f6c-6641-4f46-b219-c554b6693014    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.533178  2022-09-27 11:04:46.533178
a9e3181d-1388-48ff-92f5-a204e280e2e0    southamerica-east1-b    southamerica-east1-b    7f0592a2-ec2b-4bc9-a8c5-c9104ff94899    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.540525  2022-09-27 11:04:46.540525
bacd8e12-5e40-414d-ba9a-ffd1c27e3b72    southamerica-east1-c    southamerica-east1-c    7f0592a2-ec2b-4bc9-a8c5-c9104ff94899    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.548086  2022-09-27 11:04:46.548086
8e65dd06-ae48-413b-8a46-b871f82f6d81    southamerica-east1-a    southamerica-east1-a    7f0592a2-ec2b-4bc9-a8c5-c9104ff94899    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.554889  2022-09-27 11:04:46.554889
35400313-e17c-428c-9e04-b057894b85cc    asia-east2-a    asia-east2-a    8df4b4c8-b078-47ec-aaea-611ccfbbcdb3    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.561222  2022-09-27 11:04:46.561222
419a3d06-7bd0-48fa-9df8-60f7b8f496ec    asia-east2-b    asia-east2-b    8df4b4c8-b078-47ec-aaea-611ccfbbcdb3    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.567954  2022-09-27 11:04:46.567954
b491c50b-7130-4bde-89ac-74a2417bde5f    asia-east2-c    asia-east2-c    8df4b4c8-b078-47ec-aaea-611ccfbbcdb3    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.574703  2022-09-27 11:04:46.574703
d09e4f67-7e16-4c1c-9cb5-1bfa921e766c    asia-northeast2-a   asia-northeast2-a   cd370e7d-551c-426f-ac76-675fc6744d2c    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.582141  2022-09-27 11:04:46.582141
f817008f-3f82-404d-a918-68cb7a1fadc6    asia-northeast2-b   asia-northeast2-b   cd370e7d-551c-426f-ac76-675fc6744d2c    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.588642  2022-09-27 11:04:46.588642
488dc6ab-303f-4e47-abcb-58a325872497    asia-northeast2-c   asia-northeast2-c   cd370e7d-551c-426f-ac76-675fc6744d2c    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.595839  2022-09-27 11:04:46.595839
c0919291-a246-4676-8555-3d97bd2c5686    asia-northeast3-a   asia-northeast3-a   d373ae4b-17c4-4069-b9e1-8e7eef449628    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.602419  2022-09-27 11:04:46.602419
d1bbb232-f04d-4850-ba47-53c6b48beea9    asia-northeast3-b   asia-northeast3-b   d373ae4b-17c4-4069-b9e1-8e7eef449628    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.60912   2022-09-27 11:04:46.60912
f9803dca-88cf-48ad-8b82-574c0377b99c    asia-northeast3-c   asia-northeast3-c   d373ae4b-17c4-4069-b9e1-8e7eef449628    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.615432  2022-09-27 11:04:46.615432
886a8030-820a-4b01-bd10-354575823c4b    asia-south2-a   asia-south2-a   5f8b01c2-9df2-4580-aed4-d32a6368288d    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.621921  2022-09-27 11:04:46.621921
2d27d2fb-4faa-4760-854f-56d4300dfc98    asia-south2-b   asia-south2-b   5f8b01c2-9df2-4580-aed4-d32a6368288d    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.628858  2022-09-27 11:04:46.628858
70877f09-b75a-4f68-8209-49ca156eecef    asia-south2-c   asia-south2-c   5f8b01c2-9df2-4580-aed4-d32a6368288d    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.636255  2022-09-27 11:04:46.636255
c6b36bf9-8be8-4725-bae4-7ecbb588ffdf    asia-southeast2-a   asia-southeast2-a   44aceaeb-ded0-4667-b1b2-aa1540806978    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.644062  2022-09-27 11:04:46.644062
42153353-d76e-4c38-9a0e-2449776adb9d    asia-southeast2-b   asia-southeast2-b   44aceaeb-ded0-4667-b1b2-aa1540806978    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.651005  2022-09-27 11:04:46.651005
10f7f303-38ad-4ad6-b342-e0956f921e5f    asia-southeast2-c   asia-southeast2-c   44aceaeb-ded0-4667-b1b2-aa1540806978    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.657893  2022-09-27 11:04:46.657893
88e38750-1ce4-482f-8e0a-a0c1d45396cd    australia-southeast2-a  australia-southeast2-a  7b0c1bb1-c886-41f5-9060-c4d939325b7c    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.664615  2022-09-27 11:04:46.664615
6ff1d16a-48b0-428f-8f5f-63eda3039eea    australia-southeast2-b  australia-southeast2-b  7b0c1bb1-c886-41f5-9060-c4d939325b7c    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.671616  2022-09-27 11:04:46.671616
de566d38-129f-4e21-9bfe-e83979f8d4f0    australia-southeast2-c  australia-southeast2-c  7b0c1bb1-c886-41f5-9060-c4d939325b7c    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.678784  2022-09-27 11:04:46.678784
c0ad0927-c58e-4be7-addf-b39f58cda895    europe-central2-a   europe-central2-a   2b5832a4-d65c-4341-86c0-56feaa69e4c2    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.686138  2022-09-27 11:04:46.686138
e82f872c-02ea-4235-b985-1d667e9b2db7    europe-central2-b   europe-central2-b   2b5832a4-d65c-4341-86c0-56feaa69e4c2    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.693241  2022-09-27 11:04:46.693241
46b15391-aae4-4453-8a9b-46623520db8d    europe-central2-c   europe-central2-c   2b5832a4-d65c-4341-86c0-56feaa69e4c2    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.700086  2022-09-27 11:04:46.700086
53e14fca-090f-48e2-a754-6fd494913679    europe-north1-a europe-north1-a 4ffc3e22-1257-41ce-8fa5-3b850511d049    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.707063  2022-09-27 11:04:46.707063
65ed07f4-d3dc-49cd-acd9-c60f326360d8    europe-north1-b europe-north1-b 4ffc3e22-1257-41ce-8fa5-3b850511d049    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.713959  2022-09-27 11:04:46.713959
1c23b49a-c808-4bfb-bdc9-2bb5dcfec9af    europe-north1-c europe-north1-c 4ffc3e22-1257-41ce-8fa5-3b850511d049    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.720884  2022-09-27 11:04:46.720884
4b1afbe3-19e4-45c2-ac63-f5d197c9d1e1    europe-west6-a  europe-west6-a  6f815dbc-5251-4256-8e38-e1aa66afce6d    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.727658  2022-09-27 11:04:46.727658
dc060a12-d0c3-4d23-85dc-f8512e73ae18    europe-west6-b  europe-west6-b  6f815dbc-5251-4256-8e38-e1aa66afce6d    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.73464   2022-09-27 11:04:46.73464
d0b3a19e-cd9b-4422-9044-997e0b9a26f2    europe-west6-c  europe-west6-c  6f815dbc-5251-4256-8e38-e1aa66afce6d    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.741798  2022-09-27 11:04:46.741798
e97477a3-f8c1-4483-80e7-db228a79eb38    northamerica-northeast1-a   northamerica-northeast1-a   e44e6a81-4cc8-40f1-ad27-d7580e9c26cf    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.749177  2022-09-27 11:04:46.749177
45954ed4-c284-4a9f-9d25-dc534b1e82c1    northamerica-northeast1-b   northamerica-northeast1-b   e44e6a81-4cc8-40f1-ad27-d7580e9c26cf    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.755749  2022-09-27 11:04:46.755749
7fab2b63-56bb-48c7-b0d1-456c500d0030    northamerica-northeast1-c   northamerica-northeast1-c   e44e6a81-4cc8-40f1-ad27-d7580e9c26cf    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.762799  2022-09-27 11:04:46.762799
18c96bbc-2cad-471d-b48b-b1f51a0a6b3e    northamerica-northeast2-a   northamerica-northeast2-a   31060f68-50e0-43e9-ac92-d09a6cb665fc    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.769679  2022-09-27 11:04:46.769679
a502da2f-cb6c-4ae6-91eb-364794be7d81    northamerica-northeast2-b   northamerica-northeast2-b   31060f68-50e0-43e9-ac92-d09a6cb665fc    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.776685  2022-09-27 11:04:46.776685
b4aeb294-28d5-4ed6-9ea4-339f782ce548    northamerica-northeast2-c   northamerica-northeast2-c   31060f68-50e0-43e9-ac92-d09a6cb665fc    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.783615  2022-09-27 11:04:46.783615
4c8d61b9-2c63-43a8-a5a3-4d3da1987239    us-west2-a  us-west2-a  e296d2fc-0f34-4b1a-8f82-68f7acab138b    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.7907    2022-09-27 11:04:46.7907
cb5b423e-12f7-4055-82b4-9e88c0cea04c    us-west2-b  us-west2-b  e296d2fc-0f34-4b1a-8f82-68f7acab138b    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.797763  2022-09-27 11:04:46.797763
79e2bb40-e288-48b3-a2f1-fca10978947b    us-west2-c  us-west2-c  e296d2fc-0f34-4b1a-8f82-68f7acab138b    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.804378  2022-09-27 11:04:46.804378
3fc2cdc2-df15-4942-8e10-244fbe9395f4    us-west3-a  us-west3-a  6e61d565-720d-4a11-b4e2-ad0d2f1607e4    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.811397  2022-09-27 11:04:46.811397
60a0c619-6b30-4dc9-bdc5-bf3afa130539    us-west3-b  us-west3-b  6e61d565-720d-4a11-b4e2-ad0d2f1607e4    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.818037  2022-09-27 11:04:46.818037
28226bf5-de31-4730-9b62-c7f845130b7a    us-west3-c  us-west3-c  6e61d565-720d-4a11-b4e2-ad0d2f1607e4    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.825498  2022-09-27 11:04:46.825498
5fdee602-1820-47c6-be41-21baf42e95b7    us-west4-a  us-west4-a  f5ba1685-fe60-497a-92a7-f50064041c71    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.832542  2022-09-27 11:04:46.832542
e6249d5f-0baf-4746-8dae-c695be725c12    us-west4-b  us-west4-b  f5ba1685-fe60-497a-92a7-f50064041c71    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.839741  2022-09-27 11:04:46.839741
653040d5-5844-4948-9748-bceb778b68ee    us-west4-c  us-west4-c  f5ba1685-fe60-497a-92a7-f50064041c71    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.847681  2022-09-27 11:04:46.847681
\.


--
-- Data for Name: gcp_resources; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.gcp_resources (id, name, type, provider_id, provider_data, data, error_message, additional_properties, cost_by_hour, tags, state, idle_instance, meter_data, ignored_from, adapter_id, region_id, gcp_resource_zone_id, created_at, updated_at, gcp_multi_regional_id) FROM stdin;
\.


--
-- Data for Name: gcp_service_forecast_costs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.gcp_service_forecast_costs (id, tab, cost, account_id, created_at, updated_at, adapter_id, project_id, month) FROM stdin;
\.


--
-- Data for Name: gcp_tenant_billing_adapters; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.gcp_tenant_billing_adapters (id, organisation_id, tenant_id, billing_adapter_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: general_settings; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.general_settings (id, naming_convention_enabled, account_id, created_at, updated_at, ip_auto_increment_enabled, applicationwise_monthly_budget, email_domain, is_tag_case_insensitive, time_zone, default_tenant_visibility) FROM stdin;
\.


--
-- Data for Name: group_roles; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.group_roles (id, name, resource_id, resource_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.groups (id, name, organisation_id, account_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: groups_roles; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.groups_roles (group_id, group_role_id) FROM stdin;
\.


--
-- Data for Name: groups_users; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.groups_users (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: iam_certificates; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.iam_certificates (id, path, server_certificate_name, server_certificate_id, arn, upload_date, expiration, aws_account_id, created_at, updated_at, account_id) FROM stdin;
\.


--
-- Data for Name: iam_groups; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.iam_groups (id, adapter_id, account_id, group_id, arn, group_name, create_date, aws_account_id, path, users, created_at, updated_at, list_group_policies) FROM stdin;
\.


--
-- Data for Name: iam_roles; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.iam_roles (id, aws_account_id, role, arn, instance_profile_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: iam_user_role_policies; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.iam_user_role_policies (id, policy_id, iam_id, iam_type, created_at, updated_at, adapter_id, aws_account_id) FROM stdin;
\.


--
-- Data for Name: iam_users; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.iam_users (id, path, user_name, user_id, arn, create_date, password_last_used, permissions_boundary, tags, password_enabled, password_last_changed, password_next_rotation, mfa_active, access_key_1_active, access_key_1_last_rotated, access_key_1_last_used_date, access_key_1_last_used_region, access_key_1_last_used_service, access_key_2_active, access_key_2_last_rotated, access_key_2_last_used_date, access_key_2_last_used_region, access_key_2_last_used_service, cert_1_active, cert_1_last_rotated, cert_2_active, cert_2_last_rotated, aws_account_id, created_at, updated_at, adapter_id, ssh_public_keys, access_keys_list, login_profile, list_mfa_devices, virtual_mfa_devices) FROM stdin;
\.


--
-- Data for Name: instance_filer_volumes; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.instance_filer_volumes (id, service_id, filer_volume_id) FROM stdin;
\.


--
-- Data for Name: instance_planners; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.instance_planners (id, account_id, region_id, adapter_id, total_instances, active_standard, active_scheduled, unused_standard, unused_scheduled, ec2_covered, ec2_uncovered, potential_benifit, data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: integration_user_roles; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.integration_user_roles (id, integration_id, user_role_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: integrations; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.integrations (id, name, user_id, account_id, workspace_id, organisation_id, data, slack_members, modules, type, state, is_mute, created_at, updated_at, all_roles_selected) FROM stdin;
\.


--
-- Data for Name: interfaces; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.interfaces (id, service_id, name, interface_type, created_at, updated_at, depends) FROM stdin;
\.


--
-- Data for Name: internet_gateways; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.internet_gateways (id, name, state, type, provider_id, provider_data, vpc_id, account_id, adapter_id, region_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.invoices (id, payment_due_date, payment_date, payment_status, data, account_id, created_at, updated_at, invoice_number) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.jobs (id, log_id, state, bg_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: kumo_services; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.kumo_services (id, name, service_type, state, provider_id, account_id, adapter_id, region_id, subscription_id, created_at, updated_at, metadata, error_message) FROM stdin;
\.


--
-- Data for Name: kumo_services_tag_key_values; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.kumo_services_tag_key_values (id, kumo_service_id, tag_key_value_id) FROM stdin;
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.logs (id, job_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: machine_image_configurations; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.machine_image_configurations (id, organisation_image_id, name, userdata, user_role_ids, created_at, updated_at, instance_types, account_id, is_template, ami_config_category_id, rundata) FROM stdin;
\.


--
-- Data for Name: machine_image_configurations_soe_scripts; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.machine_image_configurations_soe_scripts (id, machine_image_configuration_id, soe_script_id, soe_script_type) FROM stdin;
\.


--
-- Data for Name: machine_image_groups; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.machine_image_groups (id, name, match_key, virtualization_type, image_owner_alias, root_device_type, image_owner_id, architecture, image_type, is_public, platform, region_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: machine_images; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.machine_images (id, adapter_id, region_id, architecture, description, image_id, image_location, image_state, image_type, is_public, kernel_id, platform, ramdisk_id, root_device_name, root_device_type, virtualization_type, created_at, updated_at, block_device_mapping, image_owner_alias, image_owner_id, product_codes, active, name, machine_image_group_id, creation_date, cost_by_hour, service_tags, aws_account_id) FROM stdin;
\.


--
-- Data for Name: nacls; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.nacls (id, provider_id, provider_vpc_id, name, vpc_id, entries, associations, tags, type, adapter_id, provider_data, account_id, region_id) FROM stdin;
\.


--
-- Data for Name: network_interfaces; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.network_interfaces (id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organisation_adapters; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.organisation_adapters (id, organisation_id, adapter_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organisation_brands; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.organisation_brands (id, organisation_id, name, product_name, child_organisation_domain, documentation_url, support_url, login_page_title, login_page_tagline, login_page_background_image_position, login_page_background_image_overlay_color, login_text_color, show_privacy_policy_url, privacy_policy_url, privacy_policy_url_name, show_terms_of_use_url, terms_of_use_url, terms_of_use_url_name, created_at, updated_at, company_logo_public_url, fevicon_public_url, navigation_logo_public_url, login_page_logo_public_url, login_page_background_image_public_url) FROM stdin;
\.


--
-- Data for Name: organisation_details; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.organisation_details (id, data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organisation_images; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.organisation_images (account_id, machine_image_id, image_id, region_id, instance_types, image_name, image_data, id, active, user_role_ids, machine_image_group_id, ejectable, architecture, description, image_location, image_type, kernel_id, platform, ramdisk_id, root_device_name, root_device_type, virtualization_type, block_device_mapping, image_owner_alias, image_owner_id, product_codes, machine_image_name, creation_date, is_public, cost_by_hour, image_state, updated_at, aws_account_id) FROM stdin;
\.


--
-- Data for Name: organisation_images_copy; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.organisation_images_copy (account_id, machine_image_id, image_id, region_id, instance_types, image_name, image_data, id, active) FROM stdin;
\.


--
-- Data for Name: organisation_saml_users; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.organisation_saml_users (id, user_id, organisation_id, auto_assign_tenant, auto_assign_role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organisation_service_groups; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.organisation_service_groups (id, organisation_id, service_group_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organisations; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.organisations (id, name, created_at, updated_at, application_plan_id, trial_period_days, organisation_identifier, subdomain, user_id, is_active, parent_id, child_organisation_enable, report_profile_id, owner_type) FROM stdin;
\.


--
-- Data for Name: organisations_users; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.organisations_users (organisation_id, user_id, uuid, state, invite_token, invited_at, active_dashboard_id) FROM stdin;
\.


--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.payment_methods (id, user_id, account_id, payable_id, payable_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.permissions (id, user_id, name, subject_class, subject_id, action, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: policies; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.policies (id, policy_name, policy_arn, type, policy_id, group_arn, created_at, updated_at, adapter_id, aws_account_id, policy_document) FROM stdin;
\.


--
-- Data for Name: protocols; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.protocols (id, name, type, description, interface_id, data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: rds_configurations; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.rds_configurations (id, account_id, created_by, updated_by, data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.regions (id, region_name, adapter_id, created_at, updated_at, code) FROM stdin;
469bf114-26ea-4a87-8667-a87606e7a8aa    Australia East  581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.529868  2022-09-27 11:04:45.529868  australiaeast
0e1396ee-26a7-4156-a390-65d6c88eb644    Australia Southeast 581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.536364  2022-09-27 11:04:45.536364  australiasoutheast
0928157b-6a44-47c6-911f-f0635c339756    Australia Central   581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.54267   2022-09-27 11:04:45.54267   australiacentral
9282a212-6ca3-4066-9a06-cdd4d0417cd2    Australia Central 2 581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.548833  2022-09-27 11:04:45.548833  australiacentral2
a2a693fa-12c5-4d12-9d4b-58efbd737fa7    Brazil South    581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.554824  2022-09-27 11:04:45.554824  brazilsouth
0872a6b1-9756-4f11-8a94-b1206b1212a6    Canada Central  581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.560444  2022-09-27 11:04:45.560444  canadacentral
7aabf5b2-49e5-498f-b7ba-8a9b44290b57    Canada East 581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.566671  2022-09-27 11:04:45.566671  canadaeast
6356b22e-ccb5-48cc-9d48-59c5b37f6b04    Central India   581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.572804  2022-09-27 11:04:45.572804  centralindia
6b33b4de-28a5-4bd6-9f84-18d0ca4b036f    Central US  581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.578802  2022-09-27 11:04:45.578802  centralus
dc267342-ef9d-42eb-9737-2aa11928abf8    East Asia   581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.584849  2022-09-27 11:04:45.584849  eastasia
a11a4d66-8687-4db7-b859-c61046a446b7    East US 581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.591016  2022-09-27 11:04:45.591016  eastus
b2026e16-21b0-42dc-a5d8-5c20cf572b56    East US 2   581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.596897  2022-09-27 11:04:45.596897  eastus2
6b0016ce-d275-4eeb-9e55-99abc0638888    France Central  581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.602877  2022-09-27 11:04:45.602877  francecentral
5c415491-ea08-4b6e-b320-0c23041bf01f    Japan East  581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.608841  2022-09-27 11:04:45.608841  japaneast
ec0e9894-ff17-4616-8907-c69f9faacb70    Japan West  581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.614809  2022-09-27 11:04:45.614809  japanwest
35d90c58-7d31-4ec3-80d6-f0bfb180d46b    Korea Central   581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.627628  2022-09-27 11:04:45.627628  koreacentral
4d2e3aef-992c-4523-a093-a3fa96447571    Korea South 581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.638109  2022-09-27 11:04:45.638109  koreasouth
8206c1f7-31f2-43b8-b8a1-ba49dd75300e    North Central US    581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.644243  2022-09-27 11:04:45.644243  northcentralus
a3b4d18d-abb1-4387-ba00-f4a0f5fba450    North Europe    581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.650219  2022-09-27 11:04:45.650219  northeurope
32caaac3-8eab-46d2-b7a3-e2a96031931e    South Africa North  581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.655923  2022-09-27 11:04:45.655923  southafricanorth
47026148-03c9-4e90-a5dc-9c9f325a66df    South Africa West   581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.661453  2022-09-27 11:04:45.661453  southafricawest
88d4effb-0f8d-49f6-9173-5cb5f703a537    South Central US    581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.666756  2022-09-27 11:04:45.666756  southcentralus
efa9d014-6c27-42a0-9da8-1a97c2b64cf1    Southeast Asia  581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.672265  2022-09-27 11:04:45.672265  southeastasia
f990d889-fd3d-4ae6-a8b7-0209b6f28596    South India 581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.678768  2022-09-27 11:04:45.678768  southindia
7b974d1b-6592-4765-8962-700a079dd2df    UK South    581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.684366  2022-09-27 11:04:45.684366  uksouth
d9c97328-afad-4381-8fe9-51891e383fee    UK West 581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.689973  2022-09-27 11:04:45.689973  ukwest
20182362-b8c3-49d4-b598-1adc4e230383    West Central US 581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.695871  2022-09-27 11:04:45.695871  westcentralus
d3684afe-3eab-4d74-952f-3d4de60c2603    West Europe 581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.701726  2022-09-27 11:04:45.701726  westeurope
bd133ed2-5714-4ab6-8cf2-081c2be1f9cb    West India  581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.707503  2022-09-27 11:04:45.707503  westindia
4834995f-50cd-4d80-b05f-bf48f557c79d    West US 581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.713132  2022-09-27 11:04:45.713132  westus
5eb957a0-c948-4b88-b271-9e97777270e6    West US 2   581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.718732  2022-09-27 11:04:45.718732  westus2
79f2218f-1b3a-4d09-a6b8-e0f837058f67    West US 3   581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.724673  2022-09-27 11:04:45.724673  westus3
6e2e6770-59c1-4c40-b035-d73b7b2c4f60    Germany West Central    581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.730642  2022-09-27 11:04:45.730642  germanywestcentral
f1d334e9-3fd3-4ea4-a86b-0d65f8087592    Norway East 581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.735987  2022-09-27 11:04:45.735987  norwayeast
05332db1-a46e-49d8-9f59-f490afcb7fba    Switzerland North   581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.742633  2022-09-27 11:04:45.742633  switzerlandnorth
b99a9ea6-b034-41df-9ebd-7d21959f8344    UAE North   581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.748559  2022-09-27 11:04:45.748559  uaenorth
15359bbe-c3a5-4328-96a8-9bb017e133e6    China East  581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.754387  2022-09-27 11:04:45.754387  chinaeast
12df199c-abc6-4579-bf9b-30e92bbbe216    China East 2    581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.760008  2022-09-27 11:04:45.760008  chinaeast2
a8e2c67b-ce42-41f2-8118-e74961f6aa14    China North 581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.765514  2022-09-27 11:04:45.765514  chinanorth
f433a05e-2678-44b1-9ef9-7dcd7f8c2188    China North 2   581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.770958  2022-09-27 11:04:45.770958  chinanorth2
f69253be-c656-4588-af0d-19572ee96e95    USGov Virginia  581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.77679   2022-09-27 11:04:45.77679   usgovvirginia
41ac957c-b430-48dd-951e-7f4c2e5855c3    USGov Iowa  581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.782407  2022-09-27 11:04:45.782407  usgoviowa
eaddc7a5-ba1c-4434-8beb-bbd1019c0e3c    USDoD East  581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.788168  2022-09-27 11:04:45.788168  usdodeast
1bba25b3-25ef-4757-8a9e-b5af6519850b    USDoD Central   581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.794136  2022-09-27 11:04:45.794136  usdodcentral
7bbe50c3-e61b-4924-90bf-fd00c4d5055c    USGov Texas 581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.800125  2022-09-27 11:04:45.800125  usgovtexas
5d2c41db-61ab-485b-9b51-b46d7e41c183    USGov Arizona   581e83bc-daf5-4bc1-bf15-3f6324ec47e9    2022-09-27 11:04:45.805996  2022-09-27 11:04:45.805996  usgovarizona
03088374-1ad2-4454-9d05-b15656e7f79f    US East (N. Virginia)   75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.811913  2022-09-27 11:04:45.811913  us-east-1
d87c78b4-fb02-449c-8b7c-74b04ffdeabd    US West (N. California) 75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.817991  2022-09-27 11:04:45.817991  us-west-1
58d04ffa-f3e1-450d-b43e-9f8b221e74b8    US West (Oregon)    75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.82392   2022-09-27 11:04:45.82392   us-west-2
3462a53f-0e39-4940-80b0-eeb79e98dc9b    EU (Ireland)    75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.830022  2022-09-27 11:04:45.830022  eu-west-1
958eb152-550b-4394-a697-ec9c1f770bed    EU (Frankfurt)  75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.835896  2022-09-27 11:04:45.835896  eu-central-1
77fd2fc7-f4d7-46b9-a0ba-836a4b574cc3    Asia Pacific (Sydney)   75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.842373  2022-09-27 11:04:45.842373  ap-southeast-2
0c06d7a9-9bfd-446d-aabe-1e4d00cc6244    Asia Pacific (Singapore)    75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.848246  2022-09-27 11:04:45.848246  ap-southeast-1
efb5fec7-4706-4005-8ba8-cfb574aa9bd3    Asia Pacific (Tokyo)    75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.853991  2022-09-27 11:04:45.853991  ap-northeast-1
643f9e2e-ab9d-4dcd-9083-77e4705183b0    South America (Sao Paulo)   75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.859688  2022-09-27 11:04:45.859688  sa-east-1
18b3d34e-e111-48b8-bfa5-54aaf49be99b    Asia Pacific (Seoul)    75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.86559   2022-09-27 11:04:45.86559   ap-northeast-2
9ca0aa29-0ce7-4414-8118-8f9c17c97b99    Asia Pacific (Mumbai)   75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.871199  2022-09-27 11:04:45.871199  ap-south-1
a377a5d0-009a-4fbd-98a1-208c0cd7774b    US East (Ohio)  75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.876796  2022-09-27 11:04:45.876796  us-east-2
8b91c796-d640-40d6-9298-0ccff7627b53    EU (London) 75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.882534  2022-09-27 11:04:45.882534  eu-west-2
3e296ad3-6608-40ea-9b26-9918df46529d    Canada (Central)    75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.888154  2022-09-27 11:04:45.888154  ca-central-1
9d295cea-6445-4722-9f82-2178cbbe1adf    Africa (Cape Town)  75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.89369   2022-09-27 11:04:45.89369   af-south-1
1aa347ca-3c0f-43c4-9546-88273e006154    Asia Pacific (Hong Kong)    75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.899132  2022-09-27 11:04:45.899132  ap-east-1
106cefbc-78cd-4460-849d-6879cd2cd12a    EU (Milan)  75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.905698  2022-09-27 11:04:45.905698  eu-south-1
42452d69-1a91-41d2-80fb-184ba3164ee1    EU (Paris)  75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.911646  2022-09-27 11:04:45.911646  eu-west-3
48d4357f-cf37-4814-810c-63a6a41afee8    EU (Stockholm)  75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.917503  2022-09-27 11:04:45.917503  eu-north-1
dfa8e31d-a55c-4c08-9ece-10ca6aeda35b    Middle East (Bahrain)   75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.923622  2022-09-27 11:04:45.923622  me-south-1
2fe8d852-ebda-4340-a04d-2e6a069b5aa4    AWS GovCloud (US-East)  75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.929709  2022-09-27 11:04:45.929709  us-gov-east-1
487fb451-ee14-4679-9831-066d5a1efbc0    AWS GovCloud (US-West)  75748e0f-6f70-4074-aac6-71c984cd6993    2022-09-27 11:04:45.935329  2022-09-27 11:04:45.935329  us-gov-west-1
4ffbf355-61cd-4667-afd2-96ffa1baafc8    Taiwan  dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:45.948888  2022-09-27 11:04:45.948888  asia-east1
8df4b4c8-b078-47ec-aaea-611ccfbbcdb3    Hong Kong   dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:45.954955  2022-09-27 11:04:45.954955  asia-east2
50a178f5-928e-4a8e-bcdb-2a6d6c9840fe    Tokyo   dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:45.960548  2022-09-27 11:04:45.960548  asia-northeast1
cd370e7d-551c-426f-ac76-675fc6744d2c    Osaka   dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:45.96594   2022-09-27 11:04:45.96594   asia-northeast2
d373ae4b-17c4-4069-b9e1-8e7eef449628    Seoul   dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:45.971543  2022-09-27 11:04:45.971543  asia-northeast3
a21f57da-fe42-499b-a56b-20806df9ba36    Mumbai  dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:45.977664  2022-09-27 11:04:45.977664  asia-south1
5f8b01c2-9df2-4580-aed4-d32a6368288d    Delhi   dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:45.982793  2022-09-27 11:04:45.982793  asia-south2
0211fdc1-5049-4f72-b070-47e1a2c359e2    Singapore   dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:45.988683  2022-09-27 11:04:45.988683  asia-southeast1
44aceaeb-ded0-4667-b1b2-aa1540806978    Jakarta dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:45.994274  2022-09-27 11:04:45.994274  asia-southeast2
bfb17f6c-6641-4f46-b219-c554b6693014    Sydney  dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:45.99995   2022-09-27 11:04:45.99995   australia-southeast1
7b0c1bb1-c886-41f5-9060-c4d939325b7c    Melbourne   dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.00891   2022-09-27 11:04:46.00891   australia-southeast2
2b5832a4-d65c-4341-86c0-56feaa69e4c2    Warsaw  dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.014242  2022-09-27 11:04:46.014242  europe-central2
4ffc3e22-1257-41ce-8fa5-3b850511d049    Finland dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.01978   2022-09-27 11:04:46.01978   europe-north1
05ce423a-c73b-4d17-8db5-3d598f6f10e7    Belgium dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.025506  2022-09-27 11:04:46.025506  europe-west1
eaf424de-2874-460b-bac6-5af2c5561144    London  dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.031514  2022-09-27 11:04:46.031514  europe-west2
2070b256-0b5c-49b0-9b48-e28bb24c921e    Frankfurt   dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.037217  2022-09-27 11:04:46.037217  europe-west3
b39071d3-f6fc-46f1-9e03-a47d04a83856    Netherlands dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.043311  2022-09-27 11:04:46.043311  europe-west4
6f815dbc-5251-4256-8e38-e1aa66afce6d    Zurich  dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.048466  2022-09-27 11:04:46.048466  europe-west6
e44e6a81-4cc8-40f1-ad27-d7580e9c26cf    Montreal    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.054004  2022-09-27 11:04:46.054004  northamerica-northeast1
31060f68-50e0-43e9-ac92-d09a6cb665fc    Toronto dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.059518  2022-09-27 11:04:46.059518  northamerica-northeast2
7f0592a2-ec2b-4bc9-a8c5-c9104ff94899    Sao Paulo   dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.065051  2022-09-27 11:04:46.065051  southamerica-east1
7bcf8c97-2722-46c7-a6f7-8c4bf5ba6dc3    Iowa    dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.07072   2022-09-27 11:04:46.07072   us-central1
134425c7-a5e0-4333-ad4a-564f2a663b0c    South Carolina  dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.076019  2022-09-27 11:04:46.076019  us-east1
63730c49-7bbc-4fbb-9955-1bd3bd0558b2    Northern Virginia   dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.081309  2022-09-27 11:04:46.081309  us-east4
02adfb56-cca7-4e21-9f45-f06871069537    Oregon  dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.086832  2022-09-27 11:04:46.086832  us-west1
e296d2fc-0f34-4b1a-8f82-68f7acab138b    Los Angeles dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.092299  2022-09-27 11:04:46.092299  us-west2
6e61d565-720d-4a11-b4e2-ad0d2f1607e4    Salt Lake City  dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.097641  2022-09-27 11:04:46.097641  us-west3
f5ba1685-fe60-497a-92a7-f50064041c71    Las Vegas   dc92e78b-4183-4e7a-b5e1-65e2303fc4a9    2022-09-27 11:04:46.103022  2022-09-27 11:04:46.103022  us-west4
\.


--
-- Data for Name: report_configurations; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.report_configurations (id, report_name, report_prefix, compression_type, adapter_id, created_at, updated_at, status, error_message) FROM stdin;
\.


--
-- Data for Name: reserved_instances; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.reserved_instances (id, account_id, region_id, adapter_id, availability_zone, duration, fixed_price, instance_type, instance_count, product_description, reserved_instances_id, start_time, state, usage_price, end_time, data, provider_data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: resource_groups; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.resource_groups (id, name, location, tags, data, provider_data, type, subscription_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: resources; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.resources (id, name, data, type, created_at, updated_at, account_id, environment_id, region_id, adapter_id, user_role_ids) FROM stdin;
\.


--
-- Data for Name: right_size_configurations; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.right_size_configurations (id, account_id, family_type, right_size_config_check, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.roles (id, name, resource_id, resource_type, created_at, updated_at, start_date, end_date) FROM stdin;
\.


--
-- Data for Name: route_tables; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.route_tables (id, name, provider_id, type, associations, routes, provider_data, vpc_id, account_id, adapter_id, region_id, created_at, updated_at, tags) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.schema_migrations (version) FROM stdin;
20131209231700
20131209232930
20131210024136
20131216002529
20131216023111
20131216032515
20131218050647
20131218051940
20140106063149
20140113001727
20140113231303
20140113231458
20140120034816
20140120035033
20140121003128
20140121054010
20140122085421
20140122090556
20140122090827
20140128062642
20140128062707
20140128100634
20140128102533
20140128102903
20140128223923
20140129100928
20140130035144
20140202114359
20140202131218
20140202132337
20140202132445
20140203051625
20140209103341
20140211131954
20140212010306
20140212025840
20140212093639
20140212093846
20140212094024
20140212094058
20140212094224
20140212094905
20140212094928
20140212095015
20140212095036
20140212095151
20140212095250
20140212095352
20140212095426
20140212095509
20140212095538
20140212095723
20140212095739
20140212100756
20140212101047
20140212101214
20140212101449
20140212101654
20140212101939
20140212101956
20140212102059
20140212102109
20140212102121
20140212102148
20140212102201
20140212102228
20140212102238
20140212102306
20140212102333
20140212102346
20140212102439
20140212102451
20140212102504
20140212102519
20140212102535
20140212102549
20140212102614
20140212102629
20140212102648
20140212102700
20140212102825
20140212103225
20140212103319
20140212104203
20140212104320
20140212105423
20140212105435
20140212105723
20140212105733
20140212105906
20140212105917
20140216080953
20140216083628
20140216103919
20140216104151
20140216104815
20140216130449
20140217071541
20140217072737
20140218041149
20140218044719
20140313004216
20140313235632
20140313235642
20140313235746
20140406101431
20140406101935
20140406102526
20140407000843
20140416055627
20140416062441
20140501120741
20140504042813
20140504061332
20140504064635
20140504065129
20140504070450
20140504071730
20140504080940
20140504080949
20140505003456
20140505091825
20140505100655
20140505101816
20140505105631
20140505105652
20140505105701
20140515000114
20140516005041
20140520003314
20140521014711
20140606033836
20140610043503
20140619105722
20140620061127
20140704021515
20140704055916
20140704061247
20140707095154
20140924053914
20140924060818
20140924061226
20140924061517
20140924061835
20140924061946
20140924062250
20140925113503
20141001063428
20141006115655
20141015084005
20141031082934
20141031142716
20141101105742
20141103135045
20141103143936
20141107064528
20141110044110
20141110052159
20141111121358
20141112151022
20141115144115
20141115144326
20141115144900
20141117042550
20141117050256
20141124150303
20141201080140
20141202150131
20141204144321
20141210072324
20141212122118
20141213111818
20141213111842
20141217051046
20141218070013
20141222114958
20141222125419
20150106110423
20150107131807
20150109130147
20150115125240
20150128051258
20150128093526
20150204100555
20150206130728
20150209054423
20150209125703
20150210042345
20150211144623
20150212091704
20150220075237
20150227122519
20150304160858
20150309083515
20150312135749
20150316053217
20150316112109
20150320104550
20150330091256
20150330092857
20150330093754
20150331070033
20150401100502
20150411073909
20150411131151
20150413052337
20150413133618
20150414131144
20150420091214
20150421070946
20150424130707
20150504102210
20150515100022
20150525075416
20150601091245
20150605091755
20150609064841
20150612101955
20150616094416
20150617134146
20150624135700
20150626102559
20150626112042
20150629080621
20150629081145
20150629132730
20150630172633
20150701155134
20150702075944
20150707122723
20150722074907
20150723092226
20150727102108
20150810150220
20150812083554
20150824095443
20150825062407
20150831112528
20150831115540
20150915130957
20150929133426
20151008095335
20151009053009
20151009120116
20151102110551
20151102145704
20151106120534
20151116092850
20151116122647
20151124065738
20151124103916
20151125102409
20151130062834
20151130090147
20151130133036
20151130152224
20151211104739
20151211105224
20160111154924
20160118111220
20160118111536
20160122091116
20160127072100
20160225145114
20160229085630
20160301132059
20160316112317
20160321143628
20160407070817
20160412122828
20160413113941
20160419142746
20160420140832
20160422064436
20160426093139
20160427055708
20160427063023
20160505092928
20160509052000
20160510130515
20160520095017
20160523133132
20160524064346
20160525075411
20160607131143
20160608091821
20160608092732
20160621122232
20160623072235
20160623140216
20160627115435
20160628044216
20160705102419
20160712093519
20160712102338
20160712113017
20160716123837
20160719140051
20160721054204
20160725130910
20160726101159
20160727135422
20160803074455
20160808091336
20160809070014
20160809142808
20160817072039
20160819112435
20160822090159
20160830071605
20160830073447
20160907144851
20160919063320
20160919092231
20160920090755
20160920095232
20160928054045
20161003062114
20161003062442
20161005045243
20161005110302
20161116130344
20161117123007
20161122063637
20161129120035
20170102071435
20170103094257
20170106060857
20170120090107
20170120100731
20170120103510
20170127071420
20170127072506
20170130101122
20170130135119
20170202094112
20170203154317
20170209090159
20170215135053
20170216093451
20170222101749
20170227122316
20170317151128
20170321095713
20170331081636
20170403113106
20170407143622
20170408101904
20170408120840
20170411055516
20170412035333
20170417105200
20170418071611
20170418133131
20170418133507
20170419133251
20170427094057
20170505063105
20170509113233
20170509114037
20170510092523
20170510120403
20170510122137
20170510134352
20170510144242
20170511052823
20170511065827
20170511071249
20170511090616
20170511093204
20170511095339
20170511100527
20170511102445
20170511114210
20170512083346
20170512083941
20170512103254
20170515073255
20170516043758
20170516104926
20170516122639
20170516125230
20170516135200
20170516145206
20170516151523
20170517093724
20170517101528
20170518092740
20170524110441
20170526135625
20170530100806
20170530132004
20170530132353
20170531034014
20170531093905
20170531142812
20170601052632
20170601082908
20170602042059
20170605142740
20170607101858
20170608132337
20170609103658
20170609131338
20170614070117
20170614102916
20170615095751
20170615114815
20170615122300
20170616163939
20170619090506
20170619102448
20170620082854
20170621085516
20170621152010
20170628123413
20170628134737
20170629112807
20170703102601
20170704055356
20170704085920
20170704104833
20170706121122
20170706123820
20170706123827
20170707075120
20170710132424
20170712111606
20170718130311
20170719090040
20170720081156
20170720110207
20170720110343
20170725090839
20170808113837
20170808124015
20170811111709
20170829094648
20170904094228
20170907142202
20170907144744
20170909060734
20170911074421
20170911105549
20170915085606
20170918103634
20170918145027
20170919063653
20170920060201
20170921143459
20170921143712
20170921145241
20170927130521
20171010074708
20171010093408
20171010093410
20171010093411
20171012062745
20171012062841
20171012081649
20171012135901
20171012140134
20171016071300
20171030113034
20171108062115
20171114062118
20171117120941
20171124110655
20171204152656
20171206100549
20171206140953
20171213073606
20171217181606
20170727130916
20170801150107
20170810090319
20180118134749
20180322072230
20180425152903
20180716074827
20180718072055
20180823092710
20180912052912
20180918102844
20181015072159
20181023060552
20181031080830
20181128094448
20181130100951
20181130101734
20181203120013
20181205133934
20181205134216
20181218092302
20181222100103
20181226095428
20190311112214
20190322112144
20190404045851
20190502115719
20190504154723
20190504170342
20190506121815
20190508055718
20190530100936
20190625202032
20190813045150
20190813113545
20190826083942
20190826090350
20190912103747
20190925090352
20191014090954
20191015060549
20191105091928
20191106114905
20191112134357
20191129072355
20191204065134
20191213084908
20191213090126
20191220072909
20191225060018
20191225063802
20191225085000
20191226084132
20191226120527
20191231081754
20200106082221
20200107092745
20200109091204
20200110130635
20200114092329
20200114112808
20200120121727
20200121063539
20200123103254
20200128062107
20200203212102
20200205083148
20200212140617
20200217095711
20200219094335
20200221052719
20200226100722
20200228064555
20200304105153
20200304121019
20200323082158
20200330064906
20200406183229
20200406195911
20200407015050
20200407020521
20200407175004
20200410001413
20200410010432
20200410190429
20200411202337
20200411205852
20200420143232
20200522133309
20200529060857
20200602110024
20200617100415
20200618142014
20200619055834
20200619071115
20200623124044
20200625065646
20200626113622
20200704071128
20200715091511
20200715183717
20200721130741
20200721151314
20200730102053
20200805165622
20200812093311
20200812165201
20200914101350
20201014080742
20201020071200
20201102135127
20201106114132
20201111101353
20201111101457
20201123055916
20201123094955
20201124085229
20201125080035
20201130113335
20201201101452
20201203114608
20201204074100
20201207091823
20201208055113
20201216164842
20201217144431
20201218075319
20201231072213
20210106094019
20210107095257
20210108052711
20210114071144
20210114102342
20210129164155
20210204095457
20210213162700
20210215144231
20210305062606
20210309092822
20210310055156
20210312082417
20210315133012
20210323062738
20210323063206
20210324071131
20210326034001
20210406072544
20210409081713
20210416104040
20210503052542
20210511093509
20210517075711
20210526094645
20210531102158
20210603085330
20210615110840
20210616051504
20210616052311
20210618110331
20210622130622
20210625060055
20210713121902
20210727102431
20210728110120
20210729113540
20210806130628
20210809060005
20210811105352
20210813054251
20210816121709
20210819193618
20210827185840
20210913073433
20210917095824
20210918081727
20210924070721
20210930150527
20211027091402
20211109101539
20211116081957
20211123111144
20220101052210
20220102102130
20220104105545
20220106113840
20220216124743
20220218064029
20220302194416
20220302194645
20220309105553
20220310141505
20220330112529
20220412145617
20220419084843
20220419085034
20210220233831
20210302054644
20210312075732
20210421074829
20210422105532
20210519045918
20210525105536
20210607094945
20210621130441
20210624084807
20210625061623
20210706104430
20210803065700
20211025033302
20211115050902
20211115211839
20211213073149
20211214035307
20211231164209
20220113190953
20220426111310
20220427050942
20220427051118
20220428082742
20220428104550
20220428120334
20220518071626
20220602110527
20220603050041
20220603052631
20220603072020
20220620080149
20220621140610
20220629101534
20220629101604
20220711124034
20220714090805
20220727110132
20220728120648
20220729051045
20220802144355
20220809102814
\.


--
-- Data for Name: security_groups; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.security_groups (id, name, group_id, owner_id, type, description, ip_permissions, provider_data, vpc_id, account_id, adapter_id, region_id, created_at, updated_at, ip_permissions_egress, state, data) FROM stdin;
\.


--
-- Data for Name: service_adviser_configs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.service_adviser_configs (id, account_id, adapter_id, provider_type, config_type, name, category, service_type, tags, config_details, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: service_adviser_summaries; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.service_adviser_summaries (id, account_id, tenant_id, tenant_name, summary_data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: service_advisor_logs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.service_advisor_logs (id, user_id, account_id, service_id, data, origin_environment_id, destination_environment_id, event_type, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: service_details; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.service_details (id, ignored_from, ignored_from_category, comment, commented_by, commented_date, adapter_id, region_id, provider_id, created_at, updated_at, comment_type, user_email, provider_type, schedule, ignore_for_days) FROM stdin;
\.


--
-- Data for Name: service_encryption_keys; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.service_encryption_keys (id, service_id, encryption_key_id) FROM stdin;
\.


--
-- Data for Name: service_events; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.service_events (id, service_id, event, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: service_groups; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.service_groups (id, account_id, tenant_id, type, name, description, provider_type, adapter_ids, tags, created_at, updated_at, billing_adapter_id, is_group_empty, normal_adapter_ids, custom_data, sub_account_ids, customer_id, customer_name, customer_subscriptions) FROM stdin;
\.


--
-- Data for Name: service_naming_defaults; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.service_naming_defaults (id, prefix_service_name, suffix_service_count, last_used_number, created_by, updated_by, account_id, created_at, updated_at, service_type, generic_service_type, sub_service_type, free_text, last_used_names) FROM stdin;
\.


--
-- Data for Name: service_synchronization_histories; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.service_synchronization_histories (id, name, state, provider_type, generic_type, provider_id, provider_vpc_id, data, provider_data, updates, adapter_id, region_id, account_id, synchronization_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.services (id, name, state, data, type, provider_type, adapter_id, geometry, account_id, provider_data, generic, created_at, updated_at, generic_type, parent_id, desired_state, friendly_id, region_id, vpc_id, provider_id, error_message, service_vpc_id, additional_properties, synchronized, hourly_cost, total_cost, last_cost_update_time, cost_by_hour, provider_created_at, created_by, updated_by, deleted_at, idle_instance, ignored_from) FROM stdin;
46b09858-47b4-4547-ba21-21454f4b11a4    internet    directory   \N  Services::Internet  \N  \N  \N  \N  \N  t   2022-09-27 11:04:47.284606+00   2022-09-27 11:04:47.290039+00   Services::Internet  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
df2d3f51-0ce5-4f4a-8978-f4a130056d9f    internet    directory   \N  Services::Generic::Internet \N  \N  \N  \N  \N  f   2022-09-27 11:04:47.301552+00   2022-09-27 11:04:47.30634+00    Services::Internet::AWS \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
85cc1f0b-8974-42f7-8995-789bc7ad5c4f    vpc directory   \N  Services::Vpc   \N  \N  \N  \N  \N  f   2022-09-27 11:04:47.318429+00   2022-09-27 11:04:47.323823+00   Services::Vpc   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
fffcec25-809e-4495-81f6-15d8fb4f8d54    vpc directory   \N  Services::Generic::Vpc  \N  \N  \N  \N  \N  f   2022-09-27 11:04:47.337708+00   2022-09-27 11:04:47.343112+00   Services::Vpc::AWS  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
2b2d60ee-776b-4613-b1f1-dfc856c78acf    availability_zone   directory   \N  Services::Network::AvailabilityZone \N  \N  \N  \N  \N  t   2022-09-27 11:04:47.355177+00   2022-09-27 11:04:47.359741+00   Services::Network::AvailabilityZone \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
a1790fc0-61fc-4c48-9ec6-5d840dcae25e    availability_zone   directory   \N  Services::Network::Generic::AvailabilityZone    \N  \N  \N  \N  \N  f   2022-09-27 11:04:47.371337+00   2022-09-27 11:04:47.377223+00   Services::Network::AvailabilityZone::AWS    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
c84d9bc7-a045-461e-8daa-6a2538f7c49d    loadbalancer    directory   \N  Services::Network::LoadBalancer \N  \N  \N  \N  \N  t   2022-09-27 11:04:47.389093+00   2022-09-27 11:04:47.394354+00   Services::Network::LoadBalancer \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
2ab653b2-f343-4660-a029-fd5cd497033b    loadbalancer    directory   \N  Services::Network::LoadBalancer::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:47.409666+00   2022-09-27 11:04:47.414647+00   Services::Network::LoadBalancer \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
e449fc95-1522-4593-a508-0fb2e712086c    loadbalancer    directory   \N  Services::Network::Generic::LoadBalancer::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:47.437514+00   2022-09-27 11:04:47.445389+00   Services::Network::LoadBalancer::AWS    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
78e7983a-88a0-4efd-8920-cd9bb0b7023c    loadbalancer    directory   \N  Services::Network::LoadBalancer::Rackspace  Providers::Rackspace    \N  \N  \N  \N  f   2022-09-27 11:04:47.462776+00   2022-09-27 11:04:47.468674+00   Services::Network::LoadBalancer \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
30c7af8d-f53c-45bc-9c64-a59c522f6c5d    \N  directory   \N  Services::Network::Generic::LoadBalancer::Rackspace::AWS    Providers::Rackspace    \N  \N  \N  \N  f   2022-09-27 11:04:47.529784+00   2022-09-27 11:04:47.534114+00   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
bfb7900d-d04b-49e5-979d-1e33bb0972d8    \N  directory   \N  Services::Network::ApplicationLoadBalancer::AWS Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:47.546187+00   2022-09-27 11:04:47.550617+00   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
64acae3a-4334-4636-b83f-efaeda92ab8d    \N  directory   \N  Services::Network::NetworkLoadBalancer::AWS Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:47.562299+00   2022-09-27 11:04:47.566766+00   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
672185ea-b97a-4ed1-b23e-0ae91fcea84c    subnet  directory   \N  Services::Network::Subnet   \N  \N  \N  \N  \N  t   2022-09-27 11:04:47.578359+00   2022-09-27 11:04:47.585824+00   Services::Network::Subnet   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
f4b6ea10-4c0a-45f7-9b9d-ff14a5fe6656    subnet  directory   \N  Services::Network::Subnet::AWS  Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:47.600151+00   2022-09-27 11:04:47.605456+00   Services::Network::Subnet   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
3ffbe046-2207-413c-a198-1f547a14c571    subnet  directory   \N  Services::Network::Generic::Subnet::AWS Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:47.6197+00 2022-09-27 11:04:47.625215+00   Services::Network::Subnet::AWS  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
e8ce58c8-ea27-4f33-921c-3507414679fe    subnet  directory   \N  Services::Network::Subnet::Rackspace    Providers::Rackspace    \N  \N  \N  \N  f   2022-09-27 11:04:47.645887+00   2022-09-27 11:04:47.653495+00   Services::Network::Subnet   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
139c52a0-fed2-4c4d-b1a6-6bc1b0797809    \N  directory   \N  Services::Network::Generic::Subnet::Rackspace   Providers::Rackspace    \N  \N  \N  \N  f   2022-09-27 11:04:47.676357+00   2022-09-27 11:04:47.683201+00   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
5cec490c-70e2-4c1c-a30e-3066923e8f45    subnet  directory   \N  Services::Network::Subnet::Azure    Providers::Azure    \N  \N  \N  \N  f   2022-09-27 11:04:47.699085+00   2022-09-27 11:04:47.7054+00 Services::Network::Subnet   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
be967efb-5399-4317-869f-a70dff80165d    server  directory   \N  Services::Compute::Server   \N  \N  \N  \N  \N  t   2022-09-27 11:04:47.719414+00   2022-09-27 11:04:47.725984+00   Services::Compute::Server   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
65b5577b-5e3d-48cf-8eda-a219812a91d4    server  directory   \N  Services::Compute::Server::AWS  Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:47.740813+00   2022-09-27 11:04:47.747105+00   Services::Compute::Server   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
1355f95f-898b-4aac-9a12-08dd902621ea    server  directory   \N  Services::Compute::Generic::Server::AWS Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:47.760969+00   2022-09-27 11:04:47.765917+00   Services::Compute::Server::AWS  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
a99a5fa1-6fdf-4eaf-ac6f-f6731c028ff9    server  directory   \N  Services::Compute::Server::Azure    Providers::Azure    \N  \N  \N  \N  f   2022-09-27 11:04:47.780397+00   2022-09-27 11:04:47.785899+00   Services::Compute::Server   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
918ed176-fc1d-40ce-9abe-2cc937d111c6    server  directory   \N  Services::Compute::Server::Rackspace    Providers::Rackspace    \N  \N  \N  \N  f   2022-09-27 11:04:47.800141+00   2022-09-27 11:04:47.805637+00   Services::Compute::Server   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
765f54a3-2829-479a-bd35-d176ed490177    \N  directory   \N  Services::Compute::Generic::Server::Rackspace   Providers::Rackspace    \N  \N  \N  \N  f   2022-09-27 11:04:47.820041+00   2022-09-27 11:04:47.825841+00   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
5c082e4c-bba3-4e0c-99ef-3516ebb32d9d    eni directory   \N  Services::Network::NetworkInterface \N  \N  \N  \N  \N  t   2022-09-27 11:04:47.838823+00   2022-09-27 11:04:47.844105+00   Services::Network::NetworkInterface \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
e69bcc09-f417-480f-add5-3401de44a581    eni directory   \N  Services::Network::NetworkInterface::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:47.875663+00   2022-09-27 11:04:47.88236+00    Services::Network::NetworkInterface \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
ec6c7488-6c9d-4f50-8eb4-a9dbf1f62de2    eni directory   \N  Services::Network::Generic::NetworkInterface::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:47.899138+00   2022-09-27 11:04:47.905119+00   Services::Network::NetworkInterface::AWS    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
b22ba06c-4e55-49c6-afe1-eaad6662569e    ISCSI Volume    directory   \N  Services::Compute::Server::IscsiVolume  \N  \N  \N  \N  \N  t   2022-09-27 11:04:47.918375+00   2022-09-27 11:04:47.923635+00   Services::Compute::Server::IscsiVolume  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
04e1c307-0e9b-4b2e-b62c-3a2e477888e6    ISCSI Volume    directory   \N  Services::Compute::Server::IscsiVolume::AWS Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:47.938357+00   2022-09-27 11:04:47.944239+00   Services::Compute::Server::IscsiVolume  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
84302043-75dc-41f3-836f-cd346aaadd07    ISCSI Volume    directory   \N  Services::Compute::Generic::Server::IscsiVolume::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:47.960092+00   2022-09-27 11:04:47.966355+00   Services::Compute::Server::IscsiVolume::AWS \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
75f4c133-0719-42bb-8ddb-e404b9901980    volume  directory   \N  Services::Compute::Server::Volume   \N  \N  \N  \N  \N  t   2022-09-27 11:04:47.98124+00    2022-09-27 11:04:47.987216+00   Services::Compute::Server::Volume   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
6f8f6ea3-92de-4434-90ef-649280a5c5c1    volume  directory   \N  Services::Compute::Server::Volume::AWS  Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.008114+00   2022-09-27 11:04:48.013499+00   Services::Compute::Server::Volume   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
7a121e9d-cc9a-4e24-8b05-cad2030cc1f3    volume  directory   \N  Services::Compute::Generic::Server::Volume::AWS Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.028081+00   2022-09-27 11:04:48.033559+00   Services::Compute::Server::Volume::AWS  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
47a01f58-5880-4b5e-bd96-d28f0d6e4987    new relic   directory   \N  Services::NewRelic  \N  \N  \N  \N  \N  f   2022-09-27 11:04:48.046088+00   2022-09-27 11:04:48.052046+00   Services::NewRelic  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
0e10a437-fe23-42dd-9eac-61e3d4b02bba    new relic   directory   \N  Services::Generic::NewRelic \N  \N  \N  \N  \N  f   2022-09-27 11:04:48.066933+00   2022-09-27 11:04:48.073006+00   Services::NewRelic::AWS \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
e5732335-a060-45fe-9c90-f18e0c0d3350    internet_gateway    directory   \N  Services::Network::InternetGateway  \N  \N  \N  \N  \N  t   2022-09-27 11:04:48.08617+00    2022-09-27 11:04:48.092564+00   Services::Network::InternetGateway  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
54fdcfc8-2eed-427b-9387-6993ff28afb9    internet_gateway    directory   \N  Services::Network::InternetGateway::AWS Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.108487+00   2022-09-27 11:04:48.11444+00    Services::Network::InternetGateway  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
925429c8-41f7-4825-8d57-1af140d767e7    internet_gateway    directory   \N  Services::Network::Generic::InternetGateway::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.130705+00   2022-09-27 11:04:48.136487+00   Services::Network::InternetGateway::AWS \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
be855574-afc6-4fb5-85cd-d50d33a24440    route_table directory   \N  Services::Network::RouteTable   \N  \N  \N  \N  \N  t   2022-09-27 11:04:48.149854+00   2022-09-27 11:04:48.156337+00   Services::Network::RouteTable   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
d3c3d87f-6ee5-46a1-93fa-9462cfd8c766    route_table directory   \N  Services::Network::RouteTable::AWS  Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.171719+00   2022-09-27 11:04:48.177388+00   Services::Network::RouteTable   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
5992e0ef-7736-4d84-9c4a-2d756d69b38e    route_table directory   \N  Services::Network::Generic::RouteTable::AWS Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.193149+00   2022-09-27 11:04:48.199239+00   Services::Network::RouteTable::AWS  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
21916c35-89ea-4690-ab94-b1314923aab7    security_group  directory   \N  Services::Network::SecurityGroup::AWS   \N  \N  \N  \N  \N  t   2022-09-27 11:04:48.213212+00   2022-09-27 11:04:48.219724+00   Services::Network::SecurityGroup    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
59ffd307-3292-4208-977a-078c922acaff    security_group  directory   \N  Services::Network::SecurityGroup::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.235408+00   2022-09-27 11:04:48.242615+00   Services::Network::SecurityGroup    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
f811ce08-bf1b-4b56-bc66-33247a85d269    security_group  directory   \N  Services::Network::Generic::SecurityGroup::AWS  Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.258098+00   2022-09-27 11:04:48.264558+00   Services::Network::SecurityGroup::AWS   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
f5679b5a-4572-40ac-a069-1baacaecec08    subnet-group    directory   \N  Services::Network::SubnetGroup  \N  \N  \N  \N  \N  t   2022-09-27 11:04:48.287685+00   2022-09-27 11:04:48.294537+00   Services::Network::SubnetGroup  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
5decd414-0d4b-4115-a3b9-ff762eb24b30    subnet-group    directory   \N  Services::Network::SubnetGroup::AWS Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.313127+00   2022-09-27 11:04:48.319617+00   Services::Network::SubnetGroup  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
366ae899-66aa-4c01-baf9-6db0293a5729    subnet-group    directory   \N  Services::Network::Generic::SubnetGroup::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.340026+00   2022-09-27 11:04:48.3493+00 Services::Network::SubnetGroup::AWS \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
34611aa0-0cca-452f-953f-2b30e61d597d    elastic_ip  directory   \N  Services::Network::ElasticIP    \N  \N  \N  \N  \N  t   2022-09-27 11:04:48.369197+00   2022-09-27 11:04:48.376378+00   Services::Network::ElasticIP    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
93ba05c3-a044-4374-965e-a4eac40ba5d8    elastic_ip  directory   \N  Services::Network::ElasticIP::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.483164+00   2022-09-27 11:04:48.489339+00   Services::Network::ElasticIP    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
e70d19b5-ded9-4f79-8516-a50c5228868a    elastic_ip  directory   \N  Services::Network::Generic::ElasticIP::AWS  Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.507562+00   2022-09-27 11:04:48.512331+00   Services::Network::ElasticIP::AWS   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
80cb2897-05e8-481d-9f50-79fe83d5251b    auto_scaling    directory   \N  Services::Network::AutoScaling::AWS \N  \N  \N  \N  \N  t   2022-09-27 11:04:48.524936+00   2022-09-27 11:04:48.529918+00   Services::Network::AutoScaling  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
fd44d59a-c648-40ff-873e-56748176aafe    auto_scaling    directory   \N  Services::Network::AutoScaling::AWS Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.544746+00   2022-09-27 11:04:48.551147+00   Services::Network::AutoScaling  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
b19a6d70-3861-4c59-8b86-0a6b23248f5d    auto_scaling    directory   \N  Services::Network::Generic::AutoScaling::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.566777+00   2022-09-27 11:04:48.572245+00   Services::Network::AutoScaling::AWS \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
3c807891-5f6f-441b-9471-71a3b40a1764    auto_scaling_configuration  directory   \N  Services::Network::AutoScalingConfiguration::AWS    \N  \N  \N  \N  \N  t   2022-09-27 11:04:48.585437+00   2022-09-27 11:04:48.593666+00   Services::Network::AutoScalingConfiguration \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
2c6afbf5-6ed7-42c4-9def-13fa9b2257df    auto_scaling_configuration  directory   \N  Services::Network::AutoScalingConfiguration::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.608396+00   2022-09-27 11:04:48.613619+00   Services::Network::AutoScalingConfiguration \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
b949f9e3-e69d-45e8-aeca-9f8c33b00678    auto_scaling_configuration  directory   \N  Services::Network::Generic::AutoScalingConfiguration::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.626778+00   2022-09-27 11:04:48.631679+00   Services::Network::AutoScalingConfiguration::AWS    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
ad876775-8136-4c1e-9ce9-d5eec295a025    alarm   directory   \N  Services::Network::Alarm    \N  \N  \N  \N  \N  t   2022-09-27 11:04:48.644225+00   2022-09-27 11:04:48.64899+00    Services::Network::Alarm    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
01410247-e8ad-4408-a604-e5845e629f95    alarm   directory   \N  Services::Network::Alarm::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.66261+00    2022-09-27 11:04:48.669362+00   Services::Network::Alarm    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
a107e5c4-e078-4726-81c5-45a10c035861    alarm   directory   \N  Services::Network::Generic::Alarm::AWS  Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.686344+00   2022-09-27 11:04:48.693284+00   Services::Network::Alarm::AWS   \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
293b9fd8-9aa1-4886-a0f5-04b094a09b34    rds directory   \N  Services::Database::Rds \N  \N  \N  \N  \N  t   2022-09-27 11:04:48.712372+00   2022-09-27 11:04:48.718383+00   Services::Database::Rds \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
e85fb1b6-3dd7-499e-905c-1d53e483d83a    PostgreSQL  directory   {"port":5432,"engine":"postgres"}   Services::Database::Rds::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.738212+00   2022-09-27 11:04:48.743082+00   Services::Database::Rds \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
213f4c4e-8a50-43b2-8993-372b8c8e1eb3    MySQL   directory   {"port":3306,"engine":"mysql"}  Services::Database::Rds::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.76976+00    2022-09-27 11:04:48.775329+00   Services::Database::Rds \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
b9361d78-634a-440d-afb1-4c1186320a37    SQL Server Enterprise Edition   directory   {"port":1433,"engine":"sqlserver-ee"}   Services::Database::Rds::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.798236+00   2022-09-27 11:04:48.803968+00   Services::Database::Rds \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
eac8a0b9-6dd3-4f8b-b569-6c25f4ff7667    SQL Server Express Edition  directory   {"port":1433,"engine":"sqlserver-ex"}   Services::Database::Rds::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.822099+00   2022-09-27 11:04:48.828465+00   Services::Database::Rds \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
ec3dab3a-f5d0-4a97-9530-f0e95f77043a    SQL Server Standard Edition directory   {"port":1433,"engine":"sqlserver-se"}   Services::Database::Rds::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.849837+00   2022-09-27 11:04:48.855841+00   Services::Database::Rds \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
2984c381-1989-43e7-8116-c5b9264ea983    SQL Server Web Edition  directory   {"port":1433,"engine":"sqlserver-web"}  Services::Database::Rds::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.880033+00   2022-09-27 11:04:48.886774+00   Services::Database::Rds \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
ac212cf7-9c82-49d2-ae18-46c64603d1d9    Oracle Database Standard Edition One    directory   {"port":1521,"engine":"oracle-se1"} Services::Database::Rds::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.906028+00   2022-09-27 11:04:48.911319+00   Services::Database::Rds \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
cffb586b-01aa-412c-9a36-90473b27126d    Oracle Database Standard Edition    directory   {"port":1521,"engine":"oracle-se"}  Services::Database::Rds::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.929287+00   2022-09-27 11:04:48.935617+00   Services::Database::Rds \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
2c2f98bd-0911-43f2-80aa-03fa9e549426    Oracle Database Enterprise Edition  directory   {"port":1521,"engine":"oracle-ee"}  Services::Database::Rds::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.955391+00   2022-09-27 11:04:48.960808+00   Services::Database::Rds \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
163bbfd2-4342-4723-b375-6d31af5d05b0    Aurora - compatible with MySQL 5.6.10a  directory   {"port":3306,"engine":"aurora"} Services::Database::Rds::AWS    Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.978917+00   2022-09-27 11:04:48.984367+00   Services::Database::Rds \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
aa40731f-48c5-404a-8f28-ad7450781122    PostgreSQL  directory   {"port":5432,"engine":"postgres"}   Services::Database::Generic::Rds::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:48.999778+00   2022-09-27 11:04:49.007093+00   Services::Database::Rds::AWS    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
4a53cd61-1821-428f-bf05-7bef82a847a1    MySQL   directory   {"port":3306,"engine":"mysql"}  Services::Database::Generic::Rds::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:49.023995+00   2022-09-27 11:04:49.029343+00   Services::Database::Rds::AWS    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
be0afc35-ed6f-4fa8-ab66-5065c08653ba    SQL Server Enterprise Edition   directory   {"port":1433,"engine":"sqlserver-ee"}   Services::Database::Generic::Rds::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:49.045088+00   2022-09-27 11:04:49.050572+00   Services::Database::Rds::AWS    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
178a5045-d51d-4586-87c4-1525baf4d638    SQL Server Express Edition  directory   {"port":1433,"engine":"sqlserver-ex"}   Services::Database::Generic::Rds::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:49.066995+00   2022-09-27 11:04:49.072531+00   Services::Database::Rds::AWS    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
0bc15bcf-7ae9-493f-a53a-209f3960d9f3    SQL Server Standard Edition directory   {"port":1433,"engine":"sqlserver-se"}   Services::Database::Generic::Rds::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:49.088435+00   2022-09-27 11:04:49.094084+00   Services::Database::Rds::AWS    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
b8270f69-5b10-40f2-90cb-bea7a40e5482    SQL Server Web Edition  directory   {"port":1433,"engine":"sqlserver-web"}  Services::Database::Generic::Rds::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:49.109617+00   2022-09-27 11:04:49.114497+00   Services::Database::Rds::AWS    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
528316f7-dca4-4614-85a8-3a75704c7d89    Oracle Database Standard Edition One    directory   {"port":1521,"engine":"oracle-se1"} Services::Database::Generic::Rds::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:49.130005+00   2022-09-27 11:04:49.135227+00   Services::Database::Rds::AWS    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
d636aa2f-8dc5-4486-a798-1edc08f8765c    Oracle Database Standard Edition    directory   {"port":1521,"engine":"oracle-se"}  Services::Database::Generic::Rds::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:49.150274+00   2022-09-27 11:04:49.156117+00   Services::Database::Rds::AWS    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
7470d255-59ec-4cb9-b80b-21449650b9aa    Oracle Database Enterprise Edition  directory   {"port":1521,"engine":"oracle-ee"}  Services::Database::Generic::Rds::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:49.171611+00   2022-09-27 11:04:49.177586+00   Services::Database::Rds::AWS    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
7869ddc4-cc08-4644-b9a6-74d9d6869142    Aurora - compatible with MySQL 5.6.10a  directory   {"port":3306,"engine":"aurora"} Services::Database::Generic::Rds::AWS   Providers::AWS  \N  \N  \N  \N  f   2022-09-27 11:04:49.193783+00   2022-09-27 11:04:49.199014+00   Services::Database::Rds::AWS    \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
eb3ae692-4b4e-4839-9308-5fba29ee19fa    rds directory   \N  Services::Database::Rds::Azure  Providers::Azure    \N  \N  \N  \N  f   2022-09-27 11:04:49.213515+00   2022-09-27 11:04:49.219547+00   Services::Database::Rds \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  \N  0.0000000000    \N  \N  \N  \N  f   {un-ignored}
\.


--
-- Data for Name: services_tasks; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.services_tasks (id, service_id, task_id) FROM stdin;
\.


--
-- Data for Name: slack_users; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.slack_users (id, organisation_id, user_id, workspace_id, account_id, access_token, auth_data, data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: snapshots; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.snapshots (id, name, type, category, provider_id, provider_data, description, account_id, service_id, adapter_id, region_id, created_at, updated_at, archived, state, data, error_message, cost_by_hour, environment_id, first_snapshot, last_cost_update_time, provider_created_at, machine_image_id, created_by, image_reference, publicly_accessible, ignored_from) FROM stdin;
\.


--
-- Data for Name: snapshots_tasks; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.snapshots_tasks (id, snapshot_id, task_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: soe_scripts; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.soe_scripts (id, name, last_updated, script_type, script_text, soe_scripts_group_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: soe_scripts_groups; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.soe_scripts_groups (id, name, supported_os, soe_config_count, sourceable_type, created_at, updated_at, sourceable_id) FROM stdin;
\.


--
-- Data for Name: soe_scripts_remote_sources; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.soe_scripts_remote_sources (id, url, last_updated, version, state, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_configs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.sso_configs (id, idp_sso_target_url, idp_slo_target_url, idp_entity_id, certificate, account_id, disable, created_at, updated_at, email_attribute_key, name_attribute_key, roles_attribute_key, sso_keyword_attribute_key, idp_metadata, private_key) FROM stdin;
\.


--
-- Data for Name: storage_vms; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.storage_vms (id, filer_id, name, state, language, allowed_aggregates, created_at, updated_at, cifs_nfs_mount_ip) FROM stdin;
\.


--
-- Data for Name: storages; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.storages (id, key, adapter_id, region_id, account_id, creation_date, created_at, updated_at, owner_id, owner_display_name, access_control_list, data, ignored_from) FROM stdin;
\.


--
-- Data for Name: subnet_groups; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.subnet_groups (id, name, provider_id, description, state, account_id, region_id, adapter_id, vpc_id, subnet_ids, data, provider_data, type, subnet_service_ids, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: subnets; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.subnets (id, provider_id, provider_vpc_id, name, vpc_id, cidr_block, available_ip, availability_zone, tags, type, provider_data, adapter_id, account_id, region_id, state, data) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.subscriptions (id, provider_subscription_id, name, state, data, provider_data, enabled, adapter_id, created_at, updated_at, type) FROM stdin;
\.


--
-- Data for Name: synchronization_settings; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.synchronization_settings (id, account_id, repeat, sync_time, auto_sync_to_aws, auto_sync_to_kum_from_aws, created_at, updated_at, status, adapters) FROM stdin;
\.


--
-- Data for Name: synchronizations; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.synchronizations (id, started_at, completed_at, state_info, account_id, created_at, updated_at, friendly_id, adapter_ids, region_ids, executor_id, has_synced_vpcs, sync_info, adapter_wise_sync_status, service_sync_status) FROM stdin;
\.


--
-- Data for Name: tag_key_values; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.tag_key_values (id, tag_value, tag_key_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tag_keys; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.tag_keys (id, key, description, created_at, updated_at, account_id, adapter_id, region_id, subscription_id) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.tags (id, tag_key, tag_type, tag_value, is_mandatory, data, account_id, created_by, updated_by, created_at, updated_at, state, applied_type, applicable_services, overridable_services, description) FROM stdin;
\.


--
-- Data for Name: task_details; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.task_details (id, adapter_id, task_id, type, data, resource_identifier, created_at, updated_at, is_opt_out) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.tasks (id, title, description, created_by, account_id, repeat, start_datetime, end_schedule, occurences_completed, data, schedule, task_type, notify, notification_schedule, created_at, updated_at, parent_id, service_type, schedule_type, last_execuation_time, next_execuation_time, status, interval_time, time_zone, region_ids, backup_policy_id, machine_image_ids, enable, progress, skip_occurrence, type, data_prepared, tenant_id) FROM stdin;
\.


--
-- Data for Name: teams_users; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.teams_users (id, account_id, organisation_id, workspace_id, user_id, access_token, user_details, bot_data, conversation_data, user_data, service_url, aad_object_id, created_at, updated_at, refresh_token) FROM stdin;
\.


--
-- Data for Name: template_costs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.template_costs (id, region_id, data, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: template_kumo_services; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.template_kumo_services (id, template_id, kumo_service_id, geometry) FROM stdin;
\.


--
-- Data for Name: template_services; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.template_services (id, template_id, service_id) FROM stdin;
\.


--
-- Data for Name: template_vpcs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.template_vpcs (id, template_id, vpc_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.templates (id, name, version, state, account_id, created_at, updated_at, friendly_id, template_model, region_id, adapter_id, created_by, updated_by, revision, shared_with, description, template_tags, selected_type, subscription_id, generic_type, with_nc) FROM stdin;
\.


--
-- Data for Name: tenant_adapters; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.tenant_adapters (id, tenant_id, adapter_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_billing_adapters; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.tenant_billing_adapters (id, tenant_id, organisation_id, billing_adapter_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_service_groups; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.tenant_service_groups (id, tenant_id, service_group_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_users; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.tenant_users (id, user_id, tenant_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.tenants (id, name, state, organisation_id, created_at, updated_at, is_default, tags, sso_keywords, exclude_edp, report_profile_id, all_selected_flags, enable_currency_conversion, default_currency) FROM stdin;
\.


--
-- Data for Name: tenants_resource_groups; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.tenants_resource_groups (id, tenant_id, adapter_id, azure_resource_group_id) FROM stdin;
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.user_preferences (id, user_id, preferences, created_at, updated_at, prefereable_id, prefereable_type) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.user_roles (id, name, created_at, updated_at, sso_keywords, provision_right, organisation_id) FROM stdin;
\.


--
-- Data for Name: user_roles_users; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.user_roles_users (id, user_id, user_role_id, tenant_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.users (id, email, encrypted_password, reset_password_token, sign_in_count, current_sign_in_ip, last_sign_in_ip, authentication_token, name, confirmation_token, unconfirmed_email, invite_token, username, created_at, updated_at, reset_password_sent_at, remember_created_at, current_sign_in_at, last_sign_in_at, confirmed_at, confirmation_sent_at, invited_at, signed_up, state, account_id, show_intro, user_type, time_zone, is_admin, current_tenant, override_tenant_currency, default_currency, reset_to_default_currency, activated_by_user, enable_welcome_popup) FROM stdin;
\.


--
-- Data for Name: users_roles; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.users_roles (user_id, role_id) FROM stdin;
\.


--
-- Data for Name: vm_ware_service_forecast_costs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.vm_ware_service_forecast_costs (id, adapter_id, account_id, month, tab, cost, created_at, updated_at, vcenter_id, net_cost, margin_cost, discount_cost) FROM stdin;
\.


--
-- Data for Name: vm_ware_tenant_adapters; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.vm_ware_tenant_adapters (id, organisation_id, tenant_id, adapter_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vpcs; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.vpcs (id, name, cidr, vpc_id, enable_dns_resolution, internet_attached, tenancy, provider_data, enabled, template_id, region_id, account_id, created_at, updated_at, type, adapter_id, data, state, synchronized, user_role_ids) FROM stdin;
\.


--
-- Data for Name: vw_events; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.vw_events (id, count, size, cores_per_socket, forceful_apply, name, vw_inventory_id, created_at, updated_at, status, error, data) FROM stdin;
\.


--
-- Data for Name: vw_inventories; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.vw_inventories (id, data, parent_id, created_at, updated_at, vw_vcenter_id, resource_type, provider_id, tag, idle_instance, cost_by_hour) FROM stdin;
\.


--
-- Data for Name: vw_metrics; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.vw_metrics (id, data, vw_inventory_id, created_at, updated_at, noted_at) FROM stdin;
\.


--
-- Data for Name: vw_vcenters; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.vw_vcenters (id, adapter_id, data, created_at, updated_at, provider_id) FROM stdin;
\.


--
-- Data for Name: vw_vdc_files; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.vw_vdc_files (id, adapter_id, zip, created_at, updated_at, vw_vcenter_id) FROM stdin;
\.


--
-- Data for Name: workspaces; Type: TABLE DATA; Schema: public; Owner: csmpdbuser
--

COPY public.workspaces (id, name, type, user_id, account_id, organisation_id, data, state, created_at, updated_at) FROM stdin;
\.


--
-- Name: admin_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: csmpdbuser
--

SELECT pg_catalog.setval('public.admin_users_id_seq', 1, false);


--
-- Name: environment_storages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: csmpdbuser
--

SELECT pg_catalog.setval('public.environment_storages_id_seq', 1, false);


--
-- Name: environments_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: csmpdbuser
--

SELECT pg_catalog.setval('public.environments_tasks_id_seq', 1, false);


--
-- Name: invoices_invoice_number_seq; Type: SEQUENCE SET; Schema: public; Owner: csmpdbuser
--

SELECT pg_catalog.setval('public.invoices_invoice_number_seq', 1, false);


--
-- Name: network_interfaces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: csmpdbuser
--

SELECT pg_catalog.setval('public.network_interfaces_id_seq', 1, false);


--
-- Name: organisation_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: csmpdbuser
--

SELECT pg_catalog.setval('public.organisation_details_id_seq', 1, false);


--
-- Name: organisation_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: csmpdbuser
--

SELECT pg_catalog.setval('public.organisation_images_id_seq', 1, false);


--
-- Name: organisations_users_uuid_seq; Type: SEQUENCE SET; Schema: public; Owner: csmpdbuser
--

SELECT pg_catalog.setval('public.organisations_users_uuid_seq', 1, false);


--
-- Name: service_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: csmpdbuser
--

SELECT pg_catalog.setval('public.service_events_id_seq', 1, false);


--
-- Name: sso_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: csmpdbuser
--

SELECT pg_catalog.setval('public.sso_configs_id_seq', 1, false);


--
-- Name: user_roles_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: csmpdbuser
--

SELECT pg_catalog.setval('public.user_roles_users_id_seq', 1, false);


--
-- Name: access_rights access_rights_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.access_rights
    ADD CONSTRAINT access_rights_pkey PRIMARY KEY (id);


--
-- Name: access_rights_user_roles access_rights_user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.access_rights_user_roles
    ADD CONSTRAINT access_rights_user_roles_pkey PRIMARY KEY (id);


--
-- Name: account_gcp_multi_regions account_gcp_multi_regions_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.account_gcp_multi_regions
    ADD CONSTRAINT account_gcp_multi_regions_pkey PRIMARY KEY (id);


--
-- Name: account_regions account_regions_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.account_regions
    ADD CONSTRAINT account_regions_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: accounts_soe_scripts_remote_sources accounts_soe_scripts_remote_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.accounts_soe_scripts_remote_sources
    ADD CONSTRAINT accounts_soe_scripts_remote_sources_pkey PRIMARY KEY (id);


--
-- Name: adapters adapters_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.adapters
    ADD CONSTRAINT adapters_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: aggregates aggregates_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.aggregates
    ADD CONSTRAINT aggregates_pkey PRIMARY KEY (id);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: ami_config_categories ami_config_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.ami_config_categories
    ADD CONSTRAINT ami_config_categories_pkey PRIMARY KEY (id);


--
-- Name: app_access_secrets app_access_secrets_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.app_access_secrets
    ADD CONSTRAINT app_access_secrets_pkey PRIMARY KEY (id);


--
-- Name: application_plans application_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.application_plans
    ADD CONSTRAINT application_plans_pkey PRIMARY KEY (id);


--
-- Name: applications applications_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: associated_services associated_services_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.associated_services
    ADD CONSTRAINT associated_services_pkey PRIMARY KEY (id);


--
-- Name: availability_zones availability_zones_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.availability_zones
    ADD CONSTRAINT availability_zones_pkey PRIMARY KEY (id);


--
-- Name: aws_accounts aws_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.aws_accounts
    ADD CONSTRAINT aws_accounts_pkey PRIMARY KEY (id);


--
-- Name: aws_cloud_trails aws_cloud_trails_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.aws_cloud_trails
    ADD CONSTRAINT aws_cloud_trails_pkey PRIMARY KEY (id);


--
-- Name: aws_cloud_watch_logs aws_cloud_watch_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.aws_cloud_watch_logs
    ADD CONSTRAINT aws_cloud_watch_logs_pkey PRIMARY KEY (id);


--
-- Name: aws_configs aws_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.aws_configs
    ADD CONSTRAINT aws_configs_pkey PRIMARY KEY (id);


--
-- Name: aws_iam_roles aws_iam_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.aws_iam_roles
    ADD CONSTRAINT aws_iam_roles_pkey PRIMARY KEY (id);


--
-- Name: aws_marketplace_saas_subscriptions aws_marketplace_saas_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.aws_marketplace_saas_subscriptions
    ADD CONSTRAINT aws_marketplace_saas_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: aws_organisations aws_organisations_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.aws_organisations
    ADD CONSTRAINT aws_organisations_pkey PRIMARY KEY (id);


--
-- Name: aws_records aws_records_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.aws_records
    ADD CONSTRAINT aws_records_pkey PRIMARY KEY (id);


--
-- Name: aws_right_sizings aws_right_sizings_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.aws_right_sizings
    ADD CONSTRAINT aws_right_sizings_pkey PRIMARY KEY (id);


--
-- Name: aws_service_forecast_costs aws_service_forecast_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.aws_service_forecast_costs
    ADD CONSTRAINT aws_service_forecast_costs_pkey PRIMARY KEY (id);


--
-- Name: aws_trails aws_trails_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.aws_trails
    ADD CONSTRAINT aws_trails_pkey PRIMARY KEY (id);


--
-- Name: azure_availability_sets azure_availability_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_availability_sets
    ADD CONSTRAINT azure_availability_sets_pkey PRIMARY KEY (id);


--
-- Name: azure_compliance_checks azure_compliance_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_compliance_checks
    ADD CONSTRAINT azure_compliance_checks_pkey PRIMARY KEY (id);


--
-- Name: azure_compliance_policies azure_compliance_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_compliance_policies
    ADD CONSTRAINT azure_compliance_policies_pkey PRIMARY KEY (id);


--
-- Name: azure_compliance_standards azure_compliance_standards_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_compliance_standards
    ADD CONSTRAINT azure_compliance_standards_pkey PRIMARY KEY (id);


--
-- Name: azure_cost_summaries azure_cost_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_cost_summaries
    ADD CONSTRAINT azure_cost_summaries_pkey PRIMARY KEY (id);


--
-- Name: azure_disks azure_disks_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_disks
    ADD CONSTRAINT azure_disks_pkey PRIMARY KEY (id);


--
-- Name: azure_export_configurations azure_export_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_export_configurations
    ADD CONSTRAINT azure_export_configurations_pkey PRIMARY KEY (id);


--
-- Name: azure_load_balancers azure_load_balancers_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_load_balancers
    ADD CONSTRAINT azure_load_balancers_pkey PRIMARY KEY (id);


--
-- Name: azure_network_interfaces azure_network_interfaces_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_network_interfaces
    ADD CONSTRAINT azure_network_interfaces_pkey PRIMARY KEY (id);


--
-- Name: azure_public_ip_addresses azure_public_ip_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_public_ip_addresses
    ADD CONSTRAINT azure_public_ip_addresses_pkey PRIMARY KEY (id);


--
-- Name: azure_rate_cards azure_rate_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_rate_cards
    ADD CONSTRAINT azure_rate_cards_pkey PRIMARY KEY (id);


--
-- Name: azure_resource_groups azure_resource_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_resource_groups
    ADD CONSTRAINT azure_resource_groups_pkey PRIMARY KEY (id);


--
-- Name: azure_resources azure_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_resources
    ADD CONSTRAINT azure_resources_pkey PRIMARY KEY (id);


--
-- Name: azure_rg_service_forecast_costs azure_rg_service_forecast_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_rg_service_forecast_costs
    ADD CONSTRAINT azure_rg_service_forecast_costs_pkey PRIMARY KEY (id);


--
-- Name: azure_route_tables azure_route_tables_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_route_tables
    ADD CONSTRAINT azure_route_tables_pkey PRIMARY KEY (id);


--
-- Name: azure_security_groups azure_security_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_security_groups
    ADD CONSTRAINT azure_security_groups_pkey PRIMARY KEY (id);


--
-- Name: azure_service_forecast_costs azure_service_forecast_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_service_forecast_costs
    ADD CONSTRAINT azure_service_forecast_costs_pkey PRIMARY KEY (id);


--
-- Name: azure_sql_db_servers azure_sql_db_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_sql_db_servers
    ADD CONSTRAINT azure_sql_db_servers_pkey PRIMARY KEY (id);


--
-- Name: azure_sql_dbs azure_sql_dbs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_sql_dbs
    ADD CONSTRAINT azure_sql_dbs_pkey PRIMARY KEY (id);


--
-- Name: azure_storage_accounts azure_storage_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_storage_accounts
    ADD CONSTRAINT azure_storage_accounts_pkey PRIMARY KEY (id);


--
-- Name: azure_subnets azure_subnets_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_subnets
    ADD CONSTRAINT azure_subnets_pkey PRIMARY KEY (id);


--
-- Name: azure_subscriptions azure_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_subscriptions
    ADD CONSTRAINT azure_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: azure_tenant_billing_adapters azure_tenant_billing_adapters_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_tenant_billing_adapters
    ADD CONSTRAINT azure_tenant_billing_adapters_pkey PRIMARY KEY (id);


--
-- Name: azure_usage_costs azure_usage_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_usage_costs
    ADD CONSTRAINT azure_usage_costs_pkey PRIMARY KEY (id);


--
-- Name: azure_virtual_machines azure_virtual_machines_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_virtual_machines
    ADD CONSTRAINT azure_virtual_machines_pkey PRIMARY KEY (id);


--
-- Name: azure_price_lists azure_vm_price_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_price_lists
    ADD CONSTRAINT azure_vm_price_lists_pkey PRIMARY KEY (id);


--
-- Name: azure_vnets azure_vnets_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_vnets
    ADD CONSTRAINT azure_vnets_pkey PRIMARY KEY (id);


--
-- Name: backup_policies backup_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.backup_policies
    ADD CONSTRAINT backup_policies_pkey PRIMARY KEY (id);


--
-- Name: billing_currencies billing_currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.billing_currencies
    ADD CONSTRAINT billing_currencies_pkey PRIMARY KEY (id);


--
-- Name: cloud_resource_adapters cloud_resource_adapters_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.cloud_resource_adapters
    ADD CONSTRAINT cloud_resource_adapters_pkey PRIMARY KEY (id);


--
-- Name: clusters_environments clusters_environments_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.clusters_environments
    ADD CONSTRAINT clusters_environments_pkey PRIMARY KEY (id);


--
-- Name: clusters clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.clusters
    ADD CONSTRAINT clusters_pkey PRIMARY KEY (id);


--
-- Name: compliance_checks compliance_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.compliance_checks
    ADD CONSTRAINT compliance_checks_pkey PRIMARY KEY (id);


--
-- Name: compliance_standards compliance_standards_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.compliance_standards
    ADD CONSTRAINT compliance_standards_pkey PRIMARY KEY (id);


--
-- Name: connections connections_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.connections
    ADD CONSTRAINT connections_pkey PRIMARY KEY (id);


--
-- Name: cost_summaries cost_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.cost_summaries
    ADD CONSTRAINT cost_summaries_pkey PRIMARY KEY (id);


--
-- Name: costs costs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.costs
    ADD CONSTRAINT costs_pkey PRIMARY KEY (id);


--
-- Name: credit_cards credit_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.credit_cards
    ADD CONSTRAINT credit_cards_pkey PRIMARY KEY (id);


--
-- Name: currency_configurations currency_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.currency_configurations
    ADD CONSTRAINT currency_configurations_pkey PRIMARY KEY (id);


--
-- Name: custom_dashboards custom_dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.custom_dashboards
    ADD CONSTRAINT custom_dashboards_pkey PRIMARY KEY (id);


--
-- Name: dashboard_data dashboard_data_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.dashboard_data
    ADD CONSTRAINT dashboard_data_pkey PRIMARY KEY (id);


--
-- Name: email_notifications email_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.email_notifications
    ADD CONSTRAINT email_notifications_pkey PRIMARY KEY (id);


--
-- Name: email_templates email_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_pkey PRIMARY KEY (id);


--
-- Name: encryption_keys encryption_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.encryption_keys
    ADD CONSTRAINT encryption_keys_pkey PRIMARY KEY (id);


--
-- Name: environment_adapters environment_adapters_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_adapters
    ADD CONSTRAINT environment_adapters_pkey PRIMARY KEY (id);


--
-- Name: environment_filer_volumes environment_filer_volumes_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_filer_volumes
    ADD CONSTRAINT environment_filer_volumes_pkey PRIMARY KEY (id);


--
-- Name: environment_jobs environment_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_jobs
    ADD CONSTRAINT environment_jobs_pkey PRIMARY KEY (id);


--
-- Name: environment_kumo_services environment_kumo_services_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_kumo_services
    ADD CONSTRAINT environment_kumo_services_pkey PRIMARY KEY (id);


--
-- Name: environment_services environment_services_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_services
    ADD CONSTRAINT environment_services_pkey PRIMARY KEY (id);


--
-- Name: environment_storages environment_storages_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_storages
    ADD CONSTRAINT environment_storages_pkey PRIMARY KEY (id);


--
-- Name: environment_tags environment_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_tags
    ADD CONSTRAINT environment_tags_pkey PRIMARY KEY (id);


--
-- Name: environment_vpcs environment_vpcs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_vpcs
    ADD CONSTRAINT environment_vpcs_pkey PRIMARY KEY (id);


--
-- Name: environments environments_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT environments_pkey PRIMARY KEY (id);


--
-- Name: environments_tasks environments_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environments_tasks
    ADD CONSTRAINT environments_tasks_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: filer_configurations filer_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.filer_configurations
    ADD CONSTRAINT filer_configurations_pkey PRIMARY KEY (id);


--
-- Name: filer_services filer_services_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.filer_services
    ADD CONSTRAINT filer_services_pkey PRIMARY KEY (id);


--
-- Name: filers filers_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.filers
    ADD CONSTRAINT filers_pkey PRIMARY KEY (id);


--
-- Name: follow_up_email_histories follow_up_email_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.follow_up_email_histories
    ADD CONSTRAINT follow_up_email_histories_pkey PRIMARY KEY (id);


--
-- Name: follow_up_emails follow_up_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.follow_up_emails
    ADD CONSTRAINT follow_up_emails_pkey PRIMARY KEY (id);


--
-- Name: gcp_compute_pricings gcp_compute_pricings_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.gcp_compute_pricings
    ADD CONSTRAINT gcp_compute_pricings_pkey PRIMARY KEY (id);


--
-- Name: gcp_multi_regionals gcp_multi_regionals_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.gcp_multi_regionals
    ADD CONSTRAINT gcp_multi_regionals_pkey PRIMARY KEY (id);


--
-- Name: gcp_report_configurations gcp_report_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.gcp_report_configurations
    ADD CONSTRAINT gcp_report_configurations_pkey PRIMARY KEY (id);


--
-- Name: gcp_resource_zones gcp_resource_zones_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.gcp_resource_zones
    ADD CONSTRAINT gcp_resource_zones_pkey PRIMARY KEY (id);


--
-- Name: gcp_resources gcp_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.gcp_resources
    ADD CONSTRAINT gcp_resources_pkey PRIMARY KEY (id);


--
-- Name: gcp_service_forecast_costs gcp_service_forecast_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.gcp_service_forecast_costs
    ADD CONSTRAINT gcp_service_forecast_costs_pkey PRIMARY KEY (id);


--
-- Name: gcp_tenant_billing_adapters gcp_tenant_billing_adapters_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.gcp_tenant_billing_adapters
    ADD CONSTRAINT gcp_tenant_billing_adapters_pkey PRIMARY KEY (id);


--
-- Name: general_settings general_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.general_settings
    ADD CONSTRAINT general_settings_pkey PRIMARY KEY (id);


--
-- Name: group_roles group_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.group_roles
    ADD CONSTRAINT group_roles_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: groups_users groups_users_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.groups_users
    ADD CONSTRAINT groups_users_pkey PRIMARY KEY (id);


--
-- Name: iam_certificates iam_certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.iam_certificates
    ADD CONSTRAINT iam_certificates_pkey PRIMARY KEY (id);


--
-- Name: iam_groups iam_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.iam_groups
    ADD CONSTRAINT iam_groups_pkey PRIMARY KEY (id);


--
-- Name: iam_roles iam_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.iam_roles
    ADD CONSTRAINT iam_roles_pkey PRIMARY KEY (id);


--
-- Name: iam_user_role_policies iam_user_role_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.iam_user_role_policies
    ADD CONSTRAINT iam_user_role_policies_pkey PRIMARY KEY (id);


--
-- Name: iam_users iam_users_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.iam_users
    ADD CONSTRAINT iam_users_pkey PRIMARY KEY (id);


--
-- Name: instance_filer_volumes instance_filer_volumes_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.instance_filer_volumes
    ADD CONSTRAINT instance_filer_volumes_pkey PRIMARY KEY (id);


--
-- Name: filer_volumes instance_filers_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.filer_volumes
    ADD CONSTRAINT instance_filers_pkey PRIMARY KEY (id);


--
-- Name: instance_planners instance_planners_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.instance_planners
    ADD CONSTRAINT instance_planners_pkey PRIMARY KEY (id);


--
-- Name: integration_user_roles integration_user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.integration_user_roles
    ADD CONSTRAINT integration_user_roles_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);


--
-- Name: interfaces interfaces_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.interfaces
    ADD CONSTRAINT interfaces_pkey PRIMARY KEY (id);


--
-- Name: internet_gateways internet_gateways_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.internet_gateways
    ADD CONSTRAINT internet_gateways_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: kumo_services kumo_services_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.kumo_services
    ADD CONSTRAINT kumo_services_pkey PRIMARY KEY (id);


--
-- Name: kumo_services_tag_key_values kumo_services_tag_key_values_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.kumo_services_tag_key_values
    ADD CONSTRAINT kumo_services_tag_key_values_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: machine_image_configurations machine_image_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.machine_image_configurations
    ADD CONSTRAINT machine_image_configurations_pkey PRIMARY KEY (id);


--
-- Name: machine_image_configurations_soe_scripts machine_image_configurations_soe_scripts_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.machine_image_configurations_soe_scripts
    ADD CONSTRAINT machine_image_configurations_soe_scripts_pkey PRIMARY KEY (id);


--
-- Name: machine_image_groups machine_image_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.machine_image_groups
    ADD CONSTRAINT machine_image_groups_pkey PRIMARY KEY (id);


--
-- Name: machine_images machine_images_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.machine_images
    ADD CONSTRAINT machine_images_pkey PRIMARY KEY (id);


--
-- Name: nacls nacls_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.nacls
    ADD CONSTRAINT nacls_pkey PRIMARY KEY (id);


--
-- Name: network_interfaces network_interfaces_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.network_interfaces
    ADD CONSTRAINT network_interfaces_pkey PRIMARY KEY (id);


--
-- Name: organisation_adapters organisation_adapters_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisation_adapters
    ADD CONSTRAINT organisation_adapters_pkey PRIMARY KEY (id);


--
-- Name: organisation_brands organisation_brands_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisation_brands
    ADD CONSTRAINT organisation_brands_pkey PRIMARY KEY (id);


--
-- Name: organisation_details organisation_details_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisation_details
    ADD CONSTRAINT organisation_details_pkey PRIMARY KEY (id);


--
-- Name: organisation_images_copy organisation_images_copy_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisation_images_copy
    ADD CONSTRAINT organisation_images_copy_pkey PRIMARY KEY (id);


--
-- Name: organisation_images organisation_images_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisation_images
    ADD CONSTRAINT organisation_images_pkey PRIMARY KEY (id);


--
-- Name: organisation_saml_users organisation_saml_users_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisation_saml_users
    ADD CONSTRAINT organisation_saml_users_pkey PRIMARY KEY (id);


--
-- Name: organisation_service_groups organisation_service_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisation_service_groups
    ADD CONSTRAINT organisation_service_groups_pkey PRIMARY KEY (id);


--
-- Name: organisations organisations_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisations
    ADD CONSTRAINT organisations_pkey PRIMARY KEY (id);


--
-- Name: organisations_users organisations_users_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisations_users
    ADD CONSTRAINT organisations_users_pkey PRIMARY KEY (uuid);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: policies policies_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.policies
    ADD CONSTRAINT policies_pkey PRIMARY KEY (id);


--
-- Name: protocols protocols_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.protocols
    ADD CONSTRAINT protocols_pkey PRIMARY KEY (id);


--
-- Name: rds_configurations rds_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.rds_configurations
    ADD CONSTRAINT rds_configurations_pkey PRIMARY KEY (id);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (id);


--
-- Name: report_configurations report_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.report_configurations
    ADD CONSTRAINT report_configurations_pkey PRIMARY KEY (id);


--
-- Name: reserved_instances reserved_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.reserved_instances
    ADD CONSTRAINT reserved_instances_pkey PRIMARY KEY (id);


--
-- Name: resource_groups resource_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.resource_groups
    ADD CONSTRAINT resource_groups_pkey PRIMARY KEY (id);


--
-- Name: resources resources_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_pkey PRIMARY KEY (id);


--
-- Name: right_size_configurations right_size_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.right_size_configurations
    ADD CONSTRAINT right_size_configurations_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: route_tables route_tables_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.route_tables
    ADD CONSTRAINT route_tables_pkey PRIMARY KEY (id);


--
-- Name: security_groups security_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.security_groups
    ADD CONSTRAINT security_groups_pkey PRIMARY KEY (id);


--
-- Name: service_adviser_configs service_adviser_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.service_adviser_configs
    ADD CONSTRAINT service_adviser_configs_pkey PRIMARY KEY (id);


--
-- Name: service_adviser_summaries service_adviser_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.service_adviser_summaries
    ADD CONSTRAINT service_adviser_summaries_pkey PRIMARY KEY (id);


--
-- Name: service_advisor_logs service_advisor_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.service_advisor_logs
    ADD CONSTRAINT service_advisor_logs_pkey PRIMARY KEY (id);


--
-- Name: service_details service_details_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.service_details
    ADD CONSTRAINT service_details_pkey PRIMARY KEY (id);


--
-- Name: service_encryption_keys service_encryption_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.service_encryption_keys
    ADD CONSTRAINT service_encryption_keys_pkey PRIMARY KEY (id);


--
-- Name: service_events service_events_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.service_events
    ADD CONSTRAINT service_events_pkey PRIMARY KEY (id);


--
-- Name: service_groups service_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.service_groups
    ADD CONSTRAINT service_groups_pkey PRIMARY KEY (id);


--
-- Name: service_naming_defaults service_naming_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.service_naming_defaults
    ADD CONSTRAINT service_naming_defaults_pkey PRIMARY KEY (id);


--
-- Name: service_synchronization_histories service_synchronization_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.service_synchronization_histories
    ADD CONSTRAINT service_synchronization_histories_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: services_tasks services_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.services_tasks
    ADD CONSTRAINT services_tasks_pkey PRIMARY KEY (id);


--
-- Name: slack_users slack_users_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.slack_users
    ADD CONSTRAINT slack_users_pkey PRIMARY KEY (id);


--
-- Name: snapshots snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.snapshots
    ADD CONSTRAINT snapshots_pkey PRIMARY KEY (id);


--
-- Name: snapshots_tasks snapshots_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.snapshots_tasks
    ADD CONSTRAINT snapshots_tasks_pkey PRIMARY KEY (id);


--
-- Name: soe_scripts_groups soe_scripts_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.soe_scripts_groups
    ADD CONSTRAINT soe_scripts_groups_pkey PRIMARY KEY (id);


--
-- Name: soe_scripts soe_scripts_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.soe_scripts
    ADD CONSTRAINT soe_scripts_pkey PRIMARY KEY (id);


--
-- Name: soe_scripts_remote_sources soe_scripts_remote_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.soe_scripts_remote_sources
    ADD CONSTRAINT soe_scripts_remote_sources_pkey PRIMARY KEY (id);


--
-- Name: sso_configs sso_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.sso_configs
    ADD CONSTRAINT sso_configs_pkey PRIMARY KEY (id);


--
-- Name: storage_vms storage_vms_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.storage_vms
    ADD CONSTRAINT storage_vms_pkey PRIMARY KEY (id);


--
-- Name: storages storages_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.storages
    ADD CONSTRAINT storages_pkey PRIMARY KEY (id);


--
-- Name: subnet_groups subnet_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.subnet_groups
    ADD CONSTRAINT subnet_groups_pkey PRIMARY KEY (id);


--
-- Name: subnets subnets_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.subnets
    ADD CONSTRAINT subnets_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: synchronization_settings synchronization_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.synchronization_settings
    ADD CONSTRAINT synchronization_settings_pkey PRIMARY KEY (id);


--
-- Name: synchronizations synchronizations_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.synchronizations
    ADD CONSTRAINT synchronizations_pkey PRIMARY KEY (id);


--
-- Name: tag_key_values tag_key_values_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tag_key_values
    ADD CONSTRAINT tag_key_values_pkey PRIMARY KEY (id);


--
-- Name: tag_keys tag_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tag_keys
    ADD CONSTRAINT tag_keys_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: task_details task_details_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.task_details
    ADD CONSTRAINT task_details_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: teams_users teams_users_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.teams_users
    ADD CONSTRAINT teams_users_pkey PRIMARY KEY (id);


--
-- Name: template_costs template_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.template_costs
    ADD CONSTRAINT template_costs_pkey PRIMARY KEY (id);


--
-- Name: template_kumo_services template_kumo_services_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.template_kumo_services
    ADD CONSTRAINT template_kumo_services_pkey PRIMARY KEY (id);


--
-- Name: template_services template_services_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.template_services
    ADD CONSTRAINT template_services_pkey PRIMARY KEY (id);


--
-- Name: template_vpcs template_vpcs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.template_vpcs
    ADD CONSTRAINT template_vpcs_pkey PRIMARY KEY (id);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: tenant_adapters tenant_adapters_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenant_adapters
    ADD CONSTRAINT tenant_adapters_pkey PRIMARY KEY (id);


--
-- Name: tenant_billing_adapters tenant_billing_adapters_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenant_billing_adapters
    ADD CONSTRAINT tenant_billing_adapters_pkey PRIMARY KEY (id);


--
-- Name: tenant_service_groups tenant_service_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenant_service_groups
    ADD CONSTRAINT tenant_service_groups_pkey PRIMARY KEY (id);


--
-- Name: tenant_users tenant_users_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenant_users
    ADD CONSTRAINT tenant_users_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants_resource_groups tenants_resource_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenants_resource_groups
    ADD CONSTRAINT tenants_resource_groups_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles_users user_roles_users_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.user_roles_users
    ADD CONSTRAINT user_roles_users_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vm_ware_service_forecast_costs vm_ware_service_forecast_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.vm_ware_service_forecast_costs
    ADD CONSTRAINT vm_ware_service_forecast_costs_pkey PRIMARY KEY (id);


--
-- Name: vm_ware_tenant_adapters vm_ware_tenant_adapters_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.vm_ware_tenant_adapters
    ADD CONSTRAINT vm_ware_tenant_adapters_pkey PRIMARY KEY (id);


--
-- Name: vpcs vpcs_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.vpcs
    ADD CONSTRAINT vpcs_pkey PRIMARY KEY (id);


--
-- Name: vw_events vw_events_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.vw_events
    ADD CONSTRAINT vw_events_pkey PRIMARY KEY (id);


--
-- Name: vw_inventories vw_inventories_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.vw_inventories
    ADD CONSTRAINT vw_inventories_pkey PRIMARY KEY (id);


--
-- Name: vw_metrics vw_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.vw_metrics
    ADD CONSTRAINT vw_metrics_pkey PRIMARY KEY (id);


--
-- Name: vw_vcenters vw_vcenters_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.vw_vcenters
    ADD CONSTRAINT vw_vcenters_pkey PRIMARY KEY (id);


--
-- Name: vw_vdc_files vw_vdc_files_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.vw_vdc_files
    ADD CONSTRAINT vw_vdc_files_pkey PRIMARY KEY (id);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (id);


--
-- Name: adapter_machine_images_grouped_colume_index; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX adapter_machine_images_grouped_colume_index ON public.adapters_machine_images USING btree (adapter_id, machine_image_id);


--
-- Name: adapter_tenant_rg_index; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX adapter_tenant_rg_index ON public.tenants_resource_groups USING btree (adapter_id, tenant_id, azure_resource_group_id);


--
-- Name: azure_resource_association_with child; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX "azure_resource_association_with child" ON public.azure_resource_connections USING btree (resource_id, associated_resource_id);


--
-- Name: azure_resource_association_with parent; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX "azure_resource_association_with parent" ON public.azure_resource_connections USING btree (associated_resource_id, resource_id);


--
-- Name: customer_group; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX customer_group ON public.service_groups USING btree (billing_adapter_id, tenant_id, account_id, customer_id);


--
-- Name: env_filer_volumes_on_environment_id_and_filer_volume_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX env_filer_volumes_on_environment_id_and_filer_volume_id ON public.environment_filer_volumes USING btree (environment_id, filer_volume_id);


--
-- Name: env_filer_volumes_on_filer_volume_id_and_environment_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX env_filer_volumes_on_filer_volume_id_and_environment_id ON public.environment_filer_volumes USING btree (filer_volume_id, environment_id);


--
-- Name: index_access_rights_user_roles_on_right_id_and_role_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_access_rights_user_roles_on_right_id_and_role_id ON public.access_rights_user_roles USING btree (access_right_id, user_role_id);


--
-- Name: index_access_rights_user_roles_on_user_role_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_access_rights_user_roles_on_user_role_id ON public.access_rights_user_roles USING btree (user_role_id);


--
-- Name: index_account_gcp_multi_regions_on_account_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_account_gcp_multi_regions_on_account_id ON public.account_gcp_multi_regions USING btree (account_id);


--
-- Name: index_account_gcp_multi_regions_on_gcp_multi_regional_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_account_gcp_multi_regions_on_gcp_multi_regional_id ON public.account_gcp_multi_regions USING btree (gcp_multi_regional_id);


--
-- Name: index_adapters_machine_images_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_adapters_machine_images_on_adapter_id ON public.adapters_machine_images USING btree (adapter_id);


--
-- Name: index_adapters_machine_images_on_machine_image_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_adapters_machine_images_on_machine_image_id ON public.adapters_machine_images USING btree (machine_image_id);


--
-- Name: index_adapters_on_ancestry; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_adapters_on_ancestry ON public.adapters USING btree (ancestry);


--
-- Name: index_adapters_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_adapters_on_id ON public.adapters USING btree (id);


--
-- Name: index_adapters_tasks_on_tenant_access; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_adapters_tasks_on_tenant_access ON public.adapters_tasks USING btree (tenant_access);


--
-- Name: index_app_access_secrets_on_organisation_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_app_access_secrets_on_organisation_id ON public.app_access_secrets USING btree (organisation_id);


--
-- Name: index_app_access_secrets_on_user_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_app_access_secrets_on_user_id ON public.app_access_secrets USING btree (user_id);


--
-- Name: index_associated_services_on_associated_kumo_service_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_associated_services_on_associated_kumo_service_id ON public.associated_services USING btree (associated_kumo_service_id);


--
-- Name: index_associated_services_on_kumo_service_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_associated_services_on_kumo_service_id ON public.associated_services USING btree (kumo_service_id);


--
-- Name: index_aws_cloud_trails_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_aws_cloud_trails_on_adapter_id ON public.aws_cloud_trails USING btree (adapter_id);


--
-- Name: index_aws_cloud_watch_logs_on_account_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_aws_cloud_watch_logs_on_account_id ON public.aws_cloud_watch_logs USING btree (account_id);


--
-- Name: index_aws_cloud_watch_logs_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_aws_cloud_watch_logs_on_adapter_id ON public.aws_cloud_watch_logs USING btree (adapter_id);


--
-- Name: index_aws_cloud_watch_logs_on_region_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_aws_cloud_watch_logs_on_region_id ON public.aws_cloud_watch_logs USING btree (region_id);


--
-- Name: index_aws_records_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_aws_records_on_adapter_id ON public.aws_records USING btree (adapter_id);


--
-- Name: index_aws_records_on_provider_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_aws_records_on_provider_id ON public.aws_records USING btree (provider_id);


--
-- Name: index_aws_right_sizings_on_type; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_aws_right_sizings_on_type ON public.aws_right_sizings USING btree (type);


--
-- Name: index_aws_service_forecast_costs_on_account_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_aws_service_forecast_costs_on_account_id ON public.aws_service_forecast_costs USING btree (account_id);


--
-- Name: index_aws_trails_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_aws_trails_on_adapter_id ON public.aws_trails USING btree (adapter_id);


--
-- Name: index_aws_trails_on_region_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_aws_trails_on_region_id ON public.aws_trails USING btree (region_id);


--
-- Name: index_az_resource_on_adapter_and_resource_group_and_region; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_az_resource_on_adapter_and_resource_group_and_region ON public.azure_resources USING btree (adapter_id, azure_resource_group_id, region_id);


--
-- Name: index_az_resource_on_adapter_id_and_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_az_resource_on_adapter_id_and_resource_group_id ON public.azure_resources USING btree (adapter_id, azure_resource_group_id);


--
-- Name: index_azure_availability_sets_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_availability_sets_on_adapter_id ON public.azure_availability_sets USING btree (adapter_id);


--
-- Name: index_azure_availability_sets_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_availability_sets_on_id ON public.azure_availability_sets USING btree (id);


--
-- Name: index_azure_availability_sets_on_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_availability_sets_on_resource_group_id ON public.azure_availability_sets USING btree (resource_group_id);


--
-- Name: index_azure_availability_sets_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_availability_sets_on_subscription_id ON public.azure_availability_sets USING btree (subscription_id);


--
-- Name: index_azure_compliance_checks_on_azure_compliance_standard_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_compliance_checks_on_azure_compliance_standard_id ON public.azure_compliance_checks USING btree (azure_compliance_standard_id);


--
-- Name: index_azure_cost_summaries_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_cost_summaries_on_id ON public.azure_cost_summaries USING btree (id);


--
-- Name: index_azure_cost_summaries_on_kumo_service_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_cost_summaries_on_kumo_service_id ON public.azure_cost_summaries USING btree (kumo_service_id);


--
-- Name: index_azure_disks_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_disks_on_adapter_id ON public.azure_disks USING btree (adapter_id);


--
-- Name: index_azure_disks_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_disks_on_id ON public.azure_disks USING btree (id);


--
-- Name: index_azure_disks_on_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_disks_on_resource_group_id ON public.azure_disks USING btree (resource_group_id);


--
-- Name: index_azure_disks_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_disks_on_subscription_id ON public.azure_disks USING btree (subscription_id);


--
-- Name: index_azure_export_configurations_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_export_configurations_on_adapter_id ON public.azure_export_configurations USING btree (adapter_id);


--
-- Name: index_azure_load_balancers_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_load_balancers_on_adapter_id ON public.azure_load_balancers USING btree (adapter_id);


--
-- Name: index_azure_load_balancers_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_load_balancers_on_id ON public.azure_load_balancers USING btree (id);


--
-- Name: index_azure_load_balancers_on_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_load_balancers_on_resource_group_id ON public.azure_load_balancers USING btree (resource_group_id);


--
-- Name: index_azure_load_balancers_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_load_balancers_on_subscription_id ON public.azure_load_balancers USING btree (subscription_id);


--
-- Name: index_azure_network_interfaces_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_network_interfaces_on_adapter_id ON public.azure_network_interfaces USING btree (adapter_id);


--
-- Name: index_azure_network_interfaces_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_network_interfaces_on_id ON public.azure_network_interfaces USING btree (id);


--
-- Name: index_azure_network_interfaces_on_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_network_interfaces_on_resource_group_id ON public.azure_network_interfaces USING btree (resource_group_id);


--
-- Name: index_azure_network_interfaces_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_network_interfaces_on_subscription_id ON public.azure_network_interfaces USING btree (subscription_id);


--
-- Name: index_azure_public_ip_addresses_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_public_ip_addresses_on_adapter_id ON public.azure_public_ip_addresses USING btree (adapter_id);


--
-- Name: index_azure_public_ip_addresses_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_public_ip_addresses_on_id ON public.azure_public_ip_addresses USING btree (id);


--
-- Name: index_azure_public_ip_addresses_on_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_public_ip_addresses_on_resource_group_id ON public.azure_public_ip_addresses USING btree (resource_group_id);


--
-- Name: index_azure_public_ip_addresses_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_public_ip_addresses_on_subscription_id ON public.azure_public_ip_addresses USING btree (subscription_id);


--
-- Name: index_azure_rate_cards_on_rates; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_rate_cards_on_rates ON public.azure_rate_cards USING gin (rates);


--
-- Name: index_azure_resource_connections_on_associated_resource_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_resource_connections_on_associated_resource_id ON public.azure_resource_connections USING btree (associated_resource_id);


--
-- Name: index_azure_resource_connections_on_resource_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_resource_connections_on_resource_id ON public.azure_resource_connections USING btree (resource_id);


--
-- Name: index_azure_resource_groups_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_resource_groups_on_adapter_id ON public.azure_resource_groups USING btree (adapter_id);


--
-- Name: index_azure_resource_groups_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_resource_groups_on_id ON public.azure_resource_groups USING btree (id);


--
-- Name: index_azure_resource_groups_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_resource_groups_on_subscription_id ON public.azure_resource_groups USING btree (subscription_id);


--
-- Name: index_azure_resources_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_resources_on_adapter_id ON public.azure_resources USING btree (adapter_id);


--
-- Name: index_azure_resources_on_azure_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_resources_on_azure_resource_group_id ON public.azure_resources USING btree (azure_resource_group_id);


--
-- Name: index_azure_resources_on_cost_by_hour; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_resources_on_cost_by_hour ON public.azure_resources USING btree (cost_by_hour DESC);


--
-- Name: index_azure_resources_on_region_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_resources_on_region_id ON public.azure_resources USING btree (region_id);


--
-- Name: index_azure_rg_service_forecast_costs_on_account_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_rg_service_forecast_costs_on_account_id ON public.azure_rg_service_forecast_costs USING btree (account_id);


--
-- Name: index_azure_route_tables_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_route_tables_on_adapter_id ON public.azure_route_tables USING btree (adapter_id);


--
-- Name: index_azure_route_tables_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_route_tables_on_id ON public.azure_route_tables USING btree (id);


--
-- Name: index_azure_route_tables_on_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_route_tables_on_resource_group_id ON public.azure_route_tables USING btree (resource_group_id);


--
-- Name: index_azure_route_tables_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_route_tables_on_subscription_id ON public.azure_route_tables USING btree (subscription_id);


--
-- Name: index_azure_security_groups_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_security_groups_on_adapter_id ON public.azure_security_groups USING btree (adapter_id);


--
-- Name: index_azure_security_groups_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_security_groups_on_id ON public.azure_security_groups USING btree (id);


--
-- Name: index_azure_security_groups_on_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_security_groups_on_resource_group_id ON public.azure_security_groups USING btree (resource_group_id);


--
-- Name: index_azure_security_groups_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_security_groups_on_subscription_id ON public.azure_security_groups USING btree (subscription_id);


--
-- Name: index_azure_service_forecast_costs_on_account_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_service_forecast_costs_on_account_id ON public.azure_service_forecast_costs USING btree (account_id);


--
-- Name: index_azure_sql_db_servers_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_sql_db_servers_on_adapter_id ON public.azure_sql_db_servers USING btree (adapter_id);


--
-- Name: index_azure_sql_db_servers_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_sql_db_servers_on_id ON public.azure_sql_db_servers USING btree (id);


--
-- Name: index_azure_sql_db_servers_on_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_sql_db_servers_on_resource_group_id ON public.azure_sql_db_servers USING btree (resource_group_id);


--
-- Name: index_azure_sql_db_servers_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_sql_db_servers_on_subscription_id ON public.azure_sql_db_servers USING btree (subscription_id);


--
-- Name: index_azure_sql_dbs_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_sql_dbs_on_adapter_id ON public.azure_sql_dbs USING btree (adapter_id);


--
-- Name: index_azure_sql_dbs_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_sql_dbs_on_id ON public.azure_sql_dbs USING btree (id);


--
-- Name: index_azure_sql_dbs_on_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_sql_dbs_on_resource_group_id ON public.azure_sql_dbs USING btree (resource_group_id);


--
-- Name: index_azure_sql_dbs_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_sql_dbs_on_subscription_id ON public.azure_sql_dbs USING btree (subscription_id);


--
-- Name: index_azure_storage_accounts_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_storage_accounts_on_adapter_id ON public.azure_storage_accounts USING btree (adapter_id);


--
-- Name: index_azure_storage_accounts_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_storage_accounts_on_id ON public.azure_storage_accounts USING btree (id);


--
-- Name: index_azure_storage_accounts_on_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_storage_accounts_on_resource_group_id ON public.azure_storage_accounts USING btree (resource_group_id);


--
-- Name: index_azure_storage_accounts_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_storage_accounts_on_subscription_id ON public.azure_storage_accounts USING btree (subscription_id);


--
-- Name: index_azure_subnets_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_subnets_on_adapter_id ON public.azure_subnets USING btree (adapter_id);


--
-- Name: index_azure_subnets_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_subnets_on_id ON public.azure_subnets USING btree (id);


--
-- Name: index_azure_subnets_on_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_subnets_on_resource_group_id ON public.azure_subnets USING btree (resource_group_id);


--
-- Name: index_azure_subnets_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_subnets_on_subscription_id ON public.azure_subnets USING btree (subscription_id);


--
-- Name: index_azure_subscriptions_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_subscriptions_on_adapter_id ON public.azure_subscriptions USING btree (adapter_id);


--
-- Name: index_azure_virtual_machines_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_virtual_machines_on_adapter_id ON public.azure_virtual_machines USING btree (adapter_id);


--
-- Name: index_azure_virtual_machines_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_virtual_machines_on_id ON public.azure_virtual_machines USING btree (id);


--
-- Name: index_azure_virtual_machines_on_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_virtual_machines_on_resource_group_id ON public.azure_virtual_machines USING btree (resource_group_id);


--
-- Name: index_azure_virtual_machines_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_virtual_machines_on_subscription_id ON public.azure_virtual_machines USING btree (subscription_id);


--
-- Name: index_azure_vnets_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_vnets_on_adapter_id ON public.azure_vnets USING btree (adapter_id);


--
-- Name: index_azure_vnets_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_vnets_on_id ON public.azure_vnets USING btree (id);


--
-- Name: index_azure_vnets_on_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_vnets_on_resource_group_id ON public.azure_vnets USING btree (resource_group_id);


--
-- Name: index_azure_vnets_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_azure_vnets_on_subscription_id ON public.azure_vnets USING btree (subscription_id);


--
-- Name: index_billing_currencies_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_billing_currencies_on_adapter_id ON public.billing_currencies USING btree (adapter_id);


--
-- Name: index_child_org_on_org_and_service_groups; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_child_org_on_org_and_service_groups ON public.organisation_service_groups USING btree (organisation_id, service_group_id);


--
-- Name: index_clusters_environments_on_cluster_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_clusters_environments_on_cluster_id ON public.clusters_environments USING btree (cluster_id);


--
-- Name: index_clusters_environments_on_environment_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_clusters_environments_on_environment_id ON public.clusters_environments USING btree (environment_id);


--
-- Name: index_compliance_checks_on_compliance_standard_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_compliance_checks_on_compliance_standard_id ON public.compliance_checks USING btree (compliance_standard_id);


--
-- Name: index_config_scripts_on_ami_conf_id_and_soe_script_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_config_scripts_on_ami_conf_id_and_soe_script_id ON public.machine_image_configurations_soe_scripts USING btree (machine_image_configuration_id, soe_script_id, soe_script_type);


--
-- Name: index_connections_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_connections_on_id ON public.connections USING btree (id);


--
-- Name: index_connections_on_interface_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_connections_on_interface_id ON public.connections USING btree (interface_id);


--
-- Name: index_connections_on_remote_interface_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_connections_on_remote_interface_id ON public.connections USING btree (remote_interface_id);


--
-- Name: index_cost_summaries_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_cost_summaries_on_adapter_id ON public.cost_summaries USING btree (adapter_id);


--
-- Name: index_costs_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_costs_on_adapter_id ON public.costs USING btree (adapter_id);


--
-- Name: index_currency_configurations_on_organisation_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_currency_configurations_on_organisation_id ON public.currency_configurations USING btree (organisation_id);


--
-- Name: index_custom_dashboards_on_name; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_custom_dashboards_on_name ON public.custom_dashboards USING btree (name);


--
-- Name: index_custom_dashboards_on_organisation_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_custom_dashboards_on_organisation_id ON public.custom_dashboards USING btree (organisation_id);


--
-- Name: index_custom_dashboards_on_user_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_custom_dashboards_on_user_id ON public.custom_dashboards USING btree (user_id);


--
-- Name: index_email_templates_on_organisation_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_email_templates_on_organisation_id ON public.email_templates USING btree (organisation_id);


--
-- Name: index_encryption_keys_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_encryption_keys_on_adapter_id ON public.encryption_keys USING btree (adapter_id);


--
-- Name: index_env_kumo_services_on_environment_id_and_kumo_service_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_env_kumo_services_on_environment_id_and_kumo_service_id ON public.environment_kumo_services USING btree (environment_id);


--
-- Name: index_environment_kumo_services_on_environment_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_environment_kumo_services_on_environment_id ON public.environment_kumo_services USING btree (environment_id);


--
-- Name: index_environment_kumo_services_on_kumo_service_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_environment_kumo_services_on_kumo_service_id ON public.environment_kumo_services USING btree (kumo_service_id);


--
-- Name: index_environment_services_on_environment_id_and_service_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_environment_services_on_environment_id_and_service_id ON public.environment_services USING btree (environment_id, service_id);


--
-- Name: index_environment_services_on_service_id_and_environment_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_environment_services_on_service_id_and_environment_id ON public.environment_services USING btree (service_id, environment_id);


--
-- Name: index_environments_on_default_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_environments_on_default_adapter_id ON public.environments USING btree (default_adapter_id);


--
-- Name: index_environments_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_environments_on_subscription_id ON public.environments USING btree (subscription_id);


--
-- Name: index_environments_tasks_on_environment_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_environments_tasks_on_environment_id ON public.environments_tasks USING btree (environment_id);


--
-- Name: index_environments_tasks_on_task_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_environments_tasks_on_task_id ON public.environments_tasks USING btree (task_id);


--
-- Name: index_filer_volumes_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_filer_volumes_on_id ON public.filer_volumes USING btree (id);


--
-- Name: index_filer_volumes_on_kumo_service_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_filer_volumes_on_kumo_service_id ON public.filer_volumes USING btree (kumo_service_id);


--
-- Name: index_follow_up_email_histories_on_follow_up_email_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_follow_up_email_histories_on_follow_up_email_id ON public.follow_up_email_histories USING btree (follow_up_email_id);


--
-- Name: index_follow_up_emails_on_account_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_follow_up_emails_on_account_id ON public.follow_up_emails USING btree (account_id);


--
-- Name: index_follow_up_emails_on_user_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_follow_up_emails_on_user_id ON public.follow_up_emails USING btree (user_id);


--
-- Name: index_gcp_multi_regionals_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_gcp_multi_regionals_on_adapter_id ON public.gcp_multi_regionals USING btree (adapter_id);


--
-- Name: index_gcp_multi_regionals_on_id_and_code; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_gcp_multi_regionals_on_id_and_code ON public.gcp_multi_regionals USING btree (id, code);


--
-- Name: index_gcp_on_description_and_res_gp_and_ser_regions; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_gcp_on_description_and_res_gp_and_ser_regions ON public.gcp_compute_pricings USING btree (description, resource_group, service_regions);


--
-- Name: index_gcp_report_configurations_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_gcp_report_configurations_on_adapter_id ON public.gcp_report_configurations USING btree (adapter_id);


--
-- Name: index_gcp_resource_on_adapter_and_resource_zone_and_region; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_gcp_resource_on_adapter_and_resource_zone_and_region ON public.gcp_resources USING btree (adapter_id, gcp_resource_zone_id, region_id);


--
-- Name: index_gcp_resource_on_adapter_id_and_resource_zone_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_gcp_resource_on_adapter_id_and_resource_zone_id ON public.gcp_resources USING btree (adapter_id, gcp_resource_zone_id);


--
-- Name: index_gcp_resource_zones_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_gcp_resource_zones_on_adapter_id ON public.gcp_resource_zones USING btree (adapter_id);


--
-- Name: index_gcp_resource_zones_on_region_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_gcp_resource_zones_on_region_id ON public.gcp_resource_zones USING btree (region_id);


--
-- Name: index_gcp_resources_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_gcp_resources_on_adapter_id ON public.gcp_resources USING btree (adapter_id);


--
-- Name: index_gcp_resources_on_gcp_multi_regional_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_gcp_resources_on_gcp_multi_regional_id ON public.gcp_resources USING btree (gcp_multi_regional_id);


--
-- Name: index_gcp_resources_on_gcp_resource_zone_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_gcp_resources_on_gcp_resource_zone_id ON public.gcp_resources USING btree (gcp_resource_zone_id);


--
-- Name: index_gcp_resources_on_region_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_gcp_resources_on_region_id ON public.gcp_resources USING btree (region_id);


--
-- Name: index_gcp_service_forecast_costs_on_account_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_gcp_service_forecast_costs_on_account_id ON public.gcp_service_forecast_costs USING btree (account_id);


--
-- Name: index_iam_roles_on_aws_account_id_and_role; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_iam_roles_on_aws_account_id_and_role ON public.iam_roles USING btree (aws_account_id, role);


--
-- Name: index_ig_on_adapter_id_and_region_id_and_vpc_id_and_provider_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_ig_on_adapter_id_and_region_id_and_vpc_id_and_provider_id ON public.internet_gateways USING btree (adapter_id, region_id, vpc_id, provider_id);


--
-- Name: index_instance_filer_volumes_on_filer_volume_id_and_service_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_instance_filer_volumes_on_filer_volume_id_and_service_id ON public.instance_filer_volumes USING btree (filer_volume_id, service_id);


--
-- Name: index_instance_filer_volumes_on_service_id_and_filer_volume_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_instance_filer_volumes_on_service_id_and_filer_volume_id ON public.instance_filer_volumes USING btree (service_id, filer_volume_id);


--
-- Name: index_integrations_on_slack_members; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_integrations_on_slack_members ON public.integrations USING gin (slack_members);


--
-- Name: index_integrations_on_user_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_integrations_on_user_id ON public.integrations USING btree (user_id);


--
-- Name: index_integrations_on_workspace_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_integrations_on_workspace_id ON public.integrations USING btree (workspace_id);


--
-- Name: index_interfaces_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_interfaces_on_id ON public.interfaces USING btree (id);


--
-- Name: index_interfaces_on_service_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_interfaces_on_service_id ON public.interfaces USING btree (service_id);


--
-- Name: index_internet_gateways_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_internet_gateways_on_adapter_id ON public.internet_gateways USING btree (adapter_id);


--
-- Name: index_keys_on_tag_key_adapter_id_subscription_id_region_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_keys_on_tag_key_adapter_id_subscription_id_region_id ON public.tag_keys USING btree (key, adapter_id, subscription_id, region_id);


--
-- Name: index_kumo_services_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_kumo_services_on_adapter_id ON public.kumo_services USING btree (adapter_id);


--
-- Name: index_kumo_services_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_kumo_services_on_id ON public.kumo_services USING btree (id);


--
-- Name: index_kumo_services_on_region_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_kumo_services_on_region_id ON public.kumo_services USING btree (region_id);


--
-- Name: index_kumo_services_on_service_type; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_kumo_services_on_service_type ON public.kumo_services USING btree (service_type);


--
-- Name: index_kumo_services_on_state; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_kumo_services_on_state ON public.kumo_services USING btree (state);


--
-- Name: index_kumo_services_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_kumo_services_on_subscription_id ON public.kumo_services USING btree (subscription_id);


--
-- Name: index_kumo_services_tag_key_values_on_kumo_service_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_kumo_services_tag_key_values_on_kumo_service_id ON public.kumo_services_tag_key_values USING btree (kumo_service_id);


--
-- Name: index_machine_image_configurations_on_account_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_machine_image_configurations_on_account_id ON public.machine_image_configurations USING btree (account_id);


--
-- Name: index_machine_image_configurations_on_ami_config_category_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_machine_image_configurations_on_ami_config_category_id ON public.machine_image_configurations USING btree (ami_config_category_id);


--
-- Name: index_machine_image_groups_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_machine_image_groups_on_id ON public.machine_image_groups USING btree (id);


--
-- Name: index_machine_image_groups_on_match_key_and_region_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_machine_image_groups_on_match_key_and_region_id ON public.machine_image_groups USING btree (match_key, region_id);


--
-- Name: index_machine_image_groups_on_name_and_region_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_machine_image_groups_on_name_and_region_id ON public.machine_image_groups USING btree (name, region_id);


--
-- Name: index_machine_images_on_image_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_machine_images_on_image_id ON public.machine_images USING btree (image_id);


--
-- Name: index_machine_images_on_image_id_and_region_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_machine_images_on_image_id_and_region_id ON public.machine_images USING btree (image_id, region_id);


--
-- Name: index_machine_images_on_image_owner_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_machine_images_on_image_owner_id ON public.machine_images USING btree (image_owner_id);


--
-- Name: index_nacls_on_adapter_and_region_and_vpc_and_provider; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_nacls_on_adapter_and_region_and_vpc_and_provider ON public.nacls USING btree (adapter_id, region_id, vpc_id, provider_id);


--
-- Name: index_nacls_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_nacls_on_adapter_id ON public.nacls USING btree (adapter_id);


--
-- Name: index_organisation_adapters_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_organisation_adapters_on_adapter_id ON public.organisation_adapters USING btree (adapter_id);


--
-- Name: index_organisation_adapters_on_organisation_id_and_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_organisation_adapters_on_organisation_id_and_adapter_id ON public.organisation_adapters USING btree (organisation_id, adapter_id);


--
-- Name: index_organisation_images_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_organisation_images_on_id ON public.organisation_images USING btree (id);


--
-- Name: index_organisation_images_on_machine_image_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_organisation_images_on_machine_image_group_id ON public.organisation_images USING btree (machine_image_group_id);


--
-- Name: index_organisation_images_on_machine_image_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_organisation_images_on_machine_image_id ON public.organisation_images USING btree (machine_image_id);


--
-- Name: index_organisation_images_on_region_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_organisation_images_on_region_id ON public.organisation_images USING btree (region_id);


--
-- Name: index_organisation_service_groups_on_service_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_organisation_service_groups_on_service_group_id ON public.organisation_service_groups USING btree (service_group_id);


--
-- Name: index_organisations_on_user_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_organisations_on_user_id ON public.organisations USING btree (user_id);


--
-- Name: index_report_configurations_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_report_configurations_on_adapter_id ON public.report_configurations USING btree (adapter_id);


--
-- Name: index_resources_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_resources_on_adapter_id ON public.resources USING btree (adapter_id);


--
-- Name: index_roles_on_name; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_roles_on_name ON public.roles USING btree (name);


--
-- Name: index_roles_on_name_and_resource_type_and_resource_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_roles_on_name_and_resource_type_and_resource_id ON public.roles USING btree (name, resource_type, resource_id);


--
-- Name: index_route_tables_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_route_tables_on_adapter_id ON public.route_tables USING btree (adapter_id);


--
-- Name: index_rt_on_adapter_id_and_region_id_and_vpc_id_and_provider_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_rt_on_adapter_id_and_region_id_and_vpc_id_and_provider_id ON public.route_tables USING btree (adapter_id, region_id, vpc_id, provider_id);


--
-- Name: index_sb_on_adapter_id_and_region_id_and_vpc_id_and_provider_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_sb_on_adapter_id_and_region_id_and_vpc_id_and_provider_id ON public.subnets USING btree (adapter_id, region_id, vpc_id, provider_id);


--
-- Name: index_security_groups_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_security_groups_on_adapter_id ON public.security_groups USING btree (adapter_id);


--
-- Name: index_service_groups_on_account_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_service_groups_on_account_id ON public.service_groups USING btree (account_id);


--
-- Name: index_service_groups_on_billing_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_service_groups_on_billing_adapter_id ON public.service_groups USING btree (billing_adapter_id);


--
-- Name: index_service_groups_on_customer_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_service_groups_on_customer_id ON public.service_groups USING btree (customer_id);


--
-- Name: index_service_groups_on_name; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_service_groups_on_name ON public.service_groups USING btree (name);


--
-- Name: index_service_groups_on_provider_type; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_service_groups_on_provider_type ON public.service_groups USING btree (provider_type);


--
-- Name: index_service_groups_on_tenant_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_service_groups_on_tenant_id ON public.service_groups USING btree (tenant_id);


--
-- Name: index_service_synchronization_histories_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_service_synchronization_histories_on_adapter_id ON public.service_synchronization_histories USING btree (adapter_id);


--
-- Name: index_services_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_services_on_adapter_id ON public.services USING btree (adapter_id);


--
-- Name: index_services_on_created_by; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_services_on_created_by ON public.services USING btree (created_by);


--
-- Name: index_services_on_deleted_at; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_services_on_deleted_at ON public.services USING btree (deleted_at);


--
-- Name: index_services_on_generic_type; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_services_on_generic_type ON public.services USING btree (generic_type);


--
-- Name: index_services_on_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_services_on_id ON public.services USING btree (id);


--
-- Name: index_services_on_id_and_provider_id_and_deleted_at; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_services_on_id_and_provider_id_and_deleted_at ON public.services USING btree (id, provider_id, deleted_at);


--
-- Name: index_services_on_state; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_services_on_state ON public.services USING btree (state);


--
-- Name: index_services_on_type; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_services_on_type ON public.services USING btree (type);


--
-- Name: index_services_on_updated_by; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_services_on_updated_by ON public.services USING btree (updated_by);


--
-- Name: index_services_tasks_on_service_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_services_tasks_on_service_id ON public.services_tasks USING btree (service_id);


--
-- Name: index_services_tasks_on_task_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_services_tasks_on_task_id ON public.services_tasks USING btree (task_id);


--
-- Name: index_sg_on_adapter_id_and_region_id_and_vpc_id_and_provider_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_sg_on_adapter_id_and_region_id_and_vpc_id_and_provider_id ON public.security_groups USING btree (adapter_id, region_id, vpc_id, group_id);


--
-- Name: index_slack_users_on_access_token; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_slack_users_on_access_token ON public.slack_users USING btree (access_token);


--
-- Name: index_slack_users_on_organisation_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_slack_users_on_organisation_id ON public.slack_users USING btree (organisation_id);


--
-- Name: index_slack_users_on_user_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_slack_users_on_user_id ON public.slack_users USING btree (user_id);


--
-- Name: index_slack_users_on_workspace_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_slack_users_on_workspace_id ON public.slack_users USING btree (workspace_id);


--
-- Name: index_snapshots_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_snapshots_on_adapter_id ON public.snapshots USING btree (adapter_id);


--
-- Name: index_snapshots_on_category; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_snapshots_on_category ON public.snapshots USING btree (category);


--
-- Name: index_snapshots_on_created_by; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_snapshots_on_created_by ON public.snapshots USING btree (created_by);


--
-- Name: index_snapshots_on_machine_image_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_snapshots_on_machine_image_id ON public.snapshots USING btree (machine_image_id);


--
-- Name: index_snapshots_tasks_on_snapshot_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_snapshots_tasks_on_snapshot_id ON public.snapshots_tasks USING btree (snapshot_id);


--
-- Name: index_snapshots_tasks_on_task_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_snapshots_tasks_on_task_id ON public.snapshots_tasks USING btree (task_id);


--
-- Name: index_storages_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_storages_on_adapter_id ON public.storages USING btree (adapter_id);


--
-- Name: index_subnet_groups_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_subnet_groups_on_adapter_id ON public.subnet_groups USING btree (adapter_id);


--
-- Name: index_subnet_groups_on_adapter_id_and_region_id_and_provider_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_subnet_groups_on_adapter_id_and_region_id_and_provider_id ON public.subnet_groups USING btree (adapter_id, region_id, provider_id);


--
-- Name: index_subnets_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_subnets_on_adapter_id ON public.subnets USING btree (adapter_id);


--
-- Name: index_tag_key_values_on_tag_key_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_tag_key_values_on_tag_key_id ON public.tag_key_values USING btree (tag_key_id);


--
-- Name: index_tag_key_values_on_tag_key_id_and_tag_value; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_tag_key_values_on_tag_key_id_and_tag_value ON public.tag_key_values USING btree (tag_key_id, tag_value);


--
-- Name: index_tag_keys_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_tag_keys_on_adapter_id ON public.tag_keys USING btree (adapter_id);


--
-- Name: index_tag_keys_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_tag_keys_on_subscription_id ON public.tag_keys USING btree (subscription_id);


--
-- Name: index_task_details_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_task_details_on_adapter_id ON public.task_details USING btree (adapter_id);


--
-- Name: index_task_details_on_resource_identifier; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_task_details_on_resource_identifier ON public.task_details USING btree (resource_identifier);


--
-- Name: index_task_details_on_task_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_task_details_on_task_id ON public.task_details USING btree (task_id);


--
-- Name: index_task_details_on_type; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_task_details_on_type ON public.task_details USING btree (type);


--
-- Name: index_tasks_on_tenant_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_tasks_on_tenant_id ON public.tasks USING btree (tenant_id);


--
-- Name: index_tasks_on_type; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_tasks_on_type ON public.tasks USING btree (type);


--
-- Name: index_template_kumo_services_on_template_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_template_kumo_services_on_template_id ON public.template_kumo_services USING btree (template_id);


--
-- Name: index_template_kumo_services_on_template_id_and_kumo_service_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_template_kumo_services_on_template_id_and_kumo_service_id ON public.template_kumo_services USING btree (template_id, kumo_service_id);


--
-- Name: index_template_services_on_service_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_template_services_on_service_id ON public.template_services USING btree (service_id);


--
-- Name: index_template_services_on_template_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_template_services_on_template_id ON public.template_services USING btree (template_id);


--
-- Name: index_templates_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_templates_on_adapter_id ON public.templates USING btree (adapter_id);


--
-- Name: index_templates_on_subscription_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_templates_on_subscription_id ON public.templates USING btree (subscription_id);


--
-- Name: index_tenant_adapters_on_adapter_id_and_tenant_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_tenant_adapters_on_adapter_id_and_tenant_id ON public.tenant_adapters USING btree (adapter_id, tenant_id);


--
-- Name: index_tenant_adapters_on_tenant_id_and_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_tenant_adapters_on_tenant_id_and_adapter_id ON public.tenant_adapters USING btree (tenant_id, adapter_id);


--
-- Name: index_tenant_users_on_tenant_id_and_user_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_tenant_users_on_tenant_id_and_user_id ON public.tenant_users USING btree (tenant_id, user_id);


--
-- Name: index_tenant_users_on_user_id_and_tenant_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_tenant_users_on_user_id_and_tenant_id ON public.tenant_users USING btree (user_id, tenant_id);


--
-- Name: index_tenants_on_organisation_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_tenants_on_organisation_id ON public.tenants USING btree (organisation_id);


--
-- Name: index_tenants_resource_groups_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_tenants_resource_groups_on_adapter_id ON public.tenants_resource_groups USING btree (adapter_id);


--
-- Name: index_tenants_resource_groups_on_azure_resource_group_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_tenants_resource_groups_on_azure_resource_group_id ON public.tenants_resource_groups USING btree (azure_resource_group_id);


--
-- Name: index_tenants_resource_groups_on_tenant_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_tenants_resource_groups_on_tenant_id ON public.tenants_resource_groups USING btree (tenant_id);


--
-- Name: index_user_roles_on_organisation_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_user_roles_on_organisation_id ON public.user_roles USING btree (organisation_id);


--
-- Name: index_user_roles_users_on_tenant_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_user_roles_users_on_tenant_id ON public.user_roles_users USING btree (tenant_id);


--
-- Name: index_users_on_authentication_token; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_users_on_authentication_token ON public.users USING btree (authentication_token);


--
-- Name: index_users_on_confirmation_token; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_users_on_confirmation_token ON public.users USING btree (confirmation_token);


--
-- Name: index_users_on_current_tenant; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_users_on_current_tenant ON public.users USING btree (current_tenant);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: index_users_roles_on_user_id_and_role_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_users_roles_on_user_id_and_role_id ON public.users_roles USING btree (user_id, role_id);


--
-- Name: index_vm_ware_service_forecast_costs_on_account_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_vm_ware_service_forecast_costs_on_account_id ON public.vm_ware_service_forecast_costs USING btree (account_id);


--
-- Name: index_vm_ware_service_forecast_costs_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_vm_ware_service_forecast_costs_on_adapter_id ON public.vm_ware_service_forecast_costs USING btree (adapter_id);


--
-- Name: index_vm_ware_tenant_adapters_on_organisation_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_vm_ware_tenant_adapters_on_organisation_id ON public.vm_ware_tenant_adapters USING btree (organisation_id);


--
-- Name: index_vm_ware_tenant_adapters_on_tenant_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_vm_ware_tenant_adapters_on_tenant_id ON public.vm_ware_tenant_adapters USING btree (tenant_id);


--
-- Name: index_vpcs_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_vpcs_on_adapter_id ON public.vpcs USING btree (adapter_id);


--
-- Name: index_vpcs_on_adapter_id_and_region_id_and_vpc_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_vpcs_on_adapter_id_and_region_id_and_vpc_id ON public.vpcs USING btree (adapter_id, region_id, vpc_id);


--
-- Name: index_vw_events_on_vw_inventory_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_vw_events_on_vw_inventory_id ON public.vw_events USING btree (vw_inventory_id);


--
-- Name: index_vw_inventories_on_provider_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_vw_inventories_on_provider_id ON public.vw_inventories USING btree (provider_id);


--
-- Name: index_vw_inventories_on_vw_vcenter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_vw_inventories_on_vw_vcenter_id ON public.vw_inventories USING btree (vw_vcenter_id);


--
-- Name: index_vw_metrics_on_vw_inventory_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_vw_metrics_on_vw_inventory_id ON public.vw_metrics USING btree (vw_inventory_id);


--
-- Name: index_vw_metrics_on_vw_inventory_id_and_noted_at; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX index_vw_metrics_on_vw_inventory_id_and_noted_at ON public.vw_metrics USING btree (vw_inventory_id, noted_at);


--
-- Name: index_vw_vcenters_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_vw_vcenters_on_adapter_id ON public.vw_vcenters USING btree (adapter_id);


--
-- Name: index_vw_vdc_files_on_adapter_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_vw_vdc_files_on_adapter_id ON public.vw_vdc_files USING btree (adapter_id);


--
-- Name: index_workspaces_on_data; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_workspaces_on_data ON public.workspaces USING gin (data);


--
-- Name: index_workspaces_on_organisation_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_workspaces_on_organisation_id ON public.workspaces USING btree (organisation_id);


--
-- Name: index_workspaces_on_user_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX index_workspaces_on_user_id ON public.workspaces USING btree (user_id);


--
-- Name: kumo_service_tags_unique_on_kumo_service_id_tag_key_value_id; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX kumo_service_tags_unique_on_kumo_service_id_tag_key_value_id ON public.kumo_services_tag_key_values USING btree (kumo_service_id, tag_key_value_id);


--
-- Name: organisation_images_copy_account_id_machine_image_id_idx; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX organisation_images_copy_account_id_machine_image_id_idx ON public.organisation_images_copy USING btree (account_id, machine_image_id);


--
-- Name: tenant_adapter_rg_index; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE INDEX tenant_adapter_rg_index ON public.tenants_resource_groups USING btree (tenant_id, adapter_id, azure_resource_group_id);


--
-- Name: uniq_by_organisation_and_user; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX uniq_by_organisation_and_user ON public.organisations_users USING btree (organisation_id, user_id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: csmpdbuser
--

CREATE UNIQUE INDEX unique_schema_migrations ON public.schema_migrations USING btree (version);


--
-- Name: accounts_soe_scripts_remote_sources acc_soe_script_source_acc_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.accounts_soe_scripts_remote_sources
    ADD CONSTRAINT acc_soe_script_source_acc_id_fk FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: adapters adapters_account_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.adapters
    ADD CONSTRAINT adapters_account_id_fk FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: associated_services associated_services_kumo_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.associated_services
    ADD CONSTRAINT associated_services_kumo_service_id_fk FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: azure_availability_sets azure_availability_sets_kumo_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_availability_sets
    ADD CONSTRAINT azure_availability_sets_kumo_service_id_fk FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: azure_disks azure_disks_kumo_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_disks
    ADD CONSTRAINT azure_disks_kumo_service_id_fk FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: azure_load_balancers azure_load_balancers_kumo_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_load_balancers
    ADD CONSTRAINT azure_load_balancers_kumo_service_id_fk FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: azure_network_interfaces azure_network_interfaces_kumo_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_network_interfaces
    ADD CONSTRAINT azure_network_interfaces_kumo_service_id_fk FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: azure_public_ip_addresses azure_public_ip_addresses_kumo_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_public_ip_addresses
    ADD CONSTRAINT azure_public_ip_addresses_kumo_service_id_fk FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: azure_route_tables azure_route_tables_kumo_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_route_tables
    ADD CONSTRAINT azure_route_tables_kumo_service_id_fk FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: azure_security_groups azure_security_groups_kumo_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_security_groups
    ADD CONSTRAINT azure_security_groups_kumo_service_id_fk FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: azure_sql_db_servers azure_sql_db_servers_kumo_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_sql_db_servers
    ADD CONSTRAINT azure_sql_db_servers_kumo_service_id_fk FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: azure_sql_dbs azure_sql_dbs_kumo_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_sql_dbs
    ADD CONSTRAINT azure_sql_dbs_kumo_service_id_fk FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: azure_storage_accounts azure_storage_accounts_kumo_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_storage_accounts
    ADD CONSTRAINT azure_storage_accounts_kumo_service_id_fk FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: azure_subnets azure_subnets_kumo_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_subnets
    ADD CONSTRAINT azure_subnets_kumo_service_id_fk FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: azure_virtual_machines azure_virtual_machines_kumo_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_virtual_machines
    ADD CONSTRAINT azure_virtual_machines_kumo_service_id_fk FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: azure_vnets azure_vnets_kumo_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_vnets
    ADD CONSTRAINT azure_vnets_kumo_service_id_fk FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: aggregates delete_aggregates_with_filers; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.aggregates
    ADD CONSTRAINT delete_aggregates_with_filers FOREIGN KEY (filer_id) REFERENCES public.filers(id) ON DELETE CASCADE;


--
-- Name: environment_filer_volumes delete_env_filer_volumes_on_env; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_filer_volumes
    ADD CONSTRAINT delete_env_filer_volumes_on_env FOREIGN KEY (environment_id) REFERENCES public.environments(id) ON DELETE CASCADE;


--
-- Name: environment_filer_volumes delete_env_filer_volumes_on_vol; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_filer_volumes
    ADD CONSTRAINT delete_env_filer_volumes_on_vol FOREIGN KEY (filer_volume_id) REFERENCES public.filer_volumes(id) ON DELETE CASCADE;


--
-- Name: instance_filer_volumes delete_instance_filer_volumes_on_fvol; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.instance_filer_volumes
    ADD CONSTRAINT delete_instance_filer_volumes_on_fvol FOREIGN KEY (filer_volume_id) REFERENCES public.filer_volumes(id) ON DELETE CASCADE;


--
-- Name: instance_filer_volumes delete_instance_filer_volumes_on_svc; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.instance_filer_volumes
    ADD CONSTRAINT delete_instance_filer_volumes_on_svc FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE CASCADE;


--
-- Name: filer_volumes delete_volume_with_aggregates; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.filer_volumes
    ADD CONSTRAINT delete_volume_with_aggregates FOREIGN KEY (aggregate_id) REFERENCES public.aggregates(id) ON DELETE CASCADE;


--
-- Name: environment_jobs environment_jobs_environment_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_jobs
    ADD CONSTRAINT environment_jobs_environment_id_fk FOREIGN KEY (environment_id) REFERENCES public.environments(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: environment_jobs environment_jobs_job_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_jobs
    ADD CONSTRAINT environment_jobs_job_id_fk FOREIGN KEY (job_id) REFERENCES public.jobs(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: environments environments_account_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT environments_account_id_fk FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: environments environments_template_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT environments_template_id_fk FOREIGN KEY (template_id) REFERENCES public.templates(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: events events_account_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_account_id_fk FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: tenant_adapters fk_rails_011b1a54f7; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenant_adapters
    ADD CONSTRAINT fk_rails_011b1a54f7 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: tenants_resource_groups fk_rails_0850915365; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenants_resource_groups
    ADD CONSTRAINT fk_rails_0850915365 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id);


--
-- Name: account_gcp_multi_regions fk_rails_09940cec34; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.account_gcp_multi_regions
    ADD CONSTRAINT fk_rails_09940cec34 FOREIGN KEY (gcp_multi_regional_id) REFERENCES public.gcp_multi_regionals(id);


--
-- Name: aws_records fk_rails_0c20a97e84; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.aws_records
    ADD CONSTRAINT fk_rails_0c20a97e84 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: tenant_service_groups fk_rails_0cc1e42bf5; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenant_service_groups
    ADD CONSTRAINT fk_rails_0cc1e42bf5 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: organisation_adapters fk_rails_0dec690073; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisation_adapters
    ADD CONSTRAINT fk_rails_0dec690073 FOREIGN KEY (organisation_id) REFERENCES public.organisations(id);


--
-- Name: tenants fk_rails_111d6de5dc; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT fk_rails_111d6de5dc FOREIGN KEY (organisation_id) REFERENCES public.organisations(id) ON DELETE CASCADE;


--
-- Name: internet_gateways fk_rails_116692a3c4; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.internet_gateways
    ADD CONSTRAINT fk_rails_116692a3c4 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: organisation_adapters fk_rails_1186987715; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisation_adapters
    ADD CONSTRAINT fk_rails_1186987715 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id);


--
-- Name: vm_ware_tenant_adapters fk_rails_1812ada41e; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.vm_ware_tenant_adapters
    ADD CONSTRAINT fk_rails_1812ada41e FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: template_kumo_services fk_rails_181e0cbf13; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.template_kumo_services
    ADD CONSTRAINT fk_rails_181e0cbf13 FOREIGN KEY (template_id) REFERENCES public.templates(id) ON DELETE CASCADE;


--
-- Name: custom_dashboards fk_rails_195fd4585e; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.custom_dashboards
    ADD CONSTRAINT fk_rails_195fd4585e FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: azure_service_forecast_costs fk_rails_1a45215033; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_service_forecast_costs
    ADD CONSTRAINT fk_rails_1a45215033 FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: storages fk_rails_1baf70a2ba; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.storages
    ADD CONSTRAINT fk_rails_1baf70a2ba FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: connections fk_rails_1cd9c557da; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.connections
    ADD CONSTRAINT fk_rails_1cd9c557da FOREIGN KEY (remote_interface_id) REFERENCES public.interfaces(id) ON DELETE CASCADE;


--
-- Name: environments fk_rails_23ebfd9b38; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT fk_rails_23ebfd9b38 FOREIGN KEY (default_adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: organisation_images fk_rails_2bcebffeb2; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisation_images
    ADD CONSTRAINT fk_rails_2bcebffeb2 FOREIGN KEY (machine_image_id) REFERENCES public.machine_images(id) ON DELETE CASCADE;


--
-- Name: report_configurations fk_rails_2e7985f83a; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.report_configurations
    ADD CONSTRAINT fk_rails_2e7985f83a FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: gcp_resources fk_rails_3467b3b636; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.gcp_resources
    ADD CONSTRAINT fk_rails_3467b3b636 FOREIGN KEY (gcp_multi_regional_id) REFERENCES public.gcp_multi_regionals(id);


--
-- Name: app_access_secrets fk_rails_35ba722a4e; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.app_access_secrets
    ADD CONSTRAINT fk_rails_35ba722a4e FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: services fk_rails_44049e09a1; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT fk_rails_44049e09a1 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: aws_service_forecast_costs fk_rails_44817ce62e; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.aws_service_forecast_costs
    ADD CONSTRAINT fk_rails_44817ce62e FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: cost_summaries fk_rails_44b8cd40db; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.cost_summaries
    ADD CONSTRAINT fk_rails_44b8cd40db FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: tenants_resource_groups fk_rails_5ce3eaf38b; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenants_resource_groups
    ADD CONSTRAINT fk_rails_5ce3eaf38b FOREIGN KEY (azure_resource_group_id) REFERENCES public.azure_resource_groups(id);


--
-- Name: azure_cost_summaries fk_rails_5efda88450; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_cost_summaries
    ADD CONSTRAINT fk_rails_5efda88450 FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: vm_ware_service_forecast_costs fk_rails_60ab0e3835; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.vm_ware_service_forecast_costs
    ADD CONSTRAINT fk_rails_60ab0e3835 FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: service_synchronization_histories fk_rails_618eccfddc; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.service_synchronization_histories
    ADD CONSTRAINT fk_rails_618eccfddc FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: encryption_keys fk_rails_621ac28cfa; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.encryption_keys
    ADD CONSTRAINT fk_rails_621ac28cfa FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: azure_rg_service_forecast_costs fk_rails_6597ae3674; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_rg_service_forecast_costs
    ADD CONSTRAINT fk_rails_6597ae3674 FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: gcp_resources fk_rails_6710422af0; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.gcp_resources
    ADD CONSTRAINT fk_rails_6710422af0 FOREIGN KEY (gcp_resource_zone_id) REFERENCES public.gcp_resource_zones(id);


--
-- Name: subnet_groups fk_rails_6c9e7b5ea1; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.subnet_groups
    ADD CONSTRAINT fk_rails_6c9e7b5ea1 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: compliance_checks fk_rails_77fb0d7ce0; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.compliance_checks
    ADD CONSTRAINT fk_rails_77fb0d7ce0 FOREIGN KEY (compliance_standard_id) REFERENCES public.compliance_standards(id) ON DELETE CASCADE;


--
-- Name: organisation_images fk_rails_7937529847; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisation_images
    ADD CONSTRAINT fk_rails_7937529847 FOREIGN KEY (machine_image_group_id) REFERENCES public.machine_image_groups(id) ON DELETE CASCADE;


--
-- Name: azure_usage_costs fk_rails_7a05f50869; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_usage_costs
    ADD CONSTRAINT fk_rails_7a05f50869 FOREIGN KEY (subscription_id) REFERENCES public.azure_subscriptions(id) ON DELETE CASCADE;


--
-- Name: gcp_service_forecast_costs fk_rails_7bf6ee1460; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.gcp_service_forecast_costs
    ADD CONSTRAINT fk_rails_7bf6ee1460 FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: azure_compliance_checks fk_rails_7d3c36e9ca; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_compliance_checks
    ADD CONSTRAINT fk_rails_7d3c36e9ca FOREIGN KEY (azure_compliance_standard_id) REFERENCES public.azure_compliance_standards(id) ON DELETE CASCADE;


--
-- Name: nacls fk_rails_7ec7b32a31; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.nacls
    ADD CONSTRAINT fk_rails_7ec7b32a31 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: connections fk_rails_805efd4280; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.connections
    ADD CONSTRAINT fk_rails_805efd4280 FOREIGN KEY (interface_id) REFERENCES public.interfaces(id) ON DELETE CASCADE;


--
-- Name: vm_ware_tenant_adapters fk_rails_8115b07809; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.vm_ware_tenant_adapters
    ADD CONSTRAINT fk_rails_8115b07809 FOREIGN KEY (organisation_id) REFERENCES public.organisations(id);


--
-- Name: environment_kumo_services fk_rails_83ecf2ee28; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_kumo_services
    ADD CONSTRAINT fk_rails_83ecf2ee28 FOREIGN KEY (environment_id) REFERENCES public.environments(id) ON DELETE CASCADE;


--
-- Name: organisation_service_groups fk_rails_8596cca9fe; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisation_service_groups
    ADD CONSTRAINT fk_rails_8596cca9fe FOREIGN KEY (service_group_id) REFERENCES public.service_groups(id);


--
-- Name: billing_currencies fk_rails_867bb47173; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.billing_currencies
    ADD CONSTRAINT fk_rails_867bb47173 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id);


--
-- Name: app_access_secrets fk_rails_8a827b66b7; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.app_access_secrets
    ADD CONSTRAINT fk_rails_8a827b66b7 FOREIGN KEY (organisation_id) REFERENCES public.organisations(id) ON DELETE CASCADE;


--
-- Name: snapshots fk_rails_8c37b62916; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.snapshots
    ADD CONSTRAINT fk_rails_8c37b62916 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: user_roles fk_rails_8ebbb7eea9; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fk_rails_8ebbb7eea9 FOREIGN KEY (organisation_id) REFERENCES public.organisations(id) ON DELETE CASCADE;


--
-- Name: subnets fk_rails_8f4a3280ed; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.subnets
    ADD CONSTRAINT fk_rails_8f4a3280ed FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: azure_subscriptions fk_rails_90bc1e67fd; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_subscriptions
    ADD CONSTRAINT fk_rails_90bc1e67fd FOREIGN KEY (adapter_id) REFERENCES public.adapters(id);


--
-- Name: azure_resources fk_rails_91780a5e97; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_resources
    ADD CONSTRAINT fk_rails_91780a5e97 FOREIGN KEY (region_id) REFERENCES public.regions(id) ON DELETE CASCADE;


--
-- Name: gcp_resource_zones fk_rails_9f97b84606; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.gcp_resource_zones
    ADD CONSTRAINT fk_rails_9f97b84606 FOREIGN KEY (region_id) REFERENCES public.regions(id);


--
-- Name: azure_resource_groups fk_rails_aa331aabaf; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_resource_groups
    ADD CONSTRAINT fk_rails_aa331aabaf FOREIGN KEY (adapter_id) REFERENCES public.adapters(id);


--
-- Name: accounts_soe_scripts_remote_sources fk_rails_accscriptsource_scriptsource; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.accounts_soe_scripts_remote_sources
    ADD CONSTRAINT fk_rails_accscriptsource_scriptsource FOREIGN KEY (soe_scripts_remote_source_id) REFERENCES public.soe_scripts_remote_sources(id) ON DELETE CASCADE;


--
-- Name: gcp_report_configurations fk_rails_ace4c61e7e; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.gcp_report_configurations
    ADD CONSTRAINT fk_rails_ace4c61e7e FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: vw_inventories fk_rails_ae6194d234; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.vw_inventories
    ADD CONSTRAINT fk_rails_ae6194d234 FOREIGN KEY (vw_vcenter_id) REFERENCES public.vw_vcenters(id) ON DELETE CASCADE;


--
-- Name: account_gcp_multi_regions fk_rails_ae76f1ada0; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.account_gcp_multi_regions
    ADD CONSTRAINT fk_rails_ae76f1ada0 FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: template_services fk_rails_ae8c61ff91; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.template_services
    ADD CONSTRAINT fk_rails_ae8c61ff91 FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE CASCADE;


--
-- Name: route_tables fk_rails_b096433dd6; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.route_tables
    ADD CONSTRAINT fk_rails_b096433dd6 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: azure_resource_connections fk_rails_b1c3328b81; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_resource_connections
    ADD CONSTRAINT fk_rails_b1c3328b81 FOREIGN KEY (resource_id) REFERENCES public.azure_resources(id) ON DELETE CASCADE;


--
-- Name: email_templates fk_rails_b4d4a5a71b; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT fk_rails_b4d4a5a71b FOREIGN KEY (organisation_id) REFERENCES public.organisations(id);


--
-- Name: environment_services fk_rails_b5d455bfe3; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_services
    ADD CONSTRAINT fk_rails_b5d455bfe3 FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE CASCADE;


--
-- Name: environment_services fk_rails_b697ec62bc; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environment_services
    ADD CONSTRAINT fk_rails_b697ec62bc FOREIGN KEY (environment_id) REFERENCES public.environments(id) ON DELETE CASCADE;


--
-- Name: interfaces fk_rails_c50305bd30; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.interfaces
    ADD CONSTRAINT fk_rails_c50305bd30 FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE CASCADE;


--
-- Name: tenant_adapters fk_rails_c798355236; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenant_adapters
    ADD CONSTRAINT fk_rails_c798355236 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id);


--
-- Name: azure_resources fk_rails_c8b5e2f457; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_resources
    ADD CONSTRAINT fk_rails_c8b5e2f457 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: costs fk_rails_ca5efe0334; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.costs
    ADD CONSTRAINT fk_rails_ca5efe0334 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: user_roles_users fk_rails_cbc0469ac8; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.user_roles_users
    ADD CONSTRAINT fk_rails_cbc0469ac8 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: organisation_service_groups fk_rails_cc4696d86b; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisation_service_groups
    ADD CONSTRAINT fk_rails_cc4696d86b FOREIGN KEY (organisation_id) REFERENCES public.organisations(id);


--
-- Name: vpcs fk_rails_cd930cd0a7; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.vpcs
    ADD CONSTRAINT fk_rails_cd930cd0a7 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: gcp_resources fk_rails_ce85ed896e; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.gcp_resources
    ADD CONSTRAINT fk_rails_ce85ed896e FOREIGN KEY (region_id) REFERENCES public.regions(id);


--
-- Name: azure_resources fk_rails_d04a29bc05; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_resources
    ADD CONSTRAINT fk_rails_d04a29bc05 FOREIGN KEY (azure_resource_group_id) REFERENCES public.azure_resource_groups(id) ON DELETE CASCADE;


--
-- Name: template_services fk_rails_d31a9dd04b; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.template_services
    ADD CONSTRAINT fk_rails_d31a9dd04b FOREIGN KEY (template_id) REFERENCES public.templates(id) ON DELETE CASCADE;


--
-- Name: vm_ware_service_forecast_costs fk_rails_d35b244e32; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.vm_ware_service_forecast_costs
    ADD CONSTRAINT fk_rails_d35b244e32 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id);


--
-- Name: organisations fk_rails_d38927edaa; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.organisations
    ADD CONSTRAINT fk_rails_d38927edaa FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: task_details fk_rails_d94e000754; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.task_details
    ADD CONSTRAINT fk_rails_d94e000754 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: custom_dashboards fk_rails_d988a73cbb; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.custom_dashboards
    ADD CONSTRAINT fk_rails_d988a73cbb FOREIGN KEY (organisation_id) REFERENCES public.organisations(id);


--
-- Name: environments fk_rails_da4bfe43c0; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT fk_rails_da4bfe43c0 FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON DELETE CASCADE;


--
-- Name: tenants_resource_groups fk_rails_daadfc6add; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenants_resource_groups
    ADD CONSTRAINT fk_rails_daadfc6add FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: task_details fk_rails_df18f590a9; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.task_details
    ADD CONSTRAINT fk_rails_df18f590a9 FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tenant_users fk_rails_e15916f8bf; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenant_users
    ADD CONSTRAINT fk_rails_e15916f8bf FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: azure_resource_connections fk_rails_e1a1e2d8d8; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_resource_connections
    ADD CONSTRAINT fk_rails_e1a1e2d8d8 FOREIGN KEY (associated_resource_id) REFERENCES public.azure_resources(id) ON DELETE CASCADE;


--
-- Name: associated_services fk_rails_e2faeff714; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.associated_services
    ADD CONSTRAINT fk_rails_e2faeff714 FOREIGN KEY (associated_kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: adapters_machine_images fk_rails_e397db13f4; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.adapters_machine_images
    ADD CONSTRAINT fk_rails_e397db13f4 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: tenant_users fk_rails_e3b237e564; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenant_users
    ADD CONSTRAINT fk_rails_e3b237e564 FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: security_groups fk_rails_e57d7d3baa; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.security_groups
    ADD CONSTRAINT fk_rails_e57d7d3baa FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: currency_configurations fk_rails_e7a0f779e0; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.currency_configurations
    ADD CONSTRAINT fk_rails_e7a0f779e0 FOREIGN KEY (organisation_id) REFERENCES public.organisations(id);


--
-- Name: templates fk_rails_f60c93ae29; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT fk_rails_f60c93ae29 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: azure_export_configurations fk_rails_f6cc1793ed; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.azure_export_configurations
    ADD CONSTRAINT fk_rails_f6cc1793ed FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: vw_metrics fk_rails_f98565a525; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.vw_metrics
    ADD CONSTRAINT fk_rails_f98565a525 FOREIGN KEY (vw_inventory_id) REFERENCES public.vw_inventories(id) ON DELETE CASCADE;


--
-- Name: resources fk_rails_f9a04ea807; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT fk_rails_f9a04ea807 FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: tenant_service_groups fk_rails_fb60522189; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tenant_service_groups
    ADD CONSTRAINT fk_rails_fb60522189 FOREIGN KEY (service_group_id) REFERENCES public.service_groups(id);


--
-- Name: gcp_resources fk_rails_fe1a50718a; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.gcp_resources
    ADD CONSTRAINT fk_rails_fe1a50718a FOREIGN KEY (adapter_id) REFERENCES public.adapters(id);


--
-- Name: machine_image_configurations_soe_scripts fk_rails_miconfsoescript_miconf; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.machine_image_configurations_soe_scripts
    ADD CONSTRAINT fk_rails_miconfsoescript_miconf FOREIGN KEY (machine_image_configuration_id) REFERENCES public.machine_image_configurations(id) ON DELETE CASCADE;


--
-- Name: machine_image_configurations_soe_scripts fk_rails_miconfsoescript_soe_script; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.machine_image_configurations_soe_scripts
    ADD CONSTRAINT fk_rails_miconfsoescript_soe_script FOREIGN KEY (soe_script_id) REFERENCES public.soe_scripts(id) ON DELETE CASCADE;


--
-- Name: follow_up_email_histories follow_up_email_histories_follow_up_email_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.follow_up_email_histories
    ADD CONSTRAINT follow_up_email_histories_follow_up_email_id_fk FOREIGN KEY (follow_up_email_id) REFERENCES public.follow_up_emails(id) ON DELETE CASCADE;


--
-- Name: follow_up_emails follow_up_emails_account_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.follow_up_emails
    ADD CONSTRAINT follow_up_emails_account_id_fk FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: follow_up_emails follow_up_emails_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.follow_up_emails
    ADD CONSTRAINT follow_up_emails_user_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: groups groups_account_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_account_id_fk FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: groups_users groups_users_group_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.groups_users
    ADD CONSTRAINT groups_users_group_id_fk FOREIGN KEY (group_id) REFERENCES public.groups(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: groups_users groups_users_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.groups_users
    ADD CONSTRAINT groups_users_user_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: kumo_services kumo_services_adapter_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.kumo_services
    ADD CONSTRAINT kumo_services_adapter_id_fk FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: kumo_services_tag_key_values kumo_services_tag_key_values_kumo_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.kumo_services_tag_key_values
    ADD CONSTRAINT kumo_services_tag_key_values_kumo_service_id_fk FOREIGN KEY (kumo_service_id) REFERENCES public.kumo_services(id) ON DELETE CASCADE;


--
-- Name: logs logs_job_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_job_id_fk FOREIGN KEY (job_id) REFERENCES public.jobs(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: protocols protocols_interface_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.protocols
    ADD CONSTRAINT protocols_interface_id_fk FOREIGN KEY (interface_id) REFERENCES public.interfaces(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: resources resources_account_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_account_id_fk FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: service_events service_events_service_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.service_events
    ADD CONSTRAINT service_events_service_id_fk FOREIGN KEY (service_id) REFERENCES public.services(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: services services_account_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_account_id_fk FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: services services_created_by_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_created_by_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: services services_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_parent_id_fk FOREIGN KEY (parent_id) REFERENCES public.services(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: services services_updated_by_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_updated_by_fk FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: snapshots snapshots_created_by_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.snapshots
    ADD CONSTRAINT snapshots_created_by_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: soe_scripts soe_scripts_soe_scripts_group_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.soe_scripts
    ADD CONSTRAINT soe_scripts_soe_scripts_group_id_fk FOREIGN KEY (soe_scripts_group_id) REFERENCES public.soe_scripts_groups(id) ON DELETE CASCADE;


--
-- Name: accounts_soe_scripts_remote_sources source_soe_script_source_acc_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.accounts_soe_scripts_remote_sources
    ADD CONSTRAINT source_soe_script_source_acc_id_fk FOREIGN KEY (soe_scripts_remote_source_id) REFERENCES public.soe_scripts_remote_sources(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_adapter_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_adapter_id_fk FOREIGN KEY (adapter_id) REFERENCES public.adapters(id) ON DELETE CASCADE;


--
-- Name: tag_key_values tag_key_values_tag_key_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.tag_key_values
    ADD CONSTRAINT tag_key_values_tag_key_id_fk FOREIGN KEY (tag_key_id) REFERENCES public.tag_keys(id) ON DELETE CASCADE;


--
-- Name: templates templates_account_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_account_id_fk FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: users users_account_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_account_id_fk FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: users_roles users_roles_role_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.users_roles
    ADD CONSTRAINT users_roles_role_id_fk FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: users_roles users_roles_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: csmpdbuser
--

ALTER TABLE ONLY public.users_roles
    ADD CONSTRAINT users_roles_user_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--