#!/bin/bash

if [[ $1 == "" ]]
then
 echo "No region!!"
 exit 0
fi

if [[ $2 == "" ]]
then
 echo "No Deployment Environment specified!!"
 exit 0
fi

REGION=$1
ENV=$2
REGION_ALIAS=$3
DB_ENDPOINT=$4
VPC=$5
MongoPvtIP=$6
DATABASE_PASSWORD=$7
DOMAIN=$8


if [[ $2 == "prd" || $2 == "prod" ]]
 then
    envfull=production
    envshort=prod
    railsenv=production
    hbenv=production
    dbname=csmppostgres${envshort}
    testdbname=csmppostgres${envshort}_test
    dbuser=csmpdbuser$envshort

elif [[ $2 == "dev" ]]
then
    envfull=devlopment
    envshort=dev
    railsenv=dev
    hbenv=development
    dbname=csmppostgres${envshort}
    testdbname=csmppostgres${envshort}_test
    dbuser=csmpdbuser$envshort
elif [[ $2 == "test" ]]
then
    envfull=test
    railsenv=test
    hbenv=test
    dbname=csmppostgres${envshort}
    testdbname=csmppostgres${envshort}_test
    dbuser=csmpdbuser$envshort
elif [[ $2 == "stg" || $2 == "stage" ]]
then
    envfull=stage
    envshort=stg
    railsenv=staging
    hbenv=staging
    dbname=csmppostgres${envshort}
    testdbname=csmppostgres${envshort}_test
    dbuser=csmpdbuser$envshort
else
    echo "Unknown Environment Variable"
    exit 0
fi




echo "Rails Env = $railsenv"
echo "Honeybadger Env = $hbenv"
echo "DB Name= $dbname"
echo "Test DB Name = $testdbname"
echo "RDS DB Endpoint = $DB_ENDPOINT"

aws secretsmanager create-secret --name "SAAS_ENV" --secret-string \""true"\" --region ${REGION~~}
aws secretsmanager create-secret --name "GEM_HOME" --secret-string \""/usr/local/bundle"\" --region ${REGION~~}
aws secretsmanager create-secret --name "HOSTED_REGION" --secret-string \""$REGION_ALIAS"\" --region ${REGION~~}
aws secretsmanager create-secret --name "WEB_PROTOCOL" --secret-string \""https:"\" --region ${REGION~~}
aws secretsmanager create-secret --name "WEB_HOST" --secret-string \""$DOMAIN"\" --region ${REGION~~}
aws secretsmanager create-secret --name "WEB_PORT" --secret-string \""443"\" --region ${REGION~~}
aws secretsmanager create-secret --name "API_PROTOCOL" --secret-string \""https:"\" --region ${REGION~~}
aws secretsmanager create-secret --name "API_HOST" --secret-string \""api-$REGION_ALIAS.$DOMAIN"\" --region ${REGION~~}
aws secretsmanager create-secret --name "NODE_API_HOST" --secret-string \""https://node-api-$REGION_ALIAS.$DOMAIN"\" --region ${REGION~~}
aws secretsmanager create-secret --name "API_PORT" --secret-string \""443"\" --region ${REGION~~}
aws secretsmanager create-secret --name "NODE_API_PORT" --secret-string \""3200"\" --region ${REGION~~}
aws secretsmanager create-secret --name "REPORT_API_PROTOCOL" --secret-string \""https:"\" --region ${REGION~~}
aws secretsmanager create-secret --name "REPORT_API_HOST" --secret-string \""report-$REGION_ALIAS.$DOMAIN"\" --region ${REGION~~}
aws secretsmanager create-secret --name "REPORT_API_PORT" --secret-string \""443"\" --region ${REGION~~}
aws secretsmanager create-secret --name "CUSTOMERIO_SITE_ID" --secret-string \""e67222b14b8aead3ed51"\" --region ${REGION~~}
aws secretsmanager create-secret --name "CUSTOMERIO_API_KEY" --secret-string \""464a79732ca3ddde0e71"\" --region ${REGION~~}
aws secretsmanager create-secret --name "CENTRAL_API_AUTH_TOKEN" --secret-string \""3e9868e7153ae0e1fc4b44b79db5333a8f"\" --region ${REGION~~}
aws secretsmanager create-secret --name "RAILS_ENV" --secret-string \""$railsenv"\" --region ${REGION~~}
aws secretsmanager create-secret --name "HOSTED_ZONE_ID" --secret-string \""Z19CFP8G9R8JU4"\" --region ${REGION~~}
aws secretsmanager create-secret --name "PROD_ROLE_ARN" --secret-string \""arn:aws:iam::702574401249:role/devmarketplace-prod-role"\" --region ${REGION~~}
aws secretsmanager create-secret --name "SECRET_TOKEN" --secret-string 'D3V153!P3PP3R!' --region ${REGION~~}
aws secretsmanager create-secret --name "DEVISE_PEPPER" --secret-string 'S3CR3T!T0K3N!' --region ${REGION~~}
aws secretsmanager create-secret --name "MP_ACC_REGION" --secret-string \""us-east-1"\" --region ${REGION~~}
aws secretsmanager create-secret --name "MP_ROLE_ARN" --secret-string \""arn:aws:iam::647183662077:role/cross-role-prodacc"\" --region ${REGION~~}
aws secretsmanager create-secret --name "SAAS_SUBSCRIPTION_ENABLE" --secret-string \""true"\" --region ${REGION~~}
aws secretsmanager create-secret --name "HONEYBADGER_ENV" --secret-string \""$hbenv"\" --region ${REGION~~}
aws secretsmanager create-secret --name "HONEYBADGER_API_KEY" --secret-string \""4c4e63e0"\" --region ${REGION~~}
aws secretsmanager create-secret --name "SCOUT_KEY" --secret-string \""MCnxjD2bssQdB06aTczw"\" --region ${REGION~~}
aws secretsmanager create-secret --name "BUGSNAG_API_KEY" --secret-string \""c49a691391f9319e83b35f72a75f1137"\" --region ${REGION~~}

aws secretsmanager create-secret --name "SMTP_USER_NAME" --secret-string \""noreply@$DOMAIN"\" --region ${REGION~~}
aws secretsmanager create-secret --name "SES_USERNAME" --secret-string \""AKIA2HFFSS3Q6A2JJYMA"\" --region ${REGION~~}
aws secretsmanager create-secret --name "SES_PASSWORD" --secret-string \""BCW/5OMTat9XrCrN7yGNTDIhGeDbNUCdv5LFBFqyezaF"\" --region ${REGION~~}
aws secretsmanager create-secret --name "SES_ADDRESS" --secret-string \""email-smtp.us-west-2.amazonaws.com"\" --region ${REGION~~}

aws secretsmanager create-secret --name "AWS_ACCESS_KEY_ID" --secret-string \""AKIA2HFFSS3Q2QXOGL6W"\" --region ${REGION~~}
aws secretsmanager create-secret --name "AWS_SECRET_ACCESS_KEY" --secret-string \""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"\" --region ${REGION~~}
aws secretsmanager create-secret --name "STS_AWS_ACCESS_KEY_ID" --secret-string \""AKIA2HFFSS3QTPZYKCX2"\" --region ${REGION~~}
aws secretsmanager create-secret --name "STS_SECRET_ACCESS_KEY" --secret-string \""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"\" --region ${REGION~~}

aws secretsmanager create-secret --name "AZURE_CLIENT_ID" --secret-string \""9e70e69e-be8b-4b46-9f8e-10f307450615"\" --region ${REGION~~}
aws secretsmanager create-secret --name "AZURE_TENANT_ID" --secret-string \""b28a56aa-da4a-4be5-9dc8-002f4dcb8713"\" --region ${REGION~~}
aws secretsmanager create-secret --name "AZURE_SECRET_KEY" --secret-string \""dJXm5E6OfTwdSlNJY7JDE0aIRwgjB0k3rauFJGjwYAY="\" --region ${REGION~~}
aws secretsmanager create-secret --name "AZURE_SUBSCRIPTION_ID" --secret-string \""a60dc695-8a62-4cb4-ac4f-b9aba2b8b957"\" --region ${REGION~~}

aws secretsmanager create-secret --name "LOG_BACKUP_BUCKET" --secret-string \""kumolus-logs"\" --region ${REGION~~}
aws secretsmanager create-secret --name "SOLR_PORT" --secret-string \""8982"\" --region ${REGION~~}
aws secretsmanager create-secret --name "DATABASE_NAME" --secret-string \""$dbname"\" --region ${REGION~~}
aws secretsmanager create-secret --name "DATABASE_USER" --secret-string \""$dbuser"\" --region ${REGION~~}
aws secretsmanager create-secret --name "DATABASE_PASSWORD" --secret-string \""$DATABASE_PASSWORD"\" --region ${REGION~~}
aws secretsmanager create-secret --name "DATABASE_HOST" --secret-string \""$DB_ENDPOINT"\" --region ${REGION~~}
aws secretsmanager create-secret --name "TEST_DATABASE_NAME" --secret-string \""$testdbname"\" --region ${REGION~~}
aws secretsmanager create-secret --name "TEST_DATABASE_USER" --secret-string \""$dbuser"\" --region ${REGION~~}
aws secretsmanager create-secret --name "TEST_DATABASE_PASSWORD" --secret-string \""$DATABASE_PASSWORD"\" --region ${REGION~~}
aws secretsmanager create-secret --name "REDIS_PORT" --secret-string \""6379"\" --region ${REGION~~}
aws secretsmanager create-secret --name "REDIS_API_PORT" --secret-string \""6379"\" --region ${REGION~~}
aws secretsmanager create-secret --name "MONGODB_HOST" --secret-string \""$MongoPvtIP"\" --region ${REGION~~}
aws secretsmanager create-secret --name "MONGODB_PORT" --secret-string \""27017"\" --region ${REGION~~}
aws secretsmanager create-secret --name "REDSHIFT_VPC_ID" --secret-string \""$VPC"\" --region ${REGION~~}
aws secretsmanager create-secret --name "REDSHIFT_REGION_ID" --secret-string \""${REGION~~}"\" --region ${REGION~~}
aws secretsmanager create-secret --name "ATHENA_WORKGROUP" --secret-string \""kumo-workgroup"\" --region ${REGION~~}
aws secretsmanager create-secret --name "ATHENA_DATABASE" --secret-string \""kumoreports"\" --region ${REGION~~}
aws secretsmanager create-secret --name "APP_REGION" --secret-string \""${REGION~~}"\" --region ${REGION~~}

aws secretsmanager create-secret --name "RAW_REPORT_BUCKET" --secret-string \""raw-reports-$ENV-${REGION~~}"\" --region ${REGION~~}
aws secretsmanager create-secret --name "PARQUET_REPORT_BUCKET" --secret-string \""parquet-reports-$ENV-${REGION~~}"\" --region ${REGION~~}

aws secretsmanager create-secret --name "GLUE_JOB_NAME" --secret-string \""csv-to-parquet-$ENV-${REGION~~}"\" --region ${REGION~~}
aws secretsmanager create-secret --name "AZURE_GLUE_JOB_NAME" --secret-string \""csv-to-parquet-azure-$ENV-${REGION~~}"\" --region ${REGION~~}
aws secretsmanager create-secret --name "AZURE_GLUE_JOB_NAME_2" --secret-string \""csv-to-parquet-azure1-$ENV-${REGION~~}"\" --region ${REGION~~}
aws secretsmanager create-secret --name "GCP_GLUE_JOB_NAME" --secret-string \""gcp_bigquery_connector_for_parquet-$ENV-${REGION~~}"\" --region ${REGION~~}
aws secretsmanager create-secret --name "GCP_SCRIPT_LOCATION" --secret-string \""s3://glue-scripts-$ENV-${REGION~~}/reporting/gcp_bigquery_connector_for_parquet.py"\" --region ${REGION~~}
aws secretsmanager create-secret --name "GCP_ROLE" --secret-string \""arn:aws:iam::702574401249:role/glue-connector-service-role"\" --region ${REGION~~}



aws secretsmanager create-secret --name "S3_BUCKET_NAME" --secret-string \""vw-vdc-$ENV-${REGION~~}"\" --region ${REGION~~}
aws secretsmanager create-secret --name "S3_BUCKET_REGION" --secret-string \""${REGION~~}"\" --region ${REGION~~}
aws secretsmanager create-secret --name "RAW_METRIC_BUCKET" --secret-string \""raw-metrics-$ENV-${REGION~~}"\" --region ${REGION~~}
aws secretsmanager create-secret --name "PARQUET_METRIC_BUCKET" --secret-string \""parquet-metrics-$ENV-${REGION~~}"\" --region ${REGION~~}
aws secretsmanager create-secret --name "GCP_API_KEY" --secret-string \""AIzaSyCrcniG9Sa0tNZ9LBmL3jAjl9HF6Xa_nuk"\" --region ${REGION~~}
aws secretsmanager create-secret --name "FIXER_ACCESS_KEY" --secret-string \""23f9e0b8fe885fca2553022d2739f111"\" --region ${REGION~~}
aws secretsmanager create-secret --name "AZURE_CSP_GLUE_JOB_NAME" --secret-string \""line-items-to-parquet-azure-csp-$ENV-${REGION~~}"\" --region ${REGION~~}

aws secretsmanager create-secret --name "GLOBAL_ADMIN_ORGANIZATION_IDENTIFIER" --secret-string \""I0000001"\" --region ${REGION~~}
aws secretsmanager create-secret --name "ROUTE53_ROLE_ARN" --secret-string \""arn:aws:iam::702574401249:role/CSMPProdRoute53"\" --region ${REGION~~}
aws secretsmanager create-secret --name "ROUTE53_EXTERNAL_ID" --secret-string \""MH-3H7Dsfh5@"\" --region ${REGION~~}

aws secretsmanager create-secret --name "BILLING_CONFIG_CSV_BUCKET" --secret-string \""billing-config-csv-$ENV-${REGION~~}"\" --region ${REGION~~}
aws secretsmanager create-secret --name "INVITE_USER_CSV_BUCKET" --secret-string \""rake-invited-user-$ENV-${REGION~~}"\" --region ${REGION~~}
aws secretsmanager create-secret --name "SERVICE_GROUP_CSV_BUCKET" --secret-string \""service-group-csv-$ENV-${REGION~~}"\" --region ${REGION~~}


aws secretsmanager create-secret --name "DOCKER_UNAME_1" --secret-string \""cbcsingh"\" --region ${REGION~~}
aws secretsmanager create-secret --name "DOCKER_PWD_1" --secret-string \""N#He!9rP#3z88ay"\" --region ${REGION~~}
aws secretsmanager create-secret --name "BUGSNAG_API_KEY_REP" --secret-string \""7ba539ba0eeb9529d5c34b8e42cd739b"\" --region ${REGION~~}

aws secretsmanager create-secret --name "SECRET_KEY_BASE" --secret-string \""c0467d918a75243c660039a521dea4b63a86758457e93190b24458bece0fd5f8f1fd6452cafbd34d4c61f3ae7eafe653211efe938c977a80703a59ba0f814945"\" --region ${REGION~~}
aws secretsmanager create-secret --name "BUNDLE_GEMS__CONTRIBSYS__COM" --secret-string \""77dfa66c:e1ef3226"\" --region ${REGION~~}
