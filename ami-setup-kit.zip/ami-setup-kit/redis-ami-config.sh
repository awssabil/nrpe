#!/bin/bash

region=$1

echo "$(tput setaf 1)Running Redis AMI Software Installation Script$(tput sgr 0)"

sudo apt-get update -y

cat <<EOF | sudo tee /etc/apt/source.list
deb http://ports.ubuntu.com/ubuntu-ports focal main restricted universe multiverse
deb-src http://ports.ubuntu.com/ubuntu-ports focal main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports focal-updates main restricted universe multiverse
deb-src http://ports.ubuntu.com/ubuntu-ports focal-updates main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports focal-backports main restricted universe multiverse
deb-src http://ports.ubuntu.com/ubuntu-ports focal-backports main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports focal-security main restricted universe multiverse
deb-src http://ports.ubuntu.com/ubuntu-ports focal-security main restricted universe multiverse
deb http://archive.canonical.com/ubuntu focal partner
deb-src http://archive.canonical.com/ubuntu focal partner
EOF

sudo sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt/ focal-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
sudo apt-get install --reinstall ubuntu-advantage-tools -y
sudo apt-get update -y
sudo apt-get install autoconf gcc curl libmcrypt-dev make libssl-dev wget dc vim net-tools build-essential gettext -y
sudo apt-get install nfs-common python3 -y
sudo update-alternatives --install  /usr/bin/python python /usr/bin/python3 1000

sudo apt-get install -y unzip python3-pip python-dev build-essential


#nrpe agent installation

sudo useradd nagios

cd /home/ubuntu/

curl -L -O https://nagios-plugins.org/download/nagios-plugins-2.2.1.tar.gz
tar zxf nagios-plugins-2.2.1.tar.gz
cd nagios-plugins-2.2.1
wget -O config.guess 'http://git.savannah.gnu.org/gitweb/?p=config.git;a=blob_plain;f=config.guess;hb=HEAD'
wget -O config.sub 'http://git.savannah.gnu.org/gitweb/?p=config.git;a=blob_plain;f=config.sub;hb=HEAD'
sudo cp config.guess build-aux/
sudo cp config.sub build-aux/
sudo ./configure --build=aarch64-linux
make
sudo make install

cd /home/ubuntu/
sudo rm nagios-plugins-2.2.1.tar.gz
sudo rm -rf nagios-plugins-2.2.1

sudo curl -L -O https://github.com/NagiosEnterprises/nrpe/releases/download/nrpe-3.2.1/nrpe-3.2.1.tar.gz
sudo tar zxf nrpe-3.2.1.tar.gz
cd nrpe-3.2.1
sudo ./configure --enable-command-args --with-ssl=/usr/include/openssl --with-ssl-lib=/usr/lib/aarch64-linux-gnu --enable-ssl
sudo make all
sudo make install-daemon
sudo make install-config
sudo make install-init
sudo systemctl start nrpe
sudo systemctl enable nrpe
cd ~
sudo rm nrpe-3.2.1.tar.gz
sudo rm -rf nrpe-3.2.1

cd /home/ubuntu/ami-setup-kit

sudo cp ./nrpe-config/plugins/mem_chk /usr/local/nagios/libexec/
sudo cp ./nrpe-config/plugins/ram_chk /usr/local/nagios/libexec/
sudo cp ./nrpe-config/plugins/check_cpu.sh /usr/local/nagios/libexec/
sudo chmod +x /usr/local/nagios/libexec/mem_chk
sudo chmod +x /usr/local/nagios/libexec/ram_chk
sudo chmod +x /usr/local/nagios/libexec/check_cpu.sh

sudo cp ./nrpe-config/nrpe.cfg /usr/local/nagios/etc/nrpe.cfg

sudo service nrpe stop
sudo service nrpe start
sudo systemctl enable nrpe

echo "$(tput setaf 1)Install AWSCLI and DOcker$(tput sgr 0)"

sudo apt-get install -y apt-transport-https ca-certificates curl software-properties-common

sudo apt update -y
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=arm64] https://download.docker.com/linux/ubuntu focal stable"
sudo apt install -y apt-transport-https ca-certificates curl software-properties-common
sudo apt install -y docker-ce
sudo curl -L "https://github.com/docker/compose/releases/download/v2.18.1/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
sudo usermod -aG docker ubuntu
sudo ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose
cd ~


sudo apt update -y
sudo apt install python3 python3-pip
sudo pip3 install awscli
aws --version

mkdir -p /home/ubuntu/redis
cd /home/ubuntu

echo "$(tput setaf 1)Creating Docker Compose file$(tput sgr 0)"

cat > docker-compose.yml <<- "EOF"
version: '2.4'

services:
 redis:
   image: 'arm64v8/redis:4.0-alpine'
   container_name: 'redis'
   command: redis-server
   mem_limit: 3 GB
   ports:
     - '6379:6379'
   volumes:
     - '/home/ubuntu/redis:/data'
   restart: always
EOF

#cp /home/ubuntu/ami-setup-kit/redis-v4.0.0-alpine.tar /home/ubuntu/
#docker load --input /home/ubuntu/redis-v4.0.0-alpine.tar
sudo docker pull arm64v8/redis:4.0-alpine
sudo docker pull arm64v8/redis:3.2-alpine

echo "$(tput setaf 1)Deleting AMI Kit$(tput sgr 0)"

sudo rm -rf /home/ubuntu/awscliv2* /home/ubuntu/ami-setup-kit*

echo "$(tput setaf 1)Redis Installation Script Completed$(tput sgr 0)"
